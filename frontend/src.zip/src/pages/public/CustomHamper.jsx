import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useNavigate, useSearchParams } from "react-router-dom";

import api from "../../api/api.js";
import { useAuth } from "../../context/AuthContext.jsx";
import { useCart } from "../../context/CartContext.jsx";
import { useDeliveryLocation } from "../../context/LocationContext.jsx";
import formatCurrency from "../../utils/formatCurrency.js";
import {
  runHamporiumRouteTransition,
  runHamporiumUiTransition,
} from "../../components/HamporiumRouteTransition.jsx";

const DISPLAY_FONT =
  "'Cormorant Garamond', 'Playfair Display', Georgia, serif";

const CHANNELS = ["corporate", "wedding", "diwali", "hamperOne"];
const DESKTOP_ITEMS_PER_PAGE = 20;
const MOBILE_ITEMS_PER_PAGE = 8;

const getToday = () => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

const BULK_PURPOSE_OPTIONS = [
  { value: "corporate", label: "Corporate" },
  { value: "wedding", label: "Wedding" },
  { value: "diwali", label: "Diwali" },
  { value: "event", label: "Event" },
  { value: "other", label: "Other" },
];

const formatDate = (value) => {
  if (!value) return "—";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "—";
  }

  return new Intl.DateTimeFormat("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(date);
};

const formatDimensions = (dimensions, fallback = "—") => {
  if (!dimensions) return fallback;

  const { length, width, height, unit } = dimensions;

  if (
    [length, width, height].some(
      (value) => value === null || value === undefined || value === ""
    )
  ) {
    return fallback;
  }

  return `${length} × ${width} × ${height} ${unit || "cm"}`;
};

const formatWeight = (weight, fallback = "—") => {
  if (
    !weight ||
    weight.value === null ||
    weight.value === undefined ||
    weight.value === ""
  ) {
    return fallback;
  }

  return `${weight.value} ${weight.unit || "g"}`;
};

const formatPackSize = (component) => {
  const sizePack = String(component?.sizePack || "").trim();
  if (sizePack) return sizePack;

  const pieces = component?.piecesPerUom;
  const uom = String(component?.uom || "").trim();

  if (
    pieces !== null &&
    pieces !== undefined &&
    pieces !== "" &&
    Number.isFinite(Number(pieces)) &&
    uom
  ) {
    return `${pieces} ${uom}`;
  }

  return "—";
};

const taxLabel = (item) => {
  if (!item || item.taxEnabled === false) return "No GST";

  const rate = Number(item.taxPercent || 0);
  return rate > 0 ? `Includes ${rate}% GST` : "GST included";
};

const PERSONALIZATION_ASSET_OPTIONS = [
  { value: "logo", label: "Logo" },
  { value: "icon", label: "Icon / mark" },
  { value: "gift_wrap", label: "Gift-wrap reference" },
  { value: "reference_design", label: "Design inspiration" },
];

const PERSONALIZATION_PLACEMENT_OPTIONS = [
  { value: "top_lid", label: "Top lid" },
  { value: "front", label: "Front of box" },
  { value: "inside_lid", label: "Inside lid" },
  { value: "gift_tag", label: "Gift tag" },
  { value: "message_card", label: "Message card" },
  { value: "ribbon_tag", label: "Ribbon tag" },
  { value: "full_wrap", label: "Full gift wrap" },
  { value: "other", label: "Other / see instructions" },
];

const emptyPersonalization = () => ({
  assets: [],
  message: "",
  instructions: "",
});

const personalizationLabel = (value, options) =>
  options.find((option) => option.value === value)?.label ||
  String(value || "").replaceAll("_", " ");

const CustomHamper = () => {
  const navigate = useNavigate();
  const navigateWithRibbon = (to) =>
    runHamporiumRouteTransition(to, navigate);
  const { user } = useAuth();
  const { addCustomHamper, updateCustomHamper } = useCart();
  const { deliveryLocation } = useDeliveryLocation();

  const [searchParams, setSearchParams] = useSearchParams();
  const editCartItemId = searchParams.get("editCartItemId") || "";
  const isEditingCartHamper = Boolean(editCartItemId);
  const requestedChannel = searchParams.get("channel") || "";
  const channel = CHANNELS.includes(requestedChannel)
    ? requestedChannel
    : "";

  const requestedMode = isEditingCartHamper
    ? "personal"
    : searchParams.get("mode") === "bulk"
      ? "bulk"
      : "personal";

  const defaultBulkPurpose = ["corporate", "wedding", "diwali"].includes(
    channel
  )
    ? channel
    : "other";

  const [containers, setContainers] = useState([]);
  const [contentComponents, setContentComponents] = useState([]);
  const [decorativeComponents, setDecorativeComponents] = useState([]);
  const [containerId, setContainerId] = useState("");
  const [selectedItems, setSelectedItems] = useState([]);
  const [selectedDecorations, setSelectedDecorations] = useState([]);
  const [configuration, setConfiguration] = useState(null);
  const [personalization, setPersonalization] = useState(
    emptyPersonalization
  );
  const [assetType, setAssetType] = useState("logo");
  const [assetPlacement, setAssetPlacement] = useState("top_lid");
  const [assetNotes, setAssetNotes] = useState("");
  const [uploadingAsset, setUploadingAsset] = useState(false);
  const [personalizationError, setPersonalizationError] = useState("");

  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [subcategoryFilter, setSubcategoryFilter] = useState("");
  const [decorationSearch, setDecorationSearch] = useState("");
  const [itemPage, setItemPage] = useState(1);
  const [decorationPage, setDecorationPage] = useState(1);

  const [loading, setLoading] = useState(true);
  const [validating, setValidating] = useState(false);
  const [selectionPending, setSelectionPending] = useState(false);
  const [addingToCart, setAddingToCart] = useState(false);
  const [error, setError] = useState("");
  const [cartError, setCartError] = useState("");
  const [editError, setEditError] = useState("");
  const [editCartItem, setEditCartItem] = useState(null);
  const [editLoading, setEditLoading] = useState(Boolean(editCartItemId));

  const [orderMode, setOrderMode] = useState(requestedMode);
  const [bulkQuantity, setBulkQuantity] = useState(25);
  const [bulkPurpose, setBulkPurpose] = useState(defaultBulkPurpose);
  const [bulkCompanyName, setBulkCompanyName] = useState("");
  const [bulkGstNumber, setBulkGstNumber] = useState("");
  const [bulkRequiredDate, setBulkRequiredDate] = useState("");
  const [bulkAddressModel, setBulkAddressModel] = useState("not_decided");
  const [bulkDeliveryLocations, setBulkDeliveryLocations] = useState("");
  const [bulkNotes, setBulkNotes] = useState("");
  const [requestingQuote, setRequestingQuote] = useState(false);
  const [deliveryJourney, setDeliveryJourney] = useState("idle");

  // Desktop header hides while scrolling down and returns while scrolling up.
  // Keep the sticky builder controls attached to that same motion: when the
  // header is hidden they use the freed top space, and when it returns they
  // slide down to leave room for it.
  const [desktopHeaderVisible, setDesktopHeaderVisible] = useState(true);

  // Mobile uses a progressive builder so only one decision is visible at a time.
  // Desktop/tablet keep the existing full builder experience.
  const [mobileStep, setMobileStep] = useState(1);
  const [isMobileWizard, setIsMobileWizard] = useState(() =>
    typeof window !== "undefined"
      ? window.matchMedia("(max-width: 767px)").matches
      : false
  );
  const mobileFlowRef = useRef(null);

  useEffect(() => {
    if (typeof window === "undefined") return undefined;

    const desktopMedia = window.matchMedia("(min-width: 1024px)");
    let lastScrollY = Math.max(0, window.scrollY);
    let frame = null;

    const syncDesktopHeaderSpace = () => {
      frame = null;
      const currentScrollY = Math.max(0, window.scrollY);

      if (!desktopMedia.matches) {
        setDesktopHeaderVisible(true);
        lastScrollY = currentScrollY;
        return;
      }

      if (currentScrollY <= 20) {
        setDesktopHeaderVisible(true);
      } else if (currentScrollY > lastScrollY + 5) {
        setDesktopHeaderVisible(false);
      } else if (currentScrollY < lastScrollY - 5) {
        setDesktopHeaderVisible(true);
      }

      lastScrollY = currentScrollY;
    };

    const handleScroll = () => {
      if (frame !== null) return;
      frame = window.requestAnimationFrame(syncDesktopHeaderSpace);
    };

    const handleDesktopMediaChange = () => {
      lastScrollY = Math.max(0, window.scrollY);
      setDesktopHeaderVisible(true);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });

    if (desktopMedia.addEventListener) {
      desktopMedia.addEventListener("change", handleDesktopMediaChange);
    } else {
      desktopMedia.addListener(handleDesktopMediaChange);
    }

    return () => {
      window.removeEventListener("scroll", handleScroll);
      if (frame !== null) window.cancelAnimationFrame(frame);

      if (desktopMedia.removeEventListener) {
        desktopMedia.removeEventListener("change", handleDesktopMediaChange);
      } else {
        desktopMedia.removeListener(handleDesktopMediaChange);
      }
    };
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return undefined;

    const media = window.matchMedia("(max-width: 767px)");
    const update = () => setIsMobileWizard(media.matches);

    update();

    if (media.addEventListener) {
      media.addEventListener("change", update);
      return () => media.removeEventListener("change", update);
    }

    media.addListener(update);
    return () => media.removeListener(update);
  }, []);

  useEffect(() => {
    let cancelled = false;

    if (!isEditingCartHamper) {
      setEditCartItem(null);
      setEditError("");
      setEditLoading(false);
      return undefined;
    }

    if (!user) {
      setEditLoading(false);
      navigateWithRibbon("/login");
      return undefined;
    }

    const loadCartHamperForEditing = async () => {
      setEditLoading(true);
      setEditError("");

      try {
        const response = await api.get("/cart");
        const item = (response.data?.cart?.items || []).find(
          (cartItem) =>
            cartItem.itemType === "custom_hamper" &&
            String(cartItem.cartItemId) === String(editCartItemId)
        );

        if (!item) {
          if (!cancelled) {
            setEditCartItem(null);
            setEditError(
              "This custom hamper is no longer in your cart. Return to the cart and choose another hamper to edit."
            );
            setEditLoading(false);
          }
          return;
        }

        const savedChannel = item.customHamper?.channel || "";

        if (
          savedChannel &&
          CHANNELS.includes(savedChannel) &&
          savedChannel !== requestedChannel
        ) {
          const nextParams = new URLSearchParams(searchParams);
          nextParams.set("channel", savedChannel);
          nextParams.set("mode", "personal");
          nextParams.set("editCartItemId", String(editCartItemId));
          setSearchParams(nextParams, { replace: true });
        }

        if (!cancelled) {
          setEditCartItem(item);
        }
      } catch (requestError) {
        if (!cancelled) {
          setEditCartItem(null);
          setEditError(
            requestError.response?.data?.message ||
              requestError.message ||
              "Unable to load this custom hamper from your cart"
          );
          setEditLoading(false);
        }
      }
    };

    loadCartHamperForEditing();

    return () => {
      cancelled = true;
    };
  }, [
    editCartItemId,
    isEditingCartHamper,
    navigate,
    requestedChannel,
    searchParams,
    setSearchParams,
    user,
  ]);

  const contentMap = useMemo(
    () =>
      new Map(
        contentComponents.map((component) => [
          String(component._id),
          component,
        ])
      ),
    [contentComponents]
  );

  const decorationComponentMap = useMemo(
    () =>
      new Map(
        decorativeComponents.map((component) => [
          String(component._id),
          component,
        ])
      ),
    [decorativeComponents]
  );

  const selectedContainer = useMemo(
    () =>
      containers.find((container) => container._id === containerId) || null,
    [containers, containerId]
  );

  const selectedMap = useMemo(
    () =>
      new Map(
        selectedItems.map((item) => [item.componentId, item.quantity])
      ),
    [selectedItems]
  );

  const decorationMap = useMemo(
    () =>
      new Map(
        selectedDecorations.map((item) => [
          item.componentId,
          item.quantity,
        ])
      ),
    [selectedDecorations]
  );

  const candidateMap = useMemo(
    () =>
      new Map(
        (configuration?.candidates || []).map((candidate) => [
          String(candidate.componentId),
          candidate,
        ])
      ),
    [configuration]
  );

  const categories = useMemo(
    () =>
      [
        ...new Set(
          contentComponents
            .map((component) => component.category)
            .filter(Boolean)
        ),
      ].sort((a, b) => a.localeCompare(b)),
    [contentComponents]
  );

  const subcategories = useMemo(() => {
    const source = categoryFilter
      ? contentComponents.filter(
          (component) => component.category === categoryFilter
        )
      : contentComponents;

    return [
      ...new Set(
        source.map((component) => component.subcategory).filter(Boolean)
      ),
    ].sort((a, b) => a.localeCompare(b));
  }, [contentComponents, categoryFilter]);

  const visibleComponents = useMemo(() => {
    const query = search.trim().toLowerCase();

    const filtered = contentComponents.filter((component) => {
      if (categoryFilter && component.category !== categoryFilter) {
        return false;
      }

      if (
        subcategoryFilter &&
        component.subcategory !== subcategoryFilter
      ) {
        return false;
      }

      if (!query) return true;

      return [
        component.name,
        component.code,
        component.brand,
        component.category,
        component.subcategory,
        component.segment,
      ]
        .filter(Boolean)
        .some((value) => String(value).toLowerCase().includes(query));
    });

    // V11.1: Builder catalogue mode must never make imported Excel items
    // disappear just because price, fit or customer-selectable data is pending.
    // Ready/selected rows are sorted first; pending rows remain visible and are
    // disabled by the cards below.
    return [...filtered].sort((left, right) => {
      const leftSelected = (selectedMap.get(left._id) || 0) > 0;
      const rightSelected = (selectedMap.get(right._id) || 0) > 0;

      if (leftSelected !== rightSelected) {
        return leftSelected ? -1 : 1;
      }

      const leftReady = left.builderStatus?.selectable !== false;
      const rightReady = right.builderStatus?.selectable !== false;

      if (leftReady !== rightReady) {
        return leftReady ? -1 : 1;
      }

      if (configuration) {
        const leftCandidate = candidateMap.get(String(left._id));
        const rightCandidate = candidateMap.get(String(right._id));
        const leftFits =
          leftCandidate?.selectable !== false &&
          Number(leftCandidate?.maxAdditionalQuantity || 0) > 0;
        const rightFits =
          rightCandidate?.selectable !== false &&
          Number(rightCandidate?.maxAdditionalQuantity || 0) > 0;

        if (leftFits !== rightFits) {
          return leftFits ? -1 : 1;
        }
      }

      const recommendationPriority = (component) => {
        if (component.recommendation?.source === "container") return 2;
        if (component.recommendation?.source === "overall") return 1;
        return 0;
      };

      const leftRecommendationPriority = recommendationPriority(left);
      const rightRecommendationPriority = recommendationPriority(right);

      if (leftRecommendationPriority !== rightRecommendationPriority) {
        return rightRecommendationPriority - leftRecommendationPriority;
      }

      const recommendationScoreDiff =
        Number(right.recommendation?.score || 0) -
        Number(left.recommendation?.score || 0);

      if (recommendationScoreDiff !== 0) {
        return recommendationScoreDiff;
      }

      return String(left.name || "").localeCompare(String(right.name || ""));
    });
  }, [
    contentComponents,
    search,
    categoryFilter,
    subcategoryFilter,
    configuration,
    selectedMap,
    candidateMap,
  ]);

  const itemsPerPage = isMobileWizard
    ? MOBILE_ITEMS_PER_PAGE
    : DESKTOP_ITEMS_PER_PAGE;

  const totalItemPages = Math.max(
    1,
    Math.ceil(visibleComponents.length / itemsPerPage)
  );

  const paginatedComponents = useMemo(() => {
    const start = (itemPage - 1) * itemsPerPage;
    return visibleComponents.slice(start, start + itemsPerPage);
  }, [visibleComponents, itemPage, itemsPerPage]);

  const itemRangeStart =
    visibleComponents.length === 0
      ? 0
      : (itemPage - 1) * itemsPerPage + 1;

  const itemRangeEnd = Math.min(
    itemPage * itemsPerPage,
    visibleComponents.length
  );

  const visibleDecorations = useMemo(() => {
    const query = decorationSearch.trim().toLowerCase();

    if (!query) return decorativeComponents;

    return decorativeComponents.filter((component) =>
      [
        component.name,
        component.code,
        component.brand,
        component.category,
        component.subcategory,
        component.segment,
      ]
        .filter(Boolean)
        .some((value) => String(value).toLowerCase().includes(query))
    );
  }, [decorativeComponents, decorationSearch]);

  const totalDecorationPages = isMobileWizard
    ? Math.max(1, Math.ceil(visibleDecorations.length / MOBILE_ITEMS_PER_PAGE))
    : 1;

  const paginatedDecorations = useMemo(() => {
    if (!isMobileWizard) return visibleDecorations;

    const start = (decorationPage - 1) * MOBILE_ITEMS_PER_PAGE;
    return visibleDecorations.slice(start, start + MOBILE_ITEMS_PER_PAGE);
  }, [visibleDecorations, decorationPage, isMobileWizard]);

  const decorationRangeStart =
    visibleDecorations.length === 0
      ? 0
      : (decorationPage - 1) * MOBILE_ITEMS_PER_PAGE + 1;

  const decorationRangeEnd = isMobileWizard
    ? Math.min(decorationPage * MOBILE_ITEMS_PER_PAGE, visibleDecorations.length)
    : visibleDecorations.length;

  const selectedItemCount = useMemo(
    () =>
      selectedItems.reduce(
        (total, item) => total + Number(item.quantity || 0),
        0
      ),
    [selectedItems]
  );

  const selectedDecorationCount = useMemo(
    () =>
      selectedDecorations.reduce(
        (total, item) => total + Number(item.quantity || 0),
        0
      ),
    [selectedDecorations]
  );

  const previewItems = useMemo(() => {
    const result = [];

    for (const selection of selectedItems) {
      const component = contentMap.get(String(selection.componentId));
      if (!component) continue;

      const copies = Math.min(Number(selection.quantity || 1), 6);

      for (let index = 0; index < copies; index += 1) {
        result.push({
          id: `${component._id}-copy-${index}`,
          component,
          copyIndex: index,
        });
      }
    }

    return result.slice(0, 24);
  }, [selectedItems, contentMap]);

  const previewDecorations = useMemo(
    () =>
      selectedDecorations
        .map((selection) => ({
          selection,
          component: decorationComponentMap.get(
            String(selection.componentId)
          ),
        }))
        .filter((entry) => entry.component)
        .slice(0, 4),
    [selectedDecorations, decorationComponentMap]
  );

  const fillPercent = useMemo(() => {
    const used = Number(configuration?.capacity?.usedVolumeCm3 || 0);
    const total = Number(configuration?.capacity?.usableVolumeCm3 || 0);

    if (!total) return 0;
    return Math.min(100, Math.max(0, (used / total) * 100));
  }, [configuration?.capacity]);

  const canIncreaseAnyItem = useMemo(() => {
    if (!containerId || !configuration || validating || selectionPending) {
      return true;
    }

    return contentComponents.some((component) => {
      const candidate = candidateMap.get(String(component._id));
      const quantity = selectedMap.get(component._id) || 0;
      const hasSellingPrice =
        component.sellingPrice !== null &&
        component.sellingPrice !== undefined;

      return Boolean(
        hasSellingPrice &&
          quantity < 99 &&
          candidate &&
          candidate.selectable !== false &&
          Number(candidate.maxAdditionalQuantity || 0) > 0
      );
    });
  }, [
    containerId,
    configuration,
    validating,
    selectionPending,
    contentComponents,
    candidateMap,
    selectedMap,
  ]);


  // UI fill is intentionally normalized to 100% when the selected box has
  // reached its practical packing limit. This keeps the visual state honest:
  // the lid closes only when the customer sees 100% filled.
  const displayFillPercent = useMemo(() => {
    const raw = Math.min(100, Math.max(0, Number(fillPercent || 0)));
    const practicallyFull = Boolean(
      selectedItemCount > 0 &&
        configuration &&
        !validating &&
        !selectionPending &&
        canIncreaseAnyItem === false
    );

    if (practicallyFull || raw >= 99.95) return 100;
    return Math.min(99, Math.round(raw));
  }, [
    fillPercent,
    selectedItemCount,
    configuration,
    validating,
    selectionPending,
    canIncreaseAnyItem,
  ]);

  const personalizationPayload = useMemo(() => {
    const assets = (personalization.assets || []).map((asset) => ({
      type: asset.type,
      url: asset.url,
      publicId: asset.publicId,
      uploadProof: asset.uploadProof || "",
      fileName: asset.fileName || "",
      mimeType: asset.mimeType || "",
      size: Number(asset.size || 0),
      placement: asset.placement || "top_lid",
      notes: asset.notes || "",
    }));

    const message = personalization.message.trim();
    const instructions = personalization.instructions.trim();
    const enabled = Boolean(assets.length || message || instructions);

    return enabled
      ? {
          enabled: true,
          assets,
          message,
          instructions,
        }
      : null;
  }, [personalization]);

  useEffect(() => {
    const loadBuilderData = async () => {
      setLoading(true);
      setError("");

      try {
        // V11.1: ask the backend for the complete imported builder catalogue.
        // Normal storefront endpoints stay strict; only Custom Hamper uses this
        // broader visibility mode.
        const containerParams = new URLSearchParams({
          builderCatalog: "1",
        });

        if (channel) {
          containerParams.set("channel", channel);
        }

        const buildComponentUrl = (hamperRole) => {
          const params = new URLSearchParams({
            hamperRole,
            builderCatalog: "1",
          });

          if (channel) {
            params.set("channel", channel);
          }

          return `/catalog/components?${params.toString()}`;
        };

        const [
          containerResponse,
          contentResponse,
          decorationResponse,
        ] = await Promise.all([
          api.get(`/catalog/containers?${containerParams.toString()}`),
          api.get(buildComponentUrl("content")),
          api.get(buildComponentUrl("decoration")),
        ]);

        const loadedContainers = containerResponse.data.containers || [];
        const loadedContentComponents = contentResponse.data.components || [];
        const loadedDecorativeComponents =
          decorationResponse.data.components || [];

        setContainers(loadedContainers);
        setContentComponents(loadedContentComponents);
        setDecorativeComponents(loadedDecorativeComponents);

        const editCustom =
          isEditingCartHamper && editCartItem?.itemType === "custom_hamper"
            ? editCartItem.customHamper || {}
            : null;

        if (editCustom) {
          const savedContainerId = String(
            editCustom.container?._id ||
              editCustom.containerId ||
              editCustom.container ||
              ""
          );

          const availableContentIds = new Set(
            loadedContentComponents.map((component) => String(component._id))
          );
          const availableDecorationIds = new Set(
            loadedDecorativeComponents.map((component) => String(component._id))
          );

          const savedItems = (editCustom.items || [])
            .map((selection) => ({
              componentId: String(
                selection.component?._id ||
                  selection.componentId ||
                  selection.component ||
                  ""
              ),
              quantity: Number(selection.quantity || 1),
            }))
            .filter(
              (selection) =>
                selection.componentId &&
                Number.isInteger(selection.quantity) &&
                selection.quantity > 0
            );

          const savedDecorations = (editCustom.decorations || [])
            .map((selection) => ({
              componentId: String(
                selection.component?._id ||
                  selection.componentId ||
                  selection.component ||
                  ""
              ),
              quantity: Number(selection.quantity || 1),
            }))
            .filter(
              (selection) =>
                selection.componentId &&
                Number.isInteger(selection.quantity) &&
                selection.quantity > 0
            );

          const nextItems = savedItems.filter((selection) =>
            availableContentIds.has(selection.componentId)
          );
          const nextDecorations = savedDecorations.filter((selection) =>
            availableDecorationIds.has(selection.componentId)
          );

          const removedGiftCount = savedItems.length - nextItems.length;
          const removedDecorationCount =
            savedDecorations.length - nextDecorations.length;

          setContainerId(savedContainerId);
          setMobileStep(nextItems.length ? 2 : 1);
          setSelectedItems(nextItems);
          setSelectedDecorations(nextDecorations);
          setConfiguration(null);
          setPersonalization(
            editCustom.personalization?.enabled
              ? {
                  assets: (editCustom.personalization.assets || []).map(
                    (asset) => ({
                      ...asset,
                      uploadProof: asset.uploadProof || "",
                    })
                  ),
                  message: editCustom.personalization.message || "",
                  instructions: editCustom.personalization.instructions || "",
                }
              : emptyPersonalization()
          );
          setPersonalizationError("");
          setSelectionPending(false);
          setOrderMode("personal");

          if (removedGiftCount || removedDecorationCount) {
            const removedParts = [];
            if (removedGiftCount) {
              removedParts.push(
                `${removedGiftCount} unavailable gift${
                  removedGiftCount === 1 ? "" : "s"
                }`
              );
            }
            if (removedDecorationCount) {
              removedParts.push(
                `${removedDecorationCount} unavailable finishing item${
                  removedDecorationCount === 1 ? "" : "s"
                }`
              );
            }

            setCartError(
              `${removedParts.join(
                " and "
              )} were removed from the editor because they are no longer selectable. Review the hamper and save your changes.`
            );
          } else {
            setCartError("");
          }

          setEditLoading(false);
        } else {
          const mobileFirstChoice =
            typeof window !== "undefined" &&
            window.matchMedia("(max-width: 767px)").matches;

          setContainerId(
            mobileFirstChoice ? "" : loadedContainers[0]?._id || ""
          );
          setMobileStep(1);
          setSelectedItems([]);
          setSelectedDecorations([]);
          setConfiguration(null);
          setPersonalization(emptyPersonalization());
          setPersonalizationError("");
          setSelectionPending(false);

          if (!isEditingCartHamper) {
            setEditLoading(false);
          }
        }
      } catch (requestError) {
        setError(
          requestError.response?.data?.message ||
            "Unable to load custom hamper options"
        );

        if (isEditingCartHamper && editCartItem) {
          setEditLoading(false);
        }
      } finally {
        setLoading(false);
      }
    };

    loadBuilderData();
  }, [channel, editCartItem, isEditingCartHamper]);

  useEffect(() => {
    setOrderMode(requestedMode);
  }, [requestedMode]);

  // V51: Once a box is selected, refresh only the content catalogue with
  // purchase-backed recommendations for that specific container. The existing
  // compatibility validator remains the source of truth for whether an item can
  // actually be added to the current configuration.
  useEffect(() => {
    if (!containerId) return;

    let cancelled = false;

    const loadBoxRecommendations = async () => {
      try {
        const params = new URLSearchParams({
          hamperRole: "content",
          builderCatalog: "1",
          recommendForContainer: containerId,
        });

        if (channel) {
          params.set("channel", channel);
        }

        const response = await api.get(
          `/catalog/components?${params.toString()}`
        );

        if (!cancelled) {
          setContentComponents(response.data?.components || []);
        }
      } catch {
        // Recommendation data is enhancement-only. Keep the already-loaded
        // catalogue and the existing physical-fit flow if this request fails.
      }
    };

    loadBoxRecommendations();

    return () => {
      cancelled = true;
    };
  }, [containerId, channel]);

  useEffect(() => {
    if (!isMobileWizard) return;

    if (!containerId && mobileStep > 1) {
      setMobileStep(1);
      return;
    }

    if (containerId && selectedItems.length === 0 && mobileStep > 2) {
      setMobileStep(2);
    }
  }, [isMobileWizard, containerId, selectedItems.length, mobileStep]);

  useEffect(() => {
    if (["corporate", "wedding", "diwali"].includes(channel)) {
      setBulkPurpose(channel);
    }
  }, [channel]);

  useEffect(() => {
    if (!containerId) {
      setConfiguration(null);
      return;
    }

    // Imported procurement boxes can be real catalogue boxes while still
    // missing custom-builder capacity/price data. Keep such a box selectable
    // for preview/browsing, but do not call the strict orderability validator.
    if (selectedContainer?.builderStatus?.selectable === false) {
      const reasons = Array.isArray(selectedContainer.builderStatus?.reasons)
        ? selectedContainer.builderStatus.reasons
        : [];

      setConfiguration({
        orderable: false,
        message: reasons.length
          ? `Box data pending: ${reasons.join(", ")}`
          : "This box is visible from Product Master but is not order-ready yet.",
        capacity: null,
        pricing: null,
        candidates: [],
      });
      setError("");
      setValidating(false);
      setSelectionPending(false);
      return;
    }

    let cancelled = false;

    const timer = window.setTimeout(async () => {
      setValidating(true);

      try {
        const response = await api.post(
          "/catalog/configurations/validate",
          {
            containerId,
            items: selectedItems,
            decorations: selectedDecorations,
            candidateIds: contentComponents.map(
              (component) => component._id
            ),
            channel: channel || undefined,
          }
        );

        if (!cancelled) {
          setConfiguration(response.data.configuration || null);
          setError("");
        }
      } catch (requestError) {
        if (!cancelled) {
          setConfiguration(null);
          setError(
            requestError.response?.data?.message ||
              "Unable to validate this hamper"
          );
        }
      } finally {
        if (!cancelled) {
          setValidating(false);
          setSelectionPending(false);
        }
      }
    }, 120);

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [
    containerId,
    selectedContainer,
    selectedItems,
    selectedDecorations,
    contentComponents,
    channel,
  ]);

  useEffect(() => {
    if (categoryFilter && !categories.includes(categoryFilter)) {
      setCategoryFilter("");
    }
  }, [categories, categoryFilter]);

  useEffect(() => {
    if (
      subcategoryFilter &&
      !subcategories.includes(subcategoryFilter)
    ) {
      setSubcategoryFilter("");
    }
  }, [subcategories, subcategoryFilter]);

  useEffect(() => {
    setItemPage(1);
  }, [search, categoryFilter, subcategoryFilter, containerId]);

  useEffect(() => {
    if (itemPage > totalItemPages) {
      setItemPage(totalItemPages);
    }
  }, [itemPage, totalItemPages]);

  useEffect(() => {
    setDecorationPage(1);
  }, [decorationSearch, isMobileWizard]);

  useEffect(() => {
    if (decorationPage > totalDecorationPages) {
      setDecorationPage(totalDecorationPages);
    }
  }, [decorationPage, totalDecorationPages]);

  const setSelectionQuantity = (setter, componentId, quantity) => {
    const nextQuantity = Number(quantity);

    if (!Number.isInteger(nextQuantity) || nextQuantity < 0) return;

    setter((current) => {
      const withoutItem = current.filter(
        (item) => item.componentId !== componentId
      );

      if (nextQuantity === 0) return withoutItem;

      return [
        ...withoutItem,
        {
          componentId,
          quantity: Math.min(99, nextQuantity),
        },
      ];
    });
  };

  const incrementItem = (component) => {
    const currentQuantity = selectedMap.get(component._id) || 0;
    const candidate = candidateMap.get(String(component._id));

    if (selectionPending || validating || !configuration) return;
    if (component.builderStatus?.selectable === false) return;

    if (
      component.sellingPrice === null ||
      component.sellingPrice === undefined
    ) {
      return;
    }

    if (
      !candidate ||
      candidate.selectable === false ||
      Number(candidate.maxAdditionalQuantity || 0) <= 0 ||
      currentQuantity >= 99
    ) {
      return;
    }

    setCartError("");
    setSelectionPending(true);
    setSelectionQuantity(
      setSelectedItems,
      component._id,
      currentQuantity + 1
    );
  };

  const decrementItem = (component) => {
    const currentQuantity = selectedMap.get(component._id) || 0;
    if (currentQuantity <= 0) return;

    setCartError("");
    setSelectionQuantity(
      setSelectedItems,
      component._id,
      currentQuantity - 1
    );
  };

  const incrementDecoration = (component) => {
    const currentQuantity = decorationMap.get(component._id) || 0;

    if (component.builderStatus?.selectable === false) return;

    if (
      component.sellingPrice === null ||
      component.sellingPrice === undefined
    ) {
      return;
    }

    setCartError("");
    setSelectionQuantity(
      setSelectedDecorations,
      component._id,
      currentQuantity + 1
    );
  };

  const decrementDecoration = (component) => {
    const currentQuantity = decorationMap.get(component._id) || 0;
    if (currentQuantity <= 0) return;

    setCartError("");
    setSelectionQuantity(
      setSelectedDecorations,
      component._id,
      currentQuantity - 1
    );
  };

  const updatePersonalizationAsset = (index, field, value) => {
    setPersonalization((current) => ({
      ...current,
      assets: current.assets.map((asset, assetIndex) =>
        assetIndex === index
          ? {
              ...asset,
              [field]: value,
            }
          : asset
      ),
    }));
  };

  const handlePersonalizationUpload = async (event) => {
    const file = event.target.files?.[0] || null;
    event.target.value = "";

    if (!file) return;

    if (!user) {
      setPersonalizationError("Login before uploading artwork.");
      return;
    }

    if ((personalization.assets || []).length >= 4) {
      setPersonalizationError("You can upload up to 4 personalization images.");
      return;
    }

    const allowedTypes = new Set([
      "image/jpeg",
      "image/png",
      "image/webp",
      "image/avif",
    ]);

    if (!allowedTypes.has(file.type)) {
      setPersonalizationError("Upload JPG, PNG, WEBP or AVIF images only.");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setPersonalizationError(
        "Each personalization image must be 5 MB or smaller."
      );
      return;
    }

    setUploadingAsset(true);
    setPersonalizationError("");

    try {
      const formData = new FormData();
      formData.append("image", file);
      formData.append("type", assetType);

      const response = await api.post(
        "/cart/custom-hampers/personalization-assets",
        formData
      );

      const uploaded = response.data.asset;

      setPersonalization((current) => ({
        ...current,
        assets: [
          ...current.assets,
          {
            ...uploaded,
            placement: assetPlacement,
            notes: assetNotes.trim(),
          },
        ].slice(0, 4),
      }));

      setAssetNotes("");
    } catch (requestError) {
      setPersonalizationError(
        requestError.response?.data?.message ||
          requestError.message ||
          "Unable to upload personalization image"
      );
    } finally {
      setUploadingAsset(false);
    }
  };

  const removePersonalizationAsset = async (index) => {
    const asset = personalization.assets[index];
    if (!asset) return;

    setPersonalizationError("");

    try {
      // Existing artwork loaded from a saved cart hamper has already been
      // attached to the cart, so the storage delete endpoint correctly blocks
      // deleting it at this stage. Remove it locally and let the backend clean
      // up the detached file only after the edited hamper is saved. Newly
      // uploaded artwork still has an uploadProof and can be deleted now.
      if (user && asset.publicId && asset.uploadProof) {
        await api.delete("/cart/custom-hampers/personalization-assets", {
          data: {
            publicId: asset.publicId,
            url: asset.url,
            uploadProof: asset.uploadProof,
          },
        });
      }

      setPersonalization((current) => ({
        ...current,
        assets: current.assets.filter((_, assetIndex) => assetIndex !== index),
      }));
    } catch (requestError) {
      setPersonalizationError(
        requestError.response?.data?.message ||
          requestError.message ||
          "Unable to remove personalization image"
      );
    }
  };

  const handleAddToCart = async () => {
    if (!user) {
      navigateWithRibbon("/login");
      return;
    }

    if (
      !containerId ||
      selectedItems.length === 0 ||
      !configuration?.orderable
    ) {
      setCartError(
        isEditingCartHamper
          ? "Choose at least one hamper item and make sure the hamper is Ready before saving your changes."
          : "Choose at least one hamper item and make sure the hamper is Ready before adding it to cart."
      );
      return;
    }

    setAddingToCart(true);
    setDeliveryJourney("packing");
    setCartError("");

    try {
      await new Promise((resolve) => window.setTimeout(resolve, 900));

      const payload = {
        containerId,
        items: selectedItems,
        decorations: selectedDecorations,
        channel,
        personalization: personalizationPayload,
        source: isEditingCartHamper
          ? "custom_hamper_edit"
          : "custom_hamper",
        pagePath: `${window.location.pathname}${window.location.search}`,
        location: deliveryLocation,
      };

      if (isEditingCartHamper) {
        await updateCustomHamper(editCartItemId, payload);
      } else {
        await addCustomHamper({
          ...payload,
          quantity: 1,
        });
      }

      setDeliveryJourney("shipping");
      await new Promise((resolve) => window.setTimeout(resolve, 1600));
      navigateWithRibbon("/cart");
    } catch (requestError) {
      setDeliveryJourney("idle");
      setCartError(
        requestError.response?.data?.message ||
          requestError.message ||
          (isEditingCartHamper
            ? "Unable to save custom hamper changes"
            : "Unable to add custom hamper to cart")
      );
    } finally {
      setAddingToCart(false);
    }
  };

  const handleRequestQuotation = async () => {
    if (!user) {
      navigateWithRibbon("/login");
      return;
    }

    if (
      !containerId ||
      selectedItems.length === 0 ||
      !configuration?.orderable
    ) {
      setCartError(
        "Choose at least one hamper item and make sure the hamper is Ready before requesting a quotation."
      );
      return;
    }

    const parsedQuantity = Number(bulkQuantity);

    if (
      !Number.isInteger(parsedQuantity) ||
      parsedQuantity < 1 ||
      parsedQuantity > 100000
    ) {
      setCartError("Enter a valid bulk quantity between 1 and 100000.");
      return;
    }

    if (!bulkRequiredDate) {
      setCartError("Choose the date by which you need the bulk order.");
      return;
    }

    const deliveryLocations = bulkDeliveryLocations
      .split(/[\n,]/)
      .map((value) => value.trim())
      .filter(Boolean)
      .slice(0, 100);

    setRequestingQuote(true);
    setCartError("");

    try {
      const response = await api.post("/rfqs/custom-hamper", {
        containerId,
        items: selectedItems,
        decorations: selectedDecorations,
        channel,
        personalization: personalizationPayload,
        quantity: parsedQuantity,
        purpose: bulkPurpose,
        companyName: bulkCompanyName.trim(),
        gstNumber: bulkGstNumber.trim(),
        requiredDeliveryDate: bulkRequiredDate,
        addressModel: bulkAddressModel,
        deliveryLocations,
        notes: bulkNotes.trim(),
      });

      const rfqId = response.data?.rfq?._id;

      if (!rfqId) {
        throw new Error("RFQ was created but its ID was not returned.");
      }

      navigateWithRibbon(`/account/corporate/rfqs/${rfqId}`);
    } catch (requestError) {
      setCartError(
        requestError.response?.data?.message ||
          requestError.message ||
          "Unable to submit quotation request"
      );
    } finally {
      setRequestingQuote(false);
    }
  };

  if (loading || editLoading) {
    return <CustomHamperSkeleton />;
  }

  const canAddToCart =
    Boolean(containerId) &&
    selectedItems.length > 0 &&
    Boolean(configuration?.orderable) &&
    !validating &&
    !selectionPending &&
    !addingToCart;

  const canRequestQuote =
    Boolean(containerId) &&
    selectedItems.length > 0 &&
    Boolean(configuration?.orderable) &&
    Boolean(bulkRequiredDate) &&
    Number.isInteger(Number(bulkQuantity)) &&
    Number(bulkQuantity) >= 1 &&
    Number(bulkQuantity) <= 100000 &&
    !validating &&
    !selectionPending &&
    !requestingQuote;

  const canPrimaryAction =
    orderMode === "bulk" ? canRequestQuote : canAddToCart;

  const primaryBusy =
    orderMode === "bulk" ? requestingQuote : addingToCart;

  const currentBuilderStep =
    !containerId
      ? 1
      : selectedItems.length === 0
        ? 2
        : selectedDecorationCount === 0 && !personalizationPayload
          ? 3
          : !personalizationPayload
            ? 4
            : 5;

  const moveMobileStep = (nextStep) => {
    const safeStep = Math.min(5, Math.max(1, Number(nextStep) || 1));

    if (safeStep === mobileStep) return;

    runHamporiumUiTransition(() => {
      setMobileStep(safeStep);
      setCartError("");

      if (typeof window !== "undefined") {
        window.requestAnimationFrame(() => {
          mobileFlowRef.current?.scrollIntoView({
            behavior: "auto",
            block: "start",
          });
        });
      }
    });
  };

  // A data-pending imported box may still be selected to browse the Excel
  // gift catalogue. Order/cart actions remain blocked by configuration.orderable.
  const canContinueFromBox = Boolean(containerId) && !validating;

  const canContinueFromProducts =
    selectedItemCount > 0 && !validating && !selectionPending;

  return (
    <main
      className="hamporium-mobile-builder min-h-screen bg-[#FAF8F4] pb-14 pt-[84px] text-[14px] text-[#171717] sm:pt-[92px] sm:text-[14px]"
      style={{ fontFamily: "'Manrope', Arial, sans-serif" }}
    >
      <style>{`
        @keyframes v7Rise {
          from { opacity: 0; transform: translateY(14px); }
          to { opacity: 1; transform: translateY(0); }
        }

        @keyframes v7Glow {
          0%, 100% { opacity: .2; transform: translateX(-50%) scale(.95); }
          50% { opacity: .38; transform: translateX(-50%) scale(1.04); }
        }

        @keyframes v7Spark {
          0%, 100% { opacity: .18; transform: translateY(0) rotate(0deg) scale(.9); }
          50% { opacity: .8; transform: translateY(-5px) rotate(12deg) scale(1.12); }
        }

        @keyframes v7DecorationPop {
          from { opacity: 0; transform: scale(.65) rotate(-7deg); }
          to { opacity: 1; transform: scale(1) rotate(0deg); }
        }

        @keyframes v9SvgDrop {
          0% { opacity: 0; transform: translateY(-150px) scale(.72) rotate(-7deg); }
          58% { opacity: 1; transform: translateY(10px) scale(1.04) rotate(2deg); }
          76% { transform: translateY(-4px) scale(.985) rotate(-1deg); }
          100% { opacity: 1; transform: translateY(0) scale(1) rotate(var(--v9-turn)); }
        }

        @keyframes v9BoxPop {
          from { opacity: .35; transform: translateY(10px) scale(.96); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }

        @keyframes v9LidClose {
          0% { opacity: 0; transform: translateY(-28px) scale(.96); }
          56% { opacity: 1; transform: translateY(6px) scale(1.012); }
          100% { opacity: 1; transform: translateY(0) scale(1); }
        }

        .v7-reveal { animation: v7Rise .45s cubic-bezier(.2,.75,.2,1) both; }
        .v7-glow { animation: v7Glow 3.6s ease-in-out infinite; }
        .v7-spark { animation: v7Spark 2.8s ease-in-out infinite; }
        .v7-decoration { animation: v7DecorationPop .36s ease-out both; }

        .v9-svg-box {
          transform-origin: 50% 56%;
          animation: v9BoxPop .45s cubic-bezier(.2,.76,.2,1) both;
        }

        .v9-lid-close {
          transform-origin: 50% 50%;
          animation: v9LidClose .66s cubic-bezier(.2,.76,.2,1) both;
        }

        .v9-svg-item {
          transform-box: fill-box;
          transform-origin: center bottom;
          animation: v9SvgDrop .74s cubic-bezier(.18,.78,.2,1) both;
          will-change: transform, opacity;
        }

        /* =====================================================
           REAL-TIME PACKING STUDIO
        ====================================================== */
        @keyframes v20BoxArrive {
          0% { opacity: 0; transform: translateX(-50%) translateY(24px) scale(.91); }
          64% { opacity: 1; transform: translateX(-50%) translateY(-3px) scale(1.018); }
          100% { opacity: 1; transform: translateX(-50%) translateY(0) scale(1); }
        }

        @keyframes v20LidOpen {
          0% { opacity: .45; transform: perspective(820px) rotateX(10deg) translateY(64%) scale(.96); }
          60% { opacity: 1; transform: perspective(820px) rotateX(78deg) translateY(-10%) scale(1.01); }
          100% { opacity: 1; transform: perspective(820px) rotateX(74deg) translateY(-6%) scale(1); }
        }

        @keyframes v20LidClose {
          0% { transform: perspective(820px) rotateX(74deg) translateY(-6%) scale(1); }
          60% { transform: perspective(820px) rotateX(8deg) translateY(52%) scale(.972); }
          100% { transform: perspective(820px) rotateX(0deg) translateY(58%) scale(.978); }
        }

        @keyframes v20ItemDrop {
          0% {
            opacity: 0;
            transform: translate(-50%, -290px) rotate(calc(var(--v20-rotate) - 13deg)) scale(.72);
            filter: blur(2px);
          }
          52% { opacity: 1; filter: blur(0); }
          72% { transform: translate(-50%, -42%) rotate(calc(var(--v20-rotate) + 2deg)) scale(var(--v20-scale)); }
          86% { transform: translate(-50%, -56%) rotate(calc(var(--v20-rotate) - 1deg)) scale(var(--v20-scale)); }
          100% {
            opacity: 1;
            transform: translate(-50%, -50%) rotate(var(--v20-rotate)) scale(var(--v20-scale));
            filter: blur(0);
          }
        }

        @keyframes v20ItemExit {
          0% { opacity: 1; transform: translate(-50%, -50%) rotate(var(--v20-rotate)) scale(var(--v20-scale)); }
          100% { opacity: 0; transform: translate(-50%, -96%) rotate(calc(var(--v20-rotate) + 8deg)) scale(.68); }
        }

        @keyframes v20ItemPulse {
          0%, 100% { box-shadow: 0 8px 18px rgba(33,22,10,.18); }
          50% { box-shadow: 0 12px 28px rgba(244,120,34,.24); }
        }

        @keyframes v20PackingToast {
          0% { opacity: 0; transform: translate(-50%, -7px) scale(.96); }
          14%, 78% { opacity: 1; transform: translate(-50%, 0) scale(1); }
          100% { opacity: 0; transform: translate(-50%, 5px) scale(.985); }
        }

        @keyframes v20FillerFloat {
          0%, 100% { transform: translateY(0) rotate(var(--v20-filler-turn)); }
          50% { transform: translateY(-3px) rotate(var(--v20-filler-turn)); }
        }

        @keyframes v20RibbonSettle {
          0% { opacity: 0; transform: scaleX(.2); }
          100% { opacity: 1; transform: scaleX(1); }
        }

        @keyframes v20PackedGlow {
          0%, 100% { opacity: .45; transform: translateX(-50%) scale(.94); }
          50% { opacity: .78; transform: translateX(-50%) scale(1.04); }
        }

        .v20-live-stage {
          position: relative;
          isolation: isolate;
          min-height: 432px;
          overflow: hidden;
          border: 1px solid rgba(96,68,32,.08);
          border-radius: 24px;
          background:
            radial-gradient(circle at 50% 4%, rgba(255,255,255,.98), transparent 26%),
            radial-gradient(circle at 50% 72%, rgba(255,219,158,.22), transparent 40%),
            linear-gradient(180deg, #FFFDFB 0%, #F7EFE6 54%, #E8D9C8 100%);
          box-shadow: inset 0 1px 0 rgba(255,255,255,.86), inset 0 -1px 0 rgba(112,73,26,.05), 0 16px 36px rgba(42,31,19,.06);
        }

        .v20-live-stage::before {
          content: "";
          position: absolute;
          inset: 0;
          pointer-events: none;
          opacity: .24;
          background-image: radial-gradient(rgba(99,70,38,.13) .55px, transparent .55px);
          background-size: 8px 8px;
          mask-image: linear-gradient(to bottom, transparent, black 22%, black 84%, transparent);
        }

        .v20-live-stage::after {
          content: "";
          position: absolute;
          z-index: 0;
          left: 50%;
          bottom: 6px;
          width: 82%;
          height: 56px;
          transform: translateX(-50%);
          border-radius: 999px;
          background: rgba(78,48,21,.18);
          filter: blur(22px);
        }

        .v20-studio-grid {
          position: absolute;
          inset: 0;
          z-index: 0;
          pointer-events: none;
          opacity: .18;
          background-image:
            linear-gradient(rgba(116,84,46,.10) 1px, transparent 1px),
            linear-gradient(90deg, rgba(116,84,46,.10) 1px, transparent 1px);
          background-size: 34px 34px;
          mask-image: linear-gradient(to bottom, transparent 18%, black 54%, transparent 94%);
          transform: perspective(420px) rotateX(64deg) scale(1.5) translateY(28%);
          transform-origin: center bottom;
        }

        .v20-box-world {
          --v20-box-main: #D9A969;
          --v20-box-light: #F3D7AE;
          --v20-box-dark: #8E5A2C;
          --v20-box-deep: #563018;
          position: absolute;
          z-index: 12;
          left: 50%;
          bottom: 0;
          width: min(100%, 640px);
          height: 362px;
          transform: translateX(-50%);
          perspective: 1200px;
          transform-style: preserve-3d;
          animation: v20BoxArrive .68s cubic-bezier(.18,.78,.2,1) both;
          will-change: transform, opacity;
        }

        .v20-box-glow {
          position: absolute;
          z-index: 0;
          left: 50%;
          bottom: 8px;
          width: 94%;
          height: 44%;
          transform: translateX(-50%);
          border-radius: 999px;
          background: radial-gradient(circle, rgba(244,120,34,.18), rgba(212,175,55,.14) 42%, transparent 74%);
          filter: blur(30px);
        }

        .v20-box-floor {
          position: absolute;
          z-index: 1;
          left: 8%;
          right: 8%;
          bottom: 16px;
          height: 18px;
          border-radius: 999px;
          background: linear-gradient(180deg, rgba(255,251,240,.55), rgba(120,86,44,.08));
          box-shadow: inset 0 1px 0 rgba(255,255,255,.6);
        }

        .v20-box-base-shadow {
          position: absolute;
          z-index: 2;
          left: 14%;
          right: 14%;
          bottom: 26px;
          height: 28px;
          border-radius: 999px;
          background: rgba(52,29,8,.20);
          filter: blur(18px);
        }

        .v20-box-base {
          position: absolute;
          z-index: 3;
          left: 16.5%;
          right: 16.5%;
          bottom: 24px;
          height: 12px;
          border: 1px solid rgba(89,57,20,.18);
          border-radius: 0 0 12px 12px;
          background: linear-gradient(180deg, rgba(255,245,222,.56), rgba(183,136,61,.42));
          box-shadow: 0 8px 14px rgba(56,34,12,.10);
        }

        .v20-box-lid {
          position: absolute;
          z-index: 8;
          left: 11%;
          top: 5%;
          width: 78%;
          height: 31%;
          transform-origin: 50% 100%;
          transform-style: preserve-3d;
          animation: v20LidOpen .86s cubic-bezier(.16,.82,.22,1) both;
        }

        .v20-box-lid.is-packed { z-index: 56; animation: v20LidClose .82s cubic-bezier(.2,.75,.2,1) both; }

        .v20-box-lid-face {
          position: absolute;
          inset: 0;
          overflow: hidden;
          border: 1px solid rgba(77,45,20,.24);
          border-radius: 18px 18px 10px 10px;
          background:
            linear-gradient(180deg, rgba(255,255,255,.26), transparent 24%),
            linear-gradient(145deg, var(--v20-box-light) 0%, color-mix(in srgb, var(--v20-box-main) 88%, white 12%) 36%, var(--v20-box-main) 62%, var(--v20-box-dark) 100%);
          box-shadow: 0 14px 26px rgba(48,28,12,.22), inset 0 1px 0 rgba(255,255,255,.42), inset 0 -10px 18px rgba(77,40,12,.14);
        }

        .v20-box-lid-face::before {
          content: "";
          position: absolute;
          inset: 10px;
          border: 1px solid rgba(255,247,224,.38);
          border-radius: 11px;
          pointer-events: none;
        }

        .v20-box-lid-face::after {
          content: "";
          position: absolute;
          left: 12%;
          right: 12%;
          bottom: 8px;
          height: 12px;
          border-radius: 999px;
          background: linear-gradient(180deg, rgba(117,73,26,.04), rgba(70,42,16,.18));
          filter: blur(5px);
        }

        .v20-box-lid-photo { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; opacity: .13; mix-blend-mode: multiply; filter: saturate(.72) contrast(.92); }
        .v20-box-monogram { position: absolute; z-index: 2; left: 50%; top: 50%; display: flex; width: 68px; height: 68px; align-items: center; justify-content: center; transform: translate(-50%, -50%); border: 1px solid rgba(255,240,191,.56); border-radius: 999px; color: #FFF2C8; background: radial-gradient(circle at 30% 25%, rgba(255,252,235,.4), rgba(102,58,23,.2)); box-shadow: inset 0 0 0 7px rgba(255,255,255,.05), 0 10px 24px rgba(60,34,11,.18); font-family: 'Cormorant Garamond', Georgia, serif; font-size: 34px; font-weight: 700; text-shadow: 0 2px 8px rgba(0,0,0,.22); backdrop-filter: blur(2px); }
        .v20-box-back { position: absolute; z-index: 10; left: 17%; right: 17%; top: 29%; height: 21%; border: 1px solid rgba(70,39,16,.18); border-radius: 10px 10px 0 0; background: linear-gradient(180deg, color-mix(in srgb, var(--v20-box-main) 92%, white 8%), var(--v20-box-dark)); box-shadow: inset 0 10px 18px rgba(255,255,255,.10); }
        .v20-box-well { position: absolute; z-index: 12; left: 18%; right: 18%; top: 42%; height: 31%; overflow: hidden; border-radius: 10px 10px 18px 18px; background: radial-gradient(circle at 50% 62%, rgba(232,205,152,.24), transparent 38%), linear-gradient(180deg, #6A4225, #2C180D 82%); box-shadow: inset 0 20px 28px rgba(0,0,0,.34), inset 0 -8px 18px rgba(255,221,154,.08); }
        .v20-box-well::before { content: ""; position: absolute; inset: 7px 8px auto; height: 16px; border-radius: 10px; background: linear-gradient(180deg, rgba(255,237,205,.14), transparent); }
        .v20-box-well::after {
          content: "";
          position: absolute;
          inset: 2px 2px auto;
          height: 8px;
          border-radius: 10px;
          border-top: 1px solid rgba(255,229,177,.22);
          box-shadow: inset 0 3px 5px rgba(255,255,255,.04);
        }
        .v20-box-inner-left, .v20-box-inner-right {
          position: absolute;
          z-index: 18;
          top: 43%;
          width: 7.5%;
          height: 28%;
          border: 1px solid rgba(77,45,20,.14);
          background: linear-gradient(180deg, rgba(235,199,133,.72), rgba(118,72,28,.92));
          box-shadow: inset 0 1px 0 rgba(255,255,255,.14);
          opacity: .82;
        }
        .v20-box-inner-left { left: 18.2%; border-radius: 9px 0 0 12px; transform: skewY(5deg); }
        .v20-box-inner-right { right: 18.2%; border-radius: 0 9px 12px 0; transform: skewY(-5deg); }
        .v20-filler { position: absolute; z-index: 16; left: 21%; right: 21%; top: 58%; height: 12%; overflow: hidden; opacity: .9; }
        .v20-filler span { position: absolute; bottom: 0; width: 28px; height: 6px; border-radius: 999px; background: linear-gradient(90deg, #C59654, #E8C982, #9B6B31); box-shadow: 0 2px 3px rgba(0,0,0,.12); animation: v20FillerFloat 2.8s ease-in-out infinite; }
        .v20-item-layer { position: absolute; z-index: 24; inset: 0; pointer-events: none; }
        .v20-pack-item { position: absolute; transform: translate(-50%, -50%) rotate(var(--v20-rotate)) scale(var(--v20-scale)); transform-origin: center bottom; will-change: transform, opacity; }
        .v20-pack-item.is-entering { animation: v20ItemDrop .82s cubic-bezier(.17,.78,.2,1.08) both; }
        .v20-pack-item.is-exiting { animation: v20ItemExit .34s cubic-bezier(.45,0,.8,.4) both; }
        .v20-pack-card { position: relative; width: 100%; height: 100%; overflow: hidden; border: 1px solid rgba(61,39,20,.18); border-radius: 10px; background: linear-gradient(145deg, #FFFDF9, #EEDCC6); box-shadow: 0 10px 18px rgba(36,22,10,.24), inset 0 1px 0 rgba(255,255,255,.72); animation: v20ItemPulse 2.8s ease-in-out infinite; }
        .v20-kind-bottle .v20-pack-card { border-radius: 13px 13px 9px 9px; }
        .v20-kind-cylinder .v20-pack-card { border-radius: 18px 18px 10px 10px; }
        .v20-kind-flat .v20-pack-card { border-radius: 7px; }
        .v20-pack-image { width: 100%; height: 100%; object-fit: contain; padding: 4px; background: rgba(255,255,255,.92); }
        .v20-pack-fallback { display: flex; width: 100%; height: 100%; align-items: center; justify-content: center; color: #8A631C; background: radial-gradient(circle at 30% 22%, rgba(255,255,255,.7), transparent 34%), linear-gradient(145deg, #F6E5C9, #C99449); font-family: 'Cormorant Garamond', Georgia, serif; font-size: 22px; font-weight: 700; }
        .v20-pack-label { position: absolute; left: 4px; right: 4px; bottom: 4px; overflow: hidden; padding: 2px 4px; border-radius: 5px; color: rgba(255,255,255,.94); background: rgba(22,17,12,.70); font-size: 5.5px; font-weight: 800; line-height: 1.1; text-align: center; text-overflow: ellipsis; white-space: nowrap; backdrop-filter: blur(3px); }
        .v20-box-left, .v20-box-right, .v20-box-front {
          position: absolute;
          z-index: 42;
          pointer-events: none;
          border: 1px solid rgba(69,38,16,.18);
          background: linear-gradient(180deg, var(--v20-box-main), var(--v20-box-dark));
          box-shadow: inset 0 1px 0 rgba(255,255,255,.18);
        }

        /* V41: fixed rigid-box side walls — no outward gate/flap look */
        .v20-box-left {
          left: 17.2%;
          top: 46%;
          width: 7.8%;
          height: 25%;
          border-radius: 12px 2px 2px 14px;
          transform: skewY(4deg);
          background:
            linear-gradient(90deg, rgba(255,255,255,.14), transparent 32%),
            linear-gradient(180deg, color-mix(in srgb, var(--v20-box-main) 93%, white 7%), var(--v20-box-deep));
          box-shadow: inset 1px 0 0 rgba(255,255,255,.16), 3px 6px 10px rgba(58,34,10,.08);
        }

        .v20-box-right {
          right: 17.2%;
          top: 46%;
          width: 7.8%;
          height: 25%;
          border-radius: 2px 12px 14px 2px;
          transform: skewY(-4deg);
          background:
            linear-gradient(270deg, rgba(255,255,255,.14), transparent 32%),
            linear-gradient(180deg, color-mix(in srgb, var(--v20-box-main) 93%, white 7%), var(--v20-box-deep));
          box-shadow: inset -1px 0 0 rgba(255,255,255,.16), -3px 6px 10px rgba(58,34,10,.08);
        }

        .v20-box-front {
          left: 20%;
          right: 20%;
          bottom: 8%;
          height: 23%;
          clip-path: polygon(0 4%, 100% 4%, 96% 100%, 4% 100%);
          border-radius: 5px 5px 14px 14px;
          background: linear-gradient(180deg, color-mix(in srgb, var(--v20-box-main) 90%, white 10%) 0%, var(--v20-box-dark) 76%, var(--v20-box-deep) 100%);
          box-shadow: 0 12px 18px rgba(49,28,10,.18), inset 0 1px 0 rgba(255,255,255,.24);
        }
        .v20-box-front::before {
          content: "";
          position: absolute;
          left: 12%;
          right: 12%;
          top: 8px;
          height: 1px;
          background: linear-gradient(90deg, transparent, rgba(255,247,224,.55), transparent);
        }
        .v20-box-front::after { content: "HAMPORIUM"; position: absolute; left: 50%; top: 56%; transform: translate(-50%, -50%); color: rgba(255,240,192,.88); font-size: 7.6px; font-weight: 900; letter-spacing: .22em; text-shadow: 0 2px 8px rgba(0,0,0,.16); }
        .v20-pack-ribbon-h, .v20-pack-ribbon-v { position: absolute; z-index: 63; pointer-events: none; background: linear-gradient(90deg, #9B6C11, #E8CB67 26%, #FFF0AD 50%, #D5A532 74%, #81530D); box-shadow: inset 0 1px 0 rgba(255,255,255,.34), 0 4px 10px rgba(43,26,5,.16); animation: v20RibbonSettle .48s cubic-bezier(.2,.8,.2,1) both; }
        .v20-pack-ribbon-h { left: 17%; right: 17%; top: 68%; height: 9px; transform-origin: center; }
        .v20-pack-ribbon-v { left: 50%; top: 41%; bottom: 5%; width: 9px; transform: translateX(-50%); background: linear-gradient(180deg, #FFF0AD, #D5A532 44%, #81530D); }
        .v20-packed-badge { position: absolute; z-index: 68; left: 50%; top: 63%; display: flex; min-width: 82px; height: 29px; align-items: center; justify-content: center; transform: translateX(-50%); border: 1px solid rgba(255,239,175,.54); border-radius: 999px; color: #FFF0B5; background: radial-gradient(circle at 35% 28%, #C99B33, #7F500D); box-shadow: 0 8px 16px rgba(42,24,4,.22), inset 0 1px 0 rgba(255,255,255,.26); font-size: 6.5px; font-weight: 900; letter-spacing: .10em; text-transform: uppercase; }
        .v20-packing-toast { position: absolute; z-index: 90; left: 50%; top: 43px; max-width: 76%; overflow: hidden; transform: translateX(-50%); border: 1px solid rgba(212,175,55,.25); border-radius: 999px; padding: 7px 12px; color: #5B4213; background: rgba(255,252,244,.94); box-shadow: 0 8px 24px rgba(44,29,11,.10); font-size: 7.5px; font-weight: 900; text-overflow: ellipsis; white-space: nowrap; backdrop-filter: blur(10px); animation: v20PackingToast 1.35s ease both; }
        .v20-packing-toast::before { content: ""; display: inline-block; width: 6px; height: 6px; margin-right: 7px; border-radius: 999px; background: #F47822; box-shadow: 0 0 0 4px rgba(244,120,34,.10); }
        .v20-empty-cue { position: absolute; z-index: 30; left: 50%; top: 50%; width: 58%; transform: translate(-50%, -50%); border: 1px dashed rgba(92,65,34,.20); border-radius: 14px; padding: 12px 14px; color: rgba(38,28,18,.40); background: rgba(255,255,255,.52); font-size: 8px; font-weight: 800; line-height: 1.5; text-align: center; backdrop-filter: blur(4px); }
        .v20-capacity-line { position: absolute; z-index: 80; left: 10px; right: 10px; bottom: 8px; display: flex; align-items: center; gap: 8px; }
        .v20-capacity-track { height: 4px; flex: 1; overflow: hidden; border-radius: 999px; background: rgba(77,50,25,.10); }
        .v20-capacity-fill { height: 100%; border-radius: inherit; background: linear-gradient(90deg, #F47822, #D4AF37); box-shadow: 0 0 14px rgba(244,120,34,.18); transition: width .72s cubic-bezier(.22,1,.36,1); }
        .v20-capacity-copy { width: 34px; flex: 0 0 auto; color: rgba(27,23,18,.46); font-size: 7px; font-weight: 900; text-align: right; }
        .v20-decor-band { position: absolute; z-index: 62; left: 18%; right: 18%; top: 68%; height: 8px; border-radius: 999px; background: linear-gradient(90deg, #875B0B, #EED576 48%, #875B0B); box-shadow: 0 3px 10px rgba(87,56,6,.20); animation: v20RibbonSettle .46s cubic-bezier(.2,.8,.2,1) both; }
        .v20-decor-band-v { position: absolute; z-index: 61; left: 50%; top: 45%; bottom: 7%; width: 8px; transform: translateX(-50%); border-radius: 999px; background: linear-gradient(180deg, #F7E9A8, #C39021 64%, #80520C); animation: v20RibbonSettle .46s cubic-bezier(.2,.8,.2,1) both; }
        .v20-packed-glow { position: absolute; z-index: 3; left: 50%; bottom: 6%; width: 72%; height: 32%; transform: translateX(-50%); border-radius: 999px; background: rgba(212,175,55,.18); filter: blur(28px); animation: v20PackedGlow 2.8s ease-in-out infinite; }

        @media (min-width: 1280px) {
          .v20-live-stage { min-height: 282px; }
          .v20-box-world { width: 95%; max-width: 540px; height: 292px; }
        }

        .v20-box-world.is-top-view.is-drop-intro {
          animation: v20BoxDropIn .84s cubic-bezier(.2,.9,.2,1.08) both;
        }
        .v20-box-world.is-top-view.is-drop-intro .v20-box-shell {
          animation: v20ShellLand .84s cubic-bezier(.2,.9,.2,1.08) both;
        }
        .v20-box-world.is-top-view.is-drop-intro .v20-box-lid--top {
          top: calc(var(--v20-shell-top) + 4%);
          transform: translateX(-50%) translateY(0) rotateX(0deg) scale(1.02);
          transition: none;
        }
        .v20-box-world.is-top-view.is-drop-intro .v20-box-fill,
        .v20-box-world.is-top-view.is-opening-intro .v20-box-fill {
          opacity: 0;
          transform: scale(.98);
        }
        .v20-box-world.is-top-view.is-opening-intro .v20-box-lid--top {
          animation: v20TopLidOpenIntro .92s cubic-bezier(.22,.86,.24,1) forwards;
        }
        .v20-box-world.is-top-view.is-opening-intro .v20-box-fill {
          animation: v20TopFillReveal .62s ease .18s forwards;
        }
        .v20-box-world.is-top-view.is-opening-intro .v20-box-orbit {
          animation-duration: 1.6s;
          opacity: 1;
        }
        .v20-box-world.is-top-view.is-opening-intro .v20-box-sparkles {
          animation: v20TopSparkBurst .9s ease-out;
        }
        @keyframes v20BoxDropIn {
          0% {
            opacity: 0;
            transform: translateX(-50%) translateY(-140px) scale(.88);
          }
          62% {
            opacity: 1;
            transform: translateX(-50%) translateY(10px) scale(1.02);
          }
          100% {
            opacity: 1;
            transform: translateX(-50%) translateY(0) scale(1);
          }
        }
        @keyframes v20ShellLand {
          0% {
            transform: translateX(-50%) scale(.94);
            filter: drop-shadow(0 28px 24px rgba(35,18,8,.18));
          }
          62% {
            transform: translateX(-50%) scale(1.01);
          }
          100% {
            transform: translateX(-50%) scale(1);
            filter: drop-shadow(0 0 0 rgba(35,18,8,0));
          }
        }
        @keyframes v20TopLidOpenIntro {
          0% {
            top: calc(var(--v20-shell-top) + 4%);
            transform: translateX(-50%) translateY(0) rotateX(0deg) scale(1.02);
          }
          55% {
            top: calc(var(--v20-shell-top) - 2%);
            transform: translateX(-50%) translateY(-8px) rotateX(7deg) scale(1.01);
          }
          100% {
            top: var(--v20-lid-top);
            transform: translateX(-50%) translateY(0) rotateX(10deg) scale(1);
          }
        }
        @keyframes v20TopFillReveal {
          0% {
            opacity: 0;
            transform: scale(.98);
          }
          100% {
            opacity: 1;
            transform: scale(1);
          }
        }
        @keyframes v20TopSparkBurst {
          0% { opacity: .18; transform: scale(.92); }
          45% { opacity: 1; transform: scale(1.04); }
          100% { opacity: 1; transform: scale(1); }
        }
        @media (max-width: 639px) {
          .v20-live-stage { min-height: 272px; }
          .v20-box-world { width: 100%; height: 244px; bottom: 2px; }
          .v20-box-monogram { width: 46px; height: 46px; font-size: 22px; }
          .v20-box-front::after { font-size: 6.4px; }
          .v20-pack-label { display: none; }
        }

        /* V45 · COUTURE LIVE HAMPER BOX */
        .v20-box-world.is-top-view {
          --v20-shell-width: 94%;
          --v20-shell-height: 66%;
          --v20-shell-top: 21%;
          --v20-shell-radius: 34px;
          --v20-lid-width: 90%;
          --v20-lid-height: 20%;
          --v20-lid-top: 3%;
          left: 50%;
          bottom: 4px;
          width: 100%;
          max-width: 760px;
          height: 408px;
          transform: translateX(-50%);
          perspective: 1400px;
        }
        .v20-box-world.is-top-view[data-box-shape="round"] {
          --v20-shell-width: 76%;
          --v20-shell-height: 72%;
          --v20-shell-top: 16%;
          --v20-shell-radius: 999px;
          --v20-lid-width: 72%;
          --v20-lid-height: 18%;
        }
        .v20-box-world.is-top-view[data-box-shape="tray"] {
          --v20-shell-width: 96%;
          --v20-shell-height: 60%;
          --v20-shell-top: 24%;
          --v20-shell-radius: 24px;
          --v20-lid-width: 92%;
          --v20-lid-height: 16%;
        }
        .v20-box-world.is-top-view[data-box-shape="curved"] {
          --v20-shell-radius: 50px;
        }
        .v20-box-world.is-top-view .v20-box-base,
        .v20-box-world.is-top-view .v20-box-back,
        .v20-box-world.is-top-view .v20-box-inner-left,
        .v20-box-world.is-top-view .v20-box-inner-right,
        .v20-box-world.is-top-view .v20-box-left,
        .v20-box-world.is-top-view .v20-box-right,
        .v20-box-world.is-top-view .v20-box-front {
          display: none;
        }
        .v20-box-pedestal {
          position: absolute;
          left: 50%;
          bottom: 10px;
          width: 94%;
          height: 84px;
          transform: translateX(-50%);
          border-radius: 999px;
          background:
            radial-gradient(circle at 50% 18%, rgba(255,255,255,.84), transparent 42%),
            linear-gradient(180deg, rgba(255,251,244,.98), rgba(233,219,201,.88));
          box-shadow: inset 0 1px 0 rgba(255,255,255,.94), 0 20px 42px rgba(60,38,16,.09);
          z-index: 1;
        }
        .v20-box-pedestal::before {
          content: "";
          position: absolute;
          inset: 12px 24px;
          border-radius: inherit;
          border: 1px solid rgba(212,175,55,.18);
          background: linear-gradient(180deg, rgba(255,255,255,.22), rgba(255,255,255,0));
        }
        .v20-box-sparkles {
          position: absolute;
          inset: 0;
          z-index: 4;
          pointer-events: none;
        }
        .v20-box-spark {
          position: absolute;
          width: 14px;
          height: 14px;
          transform: rotate(45deg);
          border-radius: 2px;
          background: linear-gradient(180deg, rgba(255,251,235,.95), rgba(212,175,55,.85));
          box-shadow: 0 0 0 3px rgba(255,245,214,.15), 0 0 20px rgba(244,188,72,.28);
          animation: v20SparkPulse 2.8s ease-in-out infinite;
        }
        .v20-box-spark::before,
        .v20-box-spark::after {
          content: "";
          position: absolute;
          left: 50%;
          top: 50%;
          background: inherit;
          transform: translate(-50%, -50%);
          border-radius: 999px;
        }
        .v20-box-spark::before { width: 2px; height: 22px; }
        .v20-box-spark::after { width: 22px; height: 2px; }
        .v20-box-spark--1 { left: 14%; top: 13%; animation-delay: 0s; }
        .v20-box-spark--2 { right: 16%; top: 20%; animation-delay: .7s; }
        .v20-box-spark--3 { left: 20%; bottom: 24%; animation-delay: 1.4s; }
        .v20-box-spark--4 { right: 19%; bottom: 31%; animation-delay: 2.1s; }

        .v20-box-world.is-top-view .v20-box-lid--top {
          left: 50%;
          top: var(--v20-lid-top);
          width: var(--v20-lid-width);
          height: var(--v20-lid-height);
          transform: translateX(-50%) translateY(0) rotateX(12deg);
          z-index: 10;
          animation: none;
        }
        .v20-box-world.is-top-view .v20-box-lid--top.is-packed { animation: none; }
        .v20-box-world.is-top-view[data-box-shape="round"] .v20-box-lid-face {
          border-radius: 999px;
        }
        .v20-box-shell {
          position: absolute;
          left: 50%;
          top: var(--v20-shell-top);
          width: var(--v20-shell-width);
          height: var(--v20-shell-height);
          transform: translateX(-50%);
          border-radius: var(--v20-shell-radius);
          background:
            radial-gradient(circle at 50% 6%, rgba(255,255,255,.24), transparent 26%),
            linear-gradient(180deg, color-mix(in srgb, var(--v20-box-light) 46%, white 54%) 0%, color-mix(in srgb, var(--v20-box-main) 82%, white 18%) 16%, color-mix(in srgb, var(--v20-box-main) 92%, black 8%) 72%, color-mix(in srgb, var(--v20-box-dark) 90%, black 10%) 100%);
          border: 1px solid rgba(77,45,20,.22);
          box-shadow: 0 38px 54px rgba(52,31,12,.18), 0 12px 22px rgba(52,31,12,.10), inset 0 1px 0 rgba(255,255,255,.34), inset 0 -18px 20px rgba(95,61,22,.18);
          overflow: visible;
          z-index: 8;
        }
        .v20-box-shell::before {
          content: "";
          position: absolute;
          inset: 10px;
          border-radius: calc(var(--v20-shell-radius) - 10px);
          border: 1px solid rgba(255,244,218,.28);
          background: linear-gradient(180deg, rgba(255,255,255,.12), transparent 18%, transparent 78%, rgba(255,244,212,.08));
          pointer-events: none;
        }
        .v20-box-shell::after {
          content: "";
          position: absolute;
          left: 50%;
          bottom: -16px;
          width: 74%;
          height: 26px;
          transform: translateX(-50%);
          border-radius: 999px;
          background: radial-gradient(circle, rgba(53,28,10,.22), rgba(53,28,10,0) 70%);
          filter: blur(8px);
          pointer-events: none;
        }
        .v20-box-world.is-top-view[data-box-shape="round"] .v20-box-shell {
          border-radius: 50% / 40%;
        }
        .v20-box-rim {
          position: absolute;
          inset: 12px;
          border-radius: calc(var(--v20-shell-radius) - 12px);
          background: linear-gradient(180deg, rgba(255,250,236,.24), rgba(116,73,26,.18));
          border: 1px solid rgba(255,244,218,.34);
          box-shadow: inset 0 2px 0 rgba(255,255,255,.26), inset 0 -2px 0 rgba(88,54,22,.16);
        }
        .v20-box-world.is-top-view[data-box-shape="round"] .v20-box-rim,
        .v20-box-world.is-top-view[data-box-shape="round"] .v20-box-fill,
        .v20-box-world.is-top-view[data-box-shape="round"] .v20-box-well {
          border-radius: 50% / 42%;
        }
        .v20-box-fill {
          position: absolute;
          inset: 24px 24px 30px;
          overflow: hidden;
          border-radius: calc(var(--v20-shell-radius) - 18px);
          background: linear-gradient(180deg, rgba(255,255,255,.06), rgba(255,255,255,0));
        }
        .v20-box-fill::before {
          content: "";
          position: absolute;
          inset: 0;
          background:
            radial-gradient(circle at 24% 26%, rgba(255,239,210,.11), transparent 22%),
            radial-gradient(circle at 72% 36%, rgba(255,227,176,.1), transparent 20%),
            linear-gradient(180deg, rgba(255,255,255,.02), rgba(0,0,0,0));
          pointer-events: none;
        }
        .v20-box-world.is-top-view .v20-box-well {
          position: absolute;
          inset: 0;
          height: auto;
          border-radius: inherit;
          background:
            radial-gradient(circle at 50% 16%, rgba(255,240,205,.22), transparent 18%),
            linear-gradient(180deg, #6F4020 0%, #4B2612 58%, #30160A 100%);
          box-shadow: inset 0 24px 44px rgba(0,0,0,.24), inset 0 -12px 18px rgba(255,227,168,.08), inset 0 0 0 1px rgba(255,239,206,.05);
        }
        .v20-box-world.is-top-view .v20-filler {
          left: 8%;
          right: 8%;
          top: auto;
          bottom: 10%;
          height: 22%;
          z-index: 18;
        }
        .v20-box-world.is-top-view .v20-item-layer {
          position: absolute;
          inset: 8% 7% 13%;
          overflow: hidden;
          z-index: 24;
          border-radius: inherit;
        }
        .v20-box-world.is-top-view .v20-item-layer::before {
          content: "";
          position: absolute;
          inset: 10% 8% 8%;
          border-radius: inherit;
          background: radial-gradient(circle at 50% 20%, rgba(255,255,255,.08), rgba(255,255,255,0) 52%);
          pointer-events: none;
        }
        .v20-box-world.is-top-view .v20-pack-item {
          filter: drop-shadow(0 12px 16px rgba(0,0,0,.18));
        }
        .v20-box-world.is-top-view .v20-pack-card {
          border-radius: 16px;
          background: linear-gradient(145deg, #fffefd, #f3e7d5);
          box-shadow: 0 12px 18px rgba(36,22,10,.2), inset 0 1px 0 rgba(255,255,255,.86);
          animation: none;
        }
        .v20-box-world.is-top-view .v20-pack-image {
          padding: 6px;
          object-fit: cover;
        }
        .v20-box-world.is-top-view .v20-pack-label {
          display: none;
        }
        .v20-box-front-badge {
          position: absolute;
          left: 50%;
          bottom: 14px;
          transform: translateX(-50%);
          padding: 10px 22px;
          border-radius: 999px;
          border: 1px solid rgba(255,244,219,.26);
          color: rgba(255,241,204,.97);
          background: linear-gradient(180deg, rgba(255,255,255,.12), rgba(0,0,0,.12));
          font-size: 11px;
          font-weight: 900;
          letter-spacing: .22em;
          text-transform: uppercase;
          box-shadow: 0 10px 20px rgba(40,22,8,.16);
          z-index: 35;
        }
        .v20-box-world.is-top-view .v20-pack-ribbon-h {
          left: 16%;
          right: 16%;
          top: calc(var(--v20-shell-top) + 54%);
          height: 12px;
          z-index: 60;
        }
        .v20-box-world.is-top-view .v20-pack-ribbon-v {
          left: 50%;
          top: calc(var(--v20-shell-top) + 4%);
          bottom: 12%;
          width: 12px;
          z-index: 59;
        }
        .v20-box-world.is-top-view .v20-packed-badge {
          top: calc(var(--v20-shell-top) + 40%);
          z-index: 61;
        }
        @media (max-width: 639px) {
          .v20-live-stage {
            min-height: 336px;
            border-radius: 18px;
          }
          .v20-box-pedestal {
            width: 96%;
            height: 60px;
            bottom: 12px;
          }
          .v20-box-world.is-top-view {
            height: 336px;
            --v20-shell-width: 98%;
            --v20-shell-height: 64%;
            --v20-shell-top: 22%;
            --v20-lid-width: 94%;
            --v20-lid-height: 20%;
            --v20-lid-top: 4%;
          }
          .v20-box-world.is-top-view[data-box-shape="round"] {
            --v20-shell-width: 80%;
            --v20-shell-height: 70%;
            --v20-shell-top: 18%;
            --v20-lid-width: 76%;
          }
          .v20-box-world.is-top-view .v20-box-front-badge {
            font-size: 9px;
            letter-spacing: .14em;
            padding: 7px 14px;
          }
          .v20-box-monogram {
            width: 54px;
            height: 54px;
            font-size: 28px;
          }
        }

        @keyframes v20CinematicPulse {
          0%, 100% { opacity: .55; transform: translateX(-50%) scale(.98); }
          50% { opacity: .92; transform: translateX(-50%) scale(1.04); }
        }
        @keyframes v20BoxSheen {
          0% { transform: translateX(-120%) rotate(10deg); opacity: 0; }
          30% { opacity: .16; }
          100% { transform: translateX(150%) rotate(10deg); opacity: 0; }
        }
        @keyframes v20SparkPulse {
          0%, 100% { opacity: .32; transform: rotate(45deg) scale(.68); }
          50% { opacity: 1; transform: rotate(45deg) scale(1); }
        }
        @keyframes v20ShipAway {
          0% { transform: translateX(-50%) translateY(0) scale(1); opacity: 1; }
          16% { transform: translateX(-48%) translateY(-3px) scale(1.01); }
          100% { transform: translateX(88%) translateY(-12px) scale(.96); opacity: .08; }
        }
        @keyframes v20TrailMove {
          0% { opacity: 0; transform: translateX(-10px); }
          25% { opacity: .92; }
          100% { opacity: 0; transform: translateX(48px); }
        }
        .v20-cinematic-halo {
          position: absolute;
          left: 50%;
          top: 8%;
          width: 84%;
          height: 58%;
          transform: translateX(-50%);
          border-radius: 999px;
          background: radial-gradient(circle, rgba(255,214,127,.3), rgba(255,214,127,.1) 44%, transparent 72%);
          filter: blur(22px);
          animation: v20CinematicPulse 3.4s ease-in-out infinite;
        }
        .v20-box-world.is-top-view .v20-box-lid-face {
          box-shadow: 0 22px 34px rgba(75,44,15,.2), inset 0 1px 0 rgba(255,255,255,.36), inset 0 -12px 20px rgba(112,71,17,.24);
          background: linear-gradient(180deg, rgba(255,247,217,.24), transparent 26%), linear-gradient(155deg, color-mix(in srgb, var(--v20-box-main) 74%, white 26%), color-mix(in srgb, var(--v20-box-dark) 82%, black 18%));
        }
        .v20-box-world.is-top-view .v20-box-lid-face::before {
          inset: 12px;
          border-radius: 16px;
          border-color: rgba(255,247,224,.34);
        }
        .v20-box-world.is-top-view .v20-box-lid-face::after {
          left: 10%;
          right: 10%;
          bottom: 10px;
          height: 16px;
          background: linear-gradient(180deg, rgba(117,73,26,.03), rgba(70,42,16,.18));
          filter: blur(7px);
        }
        .v20-box-world.is-top-view .v20-box-lid-face::selection { background: transparent; }
        .v20-box-world.is-top-view .v20-box-lid--top::after {
          content: "";
          position: absolute;
          top: 6%;
          bottom: 12%;
          left: -24%;
          width: 26%;
          background: linear-gradient(90deg, transparent, rgba(255,255,255,.18), transparent);
          transform: skewX(-18deg);
          animation: v20BoxSheen 5.6s linear infinite;
          pointer-events: none;
          z-index: 3;
        }
        .v20-box-world.is-top-view .v20-box-lid--top.is-packed {
          top: calc(var(--v20-shell-top) + 7%);
          transform: translateX(-50%) rotateX(0deg) scale(1.01);
          transition: top .72s cubic-bezier(.2,.84,.2,1), transform .72s cubic-bezier(.2,.84,.2,1);
        }
        .v20-box-world.is-top-view.is-sealed .v20-box-fill {
          opacity: .08;
          transform: scale(.98);
          transition: opacity .55s ease, transform .55s ease;
        }
        .v20-box-world.is-top-view.is-sealed .v20-box-sparkles {
          opacity: .4;
        }
        .v20-box-world.is-top-view.is-shipping {
          animation: v20ShipAway 1.45s cubic-bezier(.3,.75,.18,1) forwards;
        }
        .v20-delivery-trail {
          position: absolute;
          left: 8%;
          bottom: 19%;
          width: 82px;
          height: 12px;
          border-radius: 999px;
          background: linear-gradient(90deg, rgba(255,255,255,0), rgba(255,196,112,.82), rgba(255,255,255,0));
          filter: blur(1px);
          animation: v20TrailMove 1s linear infinite;
        }
        .v20-delivery-chip {
          position: absolute;
          left: 50%;
          top: 0;
          transform: translateX(-50%);
          padding: 8px 14px;
          border-radius: 999px;
          background: rgba(23,23,23,.92);
          color: #fff;
          font-size: 10px;
          font-weight: 800;
          letter-spacing: .08em;
          text-transform: uppercase;
          box-shadow: 0 14px 28px rgba(23,23,23,.18);
          z-index: 65;
        }

        /* V46 · NEXT LEVEL CINEMATIC HAMPER BOX */
        .v20-box-orbit {
          position: absolute;
          left: 50%;
          top: 18%;
          width: 78%;
          height: 48%;
          transform: translateX(-50%);
          border-radius: 999px;
          background:
            radial-gradient(circle at 50% 50%, rgba(255,255,255,.18), transparent 36%),
            radial-gradient(circle at 50% 50%, var(--v20-box-glow-accent), transparent 70%);
          filter: blur(20px);
          opacity: .95;
          z-index: 2;
          animation: v20CinematicPulse 4.2s ease-in-out infinite;
        }

        .v20-box-shell {
          background:
            radial-gradient(circle at 50% 0%, rgba(255,255,255,.28), transparent 22%),
            linear-gradient(145deg, color-mix(in srgb, var(--v20-box-light) 46%, white 54%) 0%, color-mix(in srgb, var(--v20-box-main) 78%, white 22%) 16%, color-mix(in srgb, var(--v20-box-main) 84%, black 16%) 68%, color-mix(in srgb, var(--v20-box-dark) 92%, black 8%) 100%);
          border-color: rgba(77,45,20,.18);
          box-shadow: 0 40px 54px rgba(52,31,12,.16), 0 10px 22px rgba(52,31,12,.08), inset 0 1px 0 rgba(255,255,255,.34), inset 0 -20px 24px rgba(95,61,22,.18);
        }
        .v20-box-shell::before {
          border-color: color-mix(in srgb, var(--v20-box-trim) 42%, transparent);
          background: linear-gradient(140deg, rgba(255,255,255,.14), transparent 24%, transparent 72%, rgba(255,255,255,.08));
        }
        .v20-box-rim {
          background: linear-gradient(180deg, color-mix(in srgb, var(--v20-box-trim) 40%, rgba(255,255,255,.16)) 0%, rgba(116,73,26,.18) 100%);
          border-color: color-mix(in srgb, var(--v20-box-trim) 55%, transparent);
          box-shadow: inset 0 2px 0 rgba(255,255,255,.28), inset 0 -4px 10px rgba(88,54,22,.14);
        }
        .v20-box-lining {
          position: absolute;
          inset: 10px;
          border-radius: inherit;
          background:
            radial-gradient(circle at 50% 18%, rgba(255,255,255,.25), transparent 20%),
            linear-gradient(180deg, rgba(255,255,255,.06), rgba(255,255,255,0) 22%),
            linear-gradient(180deg, color-mix(in srgb, var(--v20-box-satin) 78%, white 22%) 0%, color-mix(in srgb, var(--v20-box-satin) 76%, rgba(90,60,25,.10)) 100%);
          border: 1px solid rgba(255,255,255,.34);
          opacity: .96;
        }
        .v20-box-satin {
          position: absolute;
          left: 5%;
          right: 5%;
          bottom: 4%;
          height: 34%;
          border-radius: 0 0 28px 28px;
          background:
            radial-gradient(circle at 18% 74%, rgba(255,255,255,.52), transparent 18%),
            radial-gradient(circle at 82% 74%, rgba(255,255,255,.36), transparent 18%),
            linear-gradient(180deg, rgba(255,255,255,.16), rgba(255,255,255,0)),
            repeating-linear-gradient(100deg, rgba(255,255,255,.1) 0 14px, rgba(241,228,208,.22) 14px 28px);
          opacity: .84;
          mix-blend-mode: screen;
          pointer-events: none;
        }
        .v20-box-world.is-top-view .v20-box-well {
          background:
            radial-gradient(circle at 50% 16%, rgba(255,241,211,.18), transparent 20%),
            radial-gradient(circle at 50% 56%, rgba(126,67,24,.16), transparent 46%),
            linear-gradient(180deg, color-mix(in srgb, var(--v20-box-dark) 74%, #734121 26%) 0%, color-mix(in srgb, var(--v20-box-deep) 88%, black 12%) 100%);
          box-shadow: inset 0 22px 42px rgba(0,0,0,.24), inset 0 -14px 22px rgba(255,227,168,.12), inset 0 0 0 1px rgba(255,239,206,.04);
        }
        .v20-box-world.is-top-view .v20-pack-card {
          border: 1px solid rgba(84,57,28,.16);
          border-radius: 18px;
          background: linear-gradient(160deg, #fffefd 0%, #fff9f1 26%, #f2e4d0 100%);
          box-shadow: 0 16px 22px rgba(36,22,10,.18), inset 0 1px 0 rgba(255,255,255,.94);
        }
        .v20-box-world.is-top-view .v20-pack-image {
          padding: 6px;
          background: linear-gradient(180deg, rgba(255,255,255,.98), rgba(248,241,231,.96));
          border-radius: 16px;
        }
        .v20-box-world.is-top-view .v20-box-lid-face {
          border-color: rgba(77,45,20,.18);
          background:
            linear-gradient(180deg, rgba(255,247,217,.22), transparent 26%),
            linear-gradient(135deg, color-mix(in srgb, var(--v20-box-main) 66%, white 34%) 0%, color-mix(in srgb, var(--v20-box-main) 86%, white 14%) 36%, color-mix(in srgb, var(--v20-box-dark) 90%, black 10%) 100%);
        }
        .v20-box-world.is-top-view .v20-box-lid-face::before {
          border-color: color-mix(in srgb, var(--v20-box-trim) 68%, transparent);
        }
        .v20-box-monogram {
          border-color: color-mix(in srgb, var(--v20-box-trim) 74%, transparent);
          color: color-mix(in srgb, var(--v20-box-trim) 92%, white 8%);
          background: radial-gradient(circle at 30% 25%, rgba(255,252,235,.52), rgba(102,58,23,.26));
          box-shadow: inset 0 0 0 8px rgba(255,255,255,.06), 0 12px 28px rgba(60,34,11,.18);
        }
        .v20-box-front-badge {
          padding: 10px 18px;
          border-color: rgba(255,244,219,.34);
          background: linear-gradient(180deg, rgba(255,255,255,.14), rgba(0,0,0,.16));
          color: color-mix(in srgb, var(--v20-box-trim) 90%, white 10%);
          box-shadow: 0 14px 24px rgba(40,22,8,.18);
          letter-spacing: .28em;
        }
        .v20-box-world.is-top-view .v20-pack-ribbon-h,
        .v20-box-world.is-top-view .v20-pack-ribbon-v,
        .v20-decor-band,
        .v20-decor-band-v {
          background: linear-gradient(90deg, var(--v20-ribbon-b), var(--v20-ribbon-a) 32%, #fff4c5 50%, var(--v20-ribbon-a) 68%, var(--v20-ribbon-b));
        }
        .v20-box-world.is-top-view .v20-pack-ribbon-v,
        .v20-decor-band-v {
          background: linear-gradient(180deg, #fff4c5, var(--v20-ribbon-a) 40%, var(--v20-ribbon-b));
        }
        .v20-packed-badge {
          border-color: color-mix(in srgb, var(--v20-box-trim) 70%, transparent);
          color: #fff4c3;
          background: radial-gradient(circle at 35% 28%, color-mix(in srgb, var(--v20-ribbon-a) 76%, white 24%), color-mix(in srgb, var(--v20-ribbon-b) 92%, black 8%));
          box-shadow: 0 10px 18px rgba(42,24,4,.24), inset 0 1px 0 rgba(255,255,255,.28);
        }
        .v20-delivery-trail {
          left: 9%;
          bottom: 18%;
          width: 92px;
          height: 13px;
          background: linear-gradient(90deg, rgba(255,255,255,0), color-mix(in srgb, var(--v20-ribbon-a) 60%, #F47822 40%), rgba(255,255,255,0));
          box-shadow: 0 0 16px rgba(244,120,34,.18);
        }
        .v20-delivery-trail--2 {
          bottom: 14%;
          width: 54px;
          opacity: .72;
          animation-duration: .82s;
        }
        .v20-delivery-chip {
          background: rgba(17,17,17,.92);
          color: #fff;
        }
        .v20-dispatch-burst {
          position: absolute;
          right: 8%;
          top: 16%;
          width: 68px;
          height: 68px;
          border-radius: 999px;
          background: radial-gradient(circle, rgba(255,245,214,.32), rgba(255,245,214,0) 62%);
          filter: blur(2px);
          z-index: 40;
          animation: v20CinematicPulse 1.8s ease-in-out infinite;
        }

        .v20-box-world[data-box-theme="chest"] .v20-box-shell {
          border-radius: 38px 38px 28px 28px;
        }
        .v20-box-world.is-top-view.is-packing .v20-box-shell {
          animation: v20PackPulse .9s ease-in-out infinite;
        }
        .v20-box-world.is-top-view.is-packing .v20-box-lid--top {
          animation: v20PackingHover .9s ease-in-out infinite;
        }
        .v20-box-world.is-top-view.is-shipping .v20-box-pedestal {
          opacity: .2;
          transition: opacity .22s ease;
        }
        @keyframes v20PackPulse {
          0%, 100% { transform: translateX(-50%) scale(1); }
          50% { transform: translateX(-50%) scale(1.014); }
        }
        @keyframes v20PackingHover {
          0%, 100% { transform: translateX(-50%) translateY(0) rotateX(8deg); }
          50% { transform: translateX(-50%) translateY(3px) rotateX(4deg); }
        }
        @media (max-width: 639px) {

          .v20-box-front-badge {
            padding: 8px 12px;
            letter-spacing: .18em;
          }
        }

        @keyframes v10Shimmer {
          0% { transform: translateX(-140%); }
          100% { transform: translateX(420%); }
        }

        .v10-soft-scroll { scrollbar-width: none; }
        .v10-soft-scroll::-webkit-scrollbar { display: none; }
        .v24-fixed-studio { scrollbar-width: none; }
        .v24-fixed-studio::-webkit-scrollbar { display: none; }
        .v10-primary-cta { position: relative; overflow: hidden; }
        .v10-primary-cta::after { content: ""; position: absolute; inset: -60% auto -60% -34%; width: 22%; background: linear-gradient(90deg, transparent, rgba(255,255,255,.38), transparent); transform: skewX(-18deg); pointer-events: none; }
        .v10-primary-cta:hover::after { animation: v10Shimmer .8s cubic-bezier(.16,1,.3,1); }


        /* V83 | COLLECTABLE GIFT CARDS. Scope strictly to builder catalogue cards. */
        .v83-card {
          position: relative; isolation: isolate; display: flex; flex-direction: column;
          height: 100%; min-width: 0; overflow: hidden;
          border: 1px solid var(--v83-border); border-radius: 19px;
          background: linear-gradient(154deg,#fff 10%,var(--v83-soft) 100%);
          box-shadow: 0 6px 17px rgba(39,23,16,.055),0 1px 2px rgba(33,24,19,.045);
          transition: transform .36s cubic-bezier(.22,1,.36,1), box-shadow .36s ease, border-color .3s;
          -webkit-tap-highlight-color: transparent;
        }
        .v83-card:hover { transform: translateY(-5px); border-color:var(--v83-accent); box-shadow: 0 18px 35px var(--v83-shadow),0 5px 12px rgba(35,25,20,.08); }
        .v83-card.is-selected { border-color: var(--v83-accent); box-shadow:0 0 0 2px var(--v83-accent),0 13px 29px var(--v83-shadow); }
        .v83-card, .v83-card:hover, .v83-card.is-selected { border-top-color: rgba(64,48,42,.12); }
        .v83-card:focus-visible { outline: 3px solid var(--v83-accent); outline-offset: 3px; }
        .v83-media { position: relative; overflow: hidden; flex: none; background: var(--v83-soft); }
        .v83-media .v83-photo { position: relative; z-index: 0; aspect-ratio: 3 / 2; }
        .v83-media .v83-photo img { transition: transform .62s cubic-bezier(.22,1,.36,1); }
        .v83-card:hover .v83-photo img { transform: scale(1.045); }
        .v83-recommend, .v83-quantity-badge, .v83-pending {
          position:absolute; z-index:4; top:10px; padding:6px 9px; border-radius:999px;
          font-size:10px; line-height:1.15; letter-spacing:.015em; font-weight:900;
          box-shadow:0 5px 15px rgba(0,0,0,.14); backdrop-filter: blur(9px);
        }
        .v83-recommend { left:8px; color:white; background:linear-gradient(110deg,var(--v83-accent),var(--v83-deep)); max-width:80%; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
        .v83-pending { left:8px; color:#865410; background:rgba(255,248,226,.96); border:1px solid #f7d17e; }
        .v83-quantity-badge { right:8px; background:rgba(18,22,26,.86); color:#fff; }
        .v83-content { display:flex; flex:1; flex-direction:column; gap:0; min-width:0; padding:10px 12px 10px; }
        .v83-topline { display:flex; align-items:center; justify-content:space-between; gap:6px; min-height:18px; margin-bottom:4px; }
        .v83-category { min-width:0; max-width:100%; overflow:hidden; white-space:nowrap; text-overflow:ellipsis; font-size:9px; line-height:1.35; font-weight:900; letter-spacing:.08em; color:var(--v83-deep); text-transform:uppercase; }
        .v83-topline-star { flex:0 0 auto; font-size:13px; color:var(--v83-accent); opacity:.78; }
        .v83-title { margin:0; min-height:36px; overflow:hidden; display:-webkit-box; -webkit-box-orient:vertical; -webkit-line-clamp:2; font-size:13px; line-height:1.48; font-weight:850; letter-spacing:-.018em; color:#282027; }
        .v83-price-row { display:flex; align-items:baseline; gap:7px; flex-wrap:wrap; margin-top:auto; padding-top:8px; }
        .v83-price { font-size:19px; font-weight:950; letter-spacing:-.045em; color:var(--v83-deep); line-height:1.15; }
        .v83-mrp { color:#8d8584; font-size:10px; font-weight:700; text-decoration:line-through; }
        .v83-rule { height:1px; margin:8px 0 8px; background:linear-gradient(90deg,var(--v83-border),transparent); }
        .v83-actions { display:grid; grid-template-columns:minmax(0,.92fr) minmax(0,1.08fr); align-items:stretch; gap:7px; }
        .v83-btn { position:relative; min-width:0; min-height:37px; border-radius:10px; padding:6px 5px; font-size:11px; font-weight:900; line-height:1.1; transition:transform .25s,background .25s,box-shadow .25s; }
        .v83-btn:focus-visible, .v83-qty button:focus-visible { outline:2px solid var(--v83-accent); outline-offset:2px; }
        .v83-btn:active:not(:disabled) { transform:scale(.97); }
        .v83-btn-details { border:1px solid var(--v83-border); color:var(--v83-deep); background:rgba(255,255,255,.83); }
        .v83-btn-details:hover { background:#fff; box-shadow:0 3px 12px var(--v83-shadow); }
        .v83-btn-add { border:1px solid transparent; color:white; background:linear-gradient(117deg,var(--v83-accent),var(--v83-deep)); box-shadow:0 4px 10px var(--v83-shadow); }
        .v83-btn-add:hover:not(:disabled) { box-shadow:0 6px 15px var(--v83-shadow); filter:brightness(1.06); }
        .v83-btn:disabled { cursor:not-allowed; box-shadow:none; background:#ece9e5; border-color:#e4dfdb; color:#98918d; filter:none; }
        .v83-qty { display:grid; min-width:0; grid-template-columns:32px minmax(0,1fr) 32px; min-height:37px; overflow:hidden; border:1px solid var(--v83-border); border-radius:10px; background:rgba(255,255,255,.9); }
        .v83-qty button { min-width:0; border:0; background:transparent; color:var(--v83-deep); font-size:16px; font-weight:900; transition:background .2s; }
        .v83-qty button:hover:not(:disabled) { background:var(--v83-tint); }
        .v83-qty button:disabled { opacity:.3; cursor:not-allowed; }
        .v83-qty strong { display:flex; align-items:center; justify-content:center; font-size:11px; color:#2f2630; border-left:1px solid var(--v83-border); border-right:1px solid var(--v83-border); }
        /* V85: gift box selection cards use the same colourful system. */
        .v85-box-card .v83-photo { aspect-ratio: 3 / 2; }
        .v85-box-selected { border:1px solid var(--v83-border); color:var(--v83-deep); background:var(--v83-tint); cursor:default; }
        .v85-box-selected:hover { background:var(--v83-tint); }
        .v83-decor .v83-photo { aspect-ratio:3 / 2; }
        .v83-decor .v83-title { min-height:36px; }
        .v83-decor .v83-content { padding-bottom:10px; }
        .v83-decor-footer { margin-top:7px; display:flex; align-items:center; justify-content:space-between; gap:5px; }
        .v83-decor-detail { min-width:0; color:var(--v83-deep); font-size:10px; font-weight:850; white-space:nowrap; }
        .v83-decor .v83-qty { margin-top:0; grid-template-columns:32px minmax(0,1fr) 32px; }
        @media(max-width:399px) {
          .v83-card { border-radius:15px; }
          .v83-content { padding:9px 8px 9px; }
          .v83-title { font-size:12px; min-height:36px; }
          .v83-price { font-size:17px; }
          .v83-btn { font-size:10px; min-height:35px; }
          .v83-actions { gap:5px; }
          .v83-qty { grid-template-columns:26px minmax(0,1fr) 26px; min-height:35px; }
          .v83-decor .v83-qty { grid-template-columns:28px minmax(0,1fr) 28px; }
          .v83-recommend, .v83-quantity-badge, .v83-pending { font-size:9px; padding:5px 6px; top:8px; }
        }
        @media(prefers-reduced-motion:reduce) {
          .v83-card,.v83-media .v83-photo img,.v83-btn,.v83-qty button { transition:none!important; transform:none!important; }
        }

        /* V87: mobile cards ~10% shorter, same full-cover photo and controls. */
        @media (max-width: 767px) {
          .v83-card .v83-photo { aspect-ratio: 2 / 1; }
        }

        /* V88 · SPOTLIGHT HOVER. No detached popup, always aligned to its card. */
        .v83-media {
          transform-origin: center 43%;
          transition: box-shadow .45s ease, border-radius .45s ease;
        }
        .v83-photo::after {
          content: ""; position: absolute; inset: 0; z-index: 2;
          pointer-events: none; opacity: 0;
          background: linear-gradient(117deg, transparent 24%, rgba(255,255,255,.17) 43%, transparent 60%);
          transform: translateX(-110%);
        }
        @media (min-width: 900px) and (hover:hover) and (pointer:fine) {
          .v83-card:hover { z-index: 3; transform: translateY(-5px) scale(1.012); }
          .v83-card .v83-media { border-radius: 18px 18px 0 0; }
          .v83-card:hover .v83-media {
            overflow: hidden;
            box-shadow: inset 0 0 0 2px rgba(255,255,255,.22);
          }
          .v83-card:hover .v83-photo img {
            transform: scale(1.14);
            filter: saturate(1.05) contrast(1.01);
          }
          .v83-card:hover .v83-photo::after {
            opacity: 1; animation: v88SpotlightSweep .85s ease-out .08s 1 both;
          }
        }
        @keyframes v88SpotlightSweep {
          from { transform: translateX(-110%); }
          to { transform: translateX(125%); }
        }
        @media (max-width: 899px), (hover:none), (pointer:coarse) {
          .v83-card:hover .v83-media { transform:none; box-shadow:none; }
        }
        @media (prefers-reduced-motion:reduce) {
          .v83-media, .v83-photo::after { transition:none!important; animation:none!important; }
          .v83-card:hover .v83-media, .v83-card:hover .v83-photo img { transform:none!important; }
          .v83-card:hover .v83-photo img { filter:none!important; }
        }

        /* V85: selected gift thumbnails fill their entire miniature packing frame. */
        .v60-live-stage .v20-pack-card { overflow:hidden; }
        .v60-live-stage .v20-pack-image {
          display:block; width:100%; height:100%; padding:0 !important;
          object-fit:cover !important; object-position:center;
          border-radius:inherit; background:transparent;
        }
        /* V91: compositor-friendly two-layer card slideshow. Neither photo
           is recreated on every transition; only their opacity swaps. */
        .v83-media .v83-photo img.v91-card-photo-layer {
          transition: opacity .72s cubic-bezier(.4,0,.2,1), transform .62s cubic-bezier(.22,1,.36,1);
          backface-visibility: hidden;
          -webkit-backface-visibility: hidden;
        }
        @media (hover:hover) and (pointer:fine) {
          .v83-card:hover .v91-card-photo-layer { will-change: opacity, transform; }
        }
        @media (prefers-reduced-motion:reduce) {
          .v83-media .v83-photo img.v91-card-photo-layer { transition: none !important; }
        }

        /* V93 | RESTORE THE ORIGINAL V91 CARD HEIGHT, THEN REALLOCATE 60/40.
           Calculate total height from the ORIGINAL image aspect (mobile 2:1,
           desktop 3:2) plus the original compact details height. This prevents
           the fixed 430/470px V92 cards from becoming unnecessarily tall.
           cqw measures the exact grid width, including inside the builder sidebar. */
        [data-hamper-boxes-grid="true"],
        [data-hamper-products-grid="true"],
        [data-hamper-decorations-grid="true"] {
          container-type: inline-size;
          --v93-cols: 2;
          --v93-gap: 10px;
          --v93-original-aspect: .5;
          --v93-original-details: 156px;
        }
        @media (min-width: 400px) and (max-width: 767px) {
          [data-hamper-boxes-grid="true"],
          [data-hamper-products-grid="true"],
          [data-hamper-decorations-grid="true"] { --v93-original-details: 162px; }
        }
        @media (min-width: 640px) {
          [data-hamper-boxes-grid="true"],
          [data-hamper-products-grid="true"],
          [data-hamper-decorations-grid="true"] {
            --v93-cols: 3;
            --v93-gap: 14px;
          }
        }
        @media (min-width: 768px) {
          [data-hamper-boxes-grid="true"],
          [data-hamper-products-grid="true"],
          [data-hamper-decorations-grid="true"] {
            --v93-original-aspect: .6666667;
            --v93-original-details: 162px;
          }
        }
        @media (min-width: 1024px) {
          [data-hamper-products-grid="true"],
          [data-hamper-decorations-grid="true"] { --v93-cols: 4; }
        }
        @media (min-width: 1536px) {
          [data-hamper-boxes-grid="true"] { --v93-cols: 4; }
          [data-hamper-products-grid="true"],
          [data-hamper-decorations-grid="true"] { --v93-cols: 5; }
        }
        .v83-card {
          display: grid;
          grid-template-columns: minmax(0, 1fr);
          grid-template-rows: minmax(0, 3fr) minmax(0, 2fr);
          /* Same height as original compact card at this responsive width. */
          height: calc(
            (100cqw - (var(--v93-cols) - 1) * var(--v93-gap))
              / var(--v93-cols) * var(--v93-original-aspect)
              + var(--v93-original-details)
          );
          min-height: 0;
        }
        .v83-card > .v83-media {
          grid-column: 1;
          grid-row: 1;
          min-width: 0;
          min-height: 0;
          height: 100%;
          overflow: hidden;
        }
        .v83-card > .v83-content {
          grid-column: 1;
          grid-row: 2;
          min-width: 0;
          min-height: 0;
          height: 100%;
          overflow: hidden;
          padding: 6px 9px;
        }
        .v83-card .v83-photo,
        .v83-card.v85-box-card .v83-photo,
        .v83-card.v83-decor .v83-photo {
          aspect-ratio: auto;
          width: 100%;
          height: 100%;
          overflow: hidden;
        }
        .v83-card .v83-photo img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          object-position: center;
          padding: 0;
        }
        /* Compact the EXISTING content, not the card; every label/action stays. */
        .v83-card .v83-topline { min-height: 11px; margin-bottom: 2px; }
        .v83-card .v83-category { font-size: 9px; line-height: 1.1; }
        .v83-card .v83-topline-star { font-size: 11px; line-height: 1; }
        .v83-card .v83-title { min-height: 0; font-size: 12px; line-height: 1.2; }
        .v83-card .v83-price-row { padding-top: 3px; }
        .v83-card .v83-price { font-size: 17px; line-height: 1.08; }
        .v83-card .v83-mrp { font-size: 9px; }
        .v83-card .v83-rule { margin: 3px 0; }
        .v83-card .v83-actions { gap: 5px; }
        .v83-card .v83-btn { min-height: 32px; padding: 4px 3px; font-size: 10px; }
        .v83-card .v83-qty { min-height: 32px; grid-template-columns: 27px minmax(0, 1fr) 27px; }
        .v83-card.v83-decor .v83-title { min-height: 0; }
        .v83-card.v83-decor .v83-content { padding-bottom: 6px; }
        .v83-card.v83-decor .v83-qty { grid-template-columns: 27px minmax(0, 1fr) 27px; }
        @media (max-width: 399px) {
          .v83-card > .v83-content { padding: 4px 6px; }
          .v83-card .v83-topline { min-height: 9px; margin-bottom: 1px; }
          .v83-card .v83-category { font-size: 8px; line-height: 1; }
          .v83-card .v83-title { font-size: 10px; line-height: 1.14; }
          .v83-card .v83-price-row { padding-top: 1px; }
          .v83-card .v83-price { font-size: 15px; line-height: 1.05; }
          .v83-card .v83-rule { margin: 2px 0; }
          .v83-card .v83-actions { gap: 4px; }
          .v83-card .v83-btn { min-height: 27px; padding: 3px 2px; font-size: 9px; }
          .v83-card .v83-qty, .v83-card.v83-decor .v83-qty {
            min-height: 27px;
            grid-template-columns: 23px minmax(0, 1fr) 23px;
          }
          .v83-card.v83-decor .v83-content { padding-bottom: 4px; }
        }
        /* At very narrow 280-319px widths, keep the product name on one
           readable line instead of letting it collide with the price. The
           full name remains accessible through Details and the title tooltip. */
        @media (max-width: 319px) {
          .v83-card .v83-title {
            display: block;
            min-height: 0;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
          }
        }
        @media (min-width: 768px) {
          .v83-card > .v83-content { padding: 8px 10px; }
          .v83-card .v83-title { font-size: 13px; line-height: 1.2; }
          .v83-card .v83-price { font-size: 18px; }
          .v83-card .v83-btn, .v83-card .v83-qty { min-height: 34px; }
          .v83-card.v83-decor .v83-content { padding-bottom: 8px; }
        }

        /* V82: layered photo crossfade; reduced-motion override below. */
        @keyframes v82GalleryFadeIn { from { opacity: 0; } to { opacity: 1; } }
        .v82-gallery-fade { animation: v82GalleryFadeIn .42s cubic-bezier(.22,1,.36,1) both; }
        @media (prefers-reduced-motion: reduce) { .v82-gallery-fade { animation: none !important; } }

        @keyframes v13ModalBackdropIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes v13ModalPanelIn { from { opacity: 0; transform: translateY(16px) scale(.985); } to { opacity: 1; transform: translateY(0) scale(1); } }
        .v13-modal-backdrop { animation: v13ModalBackdropIn .18s ease-out both; }
        .v13-modal-panel { animation: v13ModalPanelIn .24s cubic-bezier(.2,.78,.2,1) both; }

        /* V30 · CALM GIFT STUDIO */
        @keyframes v30StepIn { from { opacity: 0; transform: translate3d(0,14px,0); } to { opacity: 1; transform: translate3d(0,0,0); } }
        .v30-step-in { animation: v30StepIn .48s cubic-bezier(.2,.78,.2,1) both; }
        .v30-scrollbar-none { scrollbar-width: none; }
        .v30-scrollbar-none::-webkit-scrollbar { display: none; }
        .v30-live-shell .v20-live-stage { border-radius: 22px; border-color: rgba(212,175,55,.12); box-shadow: inset 0 1px 0 rgba(255,255,255,.9), 0 16px 40px rgba(53,36,17,.06); }
        .v30-mobile-live .v20-live-stage { min-height: 238px; border-radius: 18px; }
        .v30-mobile-live .v20-box-world { width: 96%; height: 242px; bottom: -2px; }
        .v30-mobile-live .v20-packing-toast { top: 16px; max-width: 84%; }
        .v30-details > summary { list-style: none; }
        .v30-details > summary::-webkit-details-marker { display: none; }
        .v30-details[open] .v30-details-arrow { transform: rotate(45deg); }

        @keyframes v60MobileGiftDrop {
          0% {
            opacity: 0;
            transform: translate(-50%, -180px) rotate(calc(var(--v20-rotate) - 12deg)) scale(.62);
            filter: blur(2px);
          }
          58% {
            opacity: 1;
            transform: translate(-50%, -36%) rotate(calc(var(--v20-rotate) + 3deg)) scale(var(--v20-scale));
            filter: blur(0);
          }
          78% {
            transform: translate(-50%, -58%) rotate(calc(var(--v20-rotate) - 1deg)) scale(var(--v20-scale));
          }
          100% {
            opacity: 1;
            transform: translate(-50%, -50%) rotate(var(--v20-rotate)) scale(var(--v20-scale));
            filter: blur(0);
          }
        }

        @keyframes v61MobileGiftDrop {
          0% {
            opacity: 0;
            transform: translate(-50%, -112px) rotate(calc(var(--v20-rotate) - 10deg)) scale(.64);
            filter: blur(1.5px);
          }
          54% {
            opacity: 1;
            transform: translate(-50%, -34%) rotate(calc(var(--v20-rotate) + 3deg)) scale(var(--v20-scale));
            filter: blur(0);
          }
          78% {
            transform: translate(-50%, -59%) rotate(calc(var(--v20-rotate) - 1deg)) scale(var(--v20-scale));
          }
          100% {
            opacity: 1;
            transform: translate(-50%, -50%) rotate(var(--v20-rotate)) scale(var(--v20-scale));
            filter: blur(0);
          }
        }

        /* V97: Center the actual v78 3D box on EVERY viewport, including desktop.
           V95 removed Tailwind's -translate-x-1/2 from the box element to
           avoid a doubled transform on mobile. Until now, the replacement
           centering rule lived ONLY in the mobile media query, leaving the
           desktop box pushed half its own width to the right. Keep the single
           translateX(-50%) as the desktop/tablet default; V96's mobile rule
           below continues to override it with translateX(-50%) scale(.82). */
        .v60-live-stage > .v78-box-world {
          translate: none;
          transform: translateX(-50%);
        }

        /* V98: Desktop-only: remove the gap between the opened lid and the
           hamper body. The lid ends at about 43% of the 3D world height;
           the old body started at 47%, leaving a visible white band.
           Mobile (<=767px) deliberately retains its V97 position/size. */
        @media (min-width: 768px) {
          .v60-live-stage > .v78-box-world .v98-box-body {
            top: 43%;
          }
        }

        @media (max-width: 767px) {
          /* Keep the live packing box visible while the gift catalogue scrolls. */
          .v30-panel-mobile-sticky-safe { overflow: visible !important; }
          .v30-step-in { animation-name: v30StepInMobile; }

          .v30-mobile-live {
            position: sticky;
            top: 0;
            z-index: 70;
            margin: -20px -16px 14px;
            padding: 5px 6px 6px;
            border: 1px solid rgba(244,120,34,.12);
            border-top: 0;
            border-radius: 0 0 18px 18px;
            background: rgba(255,253,249,.99);
            box-shadow: 0 12px 30px rgba(42,29,14,.12);
            backdrop-filter: blur(18px);
            -webkit-backdrop-filter: blur(18px);
          }

          .v30-mobile-live .v20-live-stage {
            min-height: 176px;
            border-radius: 13px;
          }

          .v30-mobile-live .v20-box-world {
            width: 94%;
            height: 182px;
            bottom: -8px;
          }

          .v30-mobile-live .v20-packing-toast {
            top: 10px;
            max-width: 88%;
            padding: 5px 9px;
            font-size: 7px;
          }

          .v30-mobile-live .v20-capacity-line {
            bottom: 5px;
          }

          .v30-mobile-live-summary {
            margin-top: 5px;
            overflow: hidden;
            border: 1px solid rgba(0,0,0,.055);
            border-radius: 12px;
            background: #FAF8F4;
          }

          .v30-mobile-live-summary-grid {
            display: grid;
            grid-template-columns: .72fr .8fr 1.28fr;
          }

          .v30-mobile-live-summary-cell {
            min-width: 0;
            padding: 7px 9px 6px;
          }

          .v30-mobile-live-summary-cell + .v30-mobile-live-summary-cell {
            border-left: 1px solid rgba(0,0,0,.06);
          }

          .v30-mobile-live-box-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            border-top: 1px solid rgba(0,0,0,.05);
            padding: 9px 11px;
          }

          /* V63 · MOBILE LIVE DOCK — more room for the actual box, no title/status row */
          /* V62: sticky at the real viewport top. While the site header is visible
             it simply sits in normal flow; after the header scrolls away this dock
             occupies that freed space instead of leaving a blank strip. */
          .v30-mobile-live {
            top: 0;
            z-index: 88;
            margin: 0 0 8px;
            padding: 5px;
            border: 1px solid rgba(23,23,23,.065);
            border-radius: 14px;
            background: rgba(255,253,249,.992);
            box-shadow: 0 8px 22px rgba(42,29,14,.09);
          }

          .v30-mobile-live .v60-live-stage {
            min-height: 165px !important;
            border-radius: 11px;
            border-color: rgba(212,175,55,.11);
            box-shadow: inset 0 1px 0 rgba(255,255,255,.98), 0 6px 16px rgba(39,27,14,.04);
          }

          /* V96: stretch only the mobile box artwork vertically. The width,
             15%-narrower horizontal scale and single centering translation
             stay exactly as V95. A 187px canvas at .82 scale is 153.34px tall:
             centered inside the same 165px preview with ~6px at each end. */
          .v30-mobile-live .v78-box-world {
            top: 6px !important;
            bottom: auto !important;
            left: 50% !important;
            width: 99.5% !important;
            max-width: 435px !important;
            height: 187px !important;
            translate: none !important;
            transform: translateX(-50%) scale(.82) !important;
            transform-origin: center top;
          }

          .v30-mobile-live .v60-packing-note {
            top: 3px !important;
            max-width: 72%;
            padding: 3px 7px;
            font-size: 9px;
            line-height: 1.1;
          }

          /* Compact mode owns the stats, so the long capacity rail is hidden here. */
          .v30-mobile-live .v60-capacity-line {
            display: none !important;
          }

          .v30-mobile-live .v20-pack-item.is-entering {
            animation-name: v61MobileGiftDrop;
            animation-duration: .68s;
            animation-timing-function: cubic-bezier(.18,.82,.2,1.06);
          }

          .v61-mobile-mini-stats {
            display: grid;
            grid-template-columns: .7fr .8fr 1.2fr;
            align-items: center;
            min-height: 32px;
            margin-top: 4px;
            overflow: hidden;
            border: 1px solid rgba(0,0,0,.05);
            border-radius: 10px;
            background: #FAF8F4;
          }

          .v61-mobile-mini-stat {
            min-width: 0;
            padding: 4px 8px;
          }

          .v61-mobile-mini-stat + .v61-mobile-mini-stat {
            border-left: 1px solid rgba(0,0,0,.06);
          }

          /* V71 · persistent mobile step navigation.
             Keep Back / Next visible without forcing the customer to reach
             the end of a long product list first. */
          .v30-mobile-sticky-actions {
            position: fixed;
            left: 12px;
            right: 12px;
            bottom: max(10px, env(safe-area-inset-bottom));
            z-index: 110;
            margin: 0;
            padding: 6px;
            border: 1px solid rgba(23,23,23,.07);
            border-radius: 16px;
            background: rgba(250,248,244,.96);
            box-shadow: 0 12px 34px rgba(35,24,13,.16);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
          }

          .v30-mobile-sticky-actions > div {
            width: 100%;
          }

          .hamporium-mobile-builder {
            padding-bottom: 108px !important;
          }

          .hamporium-mobile-builder input,
          .hamporium-mobile-builder select,
          .hamporium-mobile-builder textarea {
            font-size: 16px !important;
          }
        }

        /* V73 · tablet keeps the persistent bottom controls, but desktop
           moves Back / Next into the same top row as the step navigator. */
        @media (min-width: 768px) and (max-width: 1023px) {
          .v30-mobile-sticky-actions {
            position: fixed;
            left: 20px;
            right: 20px;
            bottom: 18px;
            z-index: 110;
            margin: 0;
            padding: 7px;
            border: 1px solid rgba(23,23,23,.07);
            border-radius: 16px;
            background: rgba(250,248,244,.965);
            box-shadow: 0 14px 34px rgba(35,24,13,.14);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
          }

          .v30-mobile-sticky-actions > div {
            width: fit-content;
            margin-left: auto;
          }

          .hamporium-mobile-builder {
            padding-bottom: 118px !important;
          }
        }

        @media (min-width: 1024px) {
          .v30-mobile-sticky-actions {
            display: none !important;
          }

          .hamporium-mobile-builder {
            padding-bottom: 56px !important;
          }
        }

        @keyframes v30StepInMobile {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        @media (min-width: 1280px) {
          .v31-studio-compact .v30-live-shell { padding: 14px; border-radius: 22px; }
          .v31-studio-compact .v20-live-stage { min-height: 220px; border-radius: 16px; }
          .v31-studio-compact .v20-box-world { width: 96%; height: 220px; bottom: -3px; }
          .v31-studio-compact .v20-packing-toast { top: 14px; max-width: 86%; }
        }

        /* V34 · FLAT PRODUCT WORKSPACE — product cards are the only catalogue cards */
        .v34-gift-workspace { background: transparent; }
        .v34-live-flat .v20-live-stage {
          border: 0;
          border-radius: 0;
          background: transparent;
          box-shadow: none;
        }
        .v34-live-flat .v20-live-stage::before,
        .v34-live-flat .v20-live-stage::after { display: none; }
        .v34-live-flat .v20-studio-grid { opacity: .10; }
        @media (min-width: 1280px) {
          .v31-studio-compact.v34-live-flat,
          .v31-studio-compact .v34-live-flat { padding-top: 2px; }
        }

        /* V38 · floating side progress navigator (no outer tracker card) */
        .v38-builder-head {
          position: relative;
          isolation: isolate;
        }

        .v38-progress-dock {
          position: fixed;
          z-index: 96;
          left: 12px;
          top: 50%;
          display: flex;
          flex-direction: column;
          align-items: flex-start;
          gap: 8px;
          transform: translateY(-50%);
          filter: drop-shadow(0 9px 22px rgba(31,22,12,.12));
        }

        .v38-progress-dock::before {
          content: "";
          position: absolute;
          z-index: 0;
          left: 20px;
          top: 18px;
          bottom: 18px;
          width: 1px;
          background: linear-gradient(180deg, rgba(212,175,55,.58), rgba(23,23,23,.10));
          pointer-events: none;
        }

        .v38-progress-step {
          position: relative;
          z-index: 1;
          display: flex;
          height: 42px;
          width: 42px;
          align-items: center;
          overflow: hidden;
          border: 1px solid rgba(23,23,23,.08);
          border-radius: 999px;
          background: rgba(255,252,247,.94);
          color: rgba(23,23,23,.50);
          box-shadow: 0 4px 15px rgba(35,25,14,.06);
          backdrop-filter: blur(14px);
          -webkit-backdrop-filter: blur(14px);
          transition: width .28s cubic-bezier(.22,1,.36,1), border-color .24s ease, background .24s ease, color .24s ease, transform .24s ease;
        }

        .v38-progress-step:hover:not(:disabled),
        .v38-progress-step:focus-visible:not(:disabled) {
          width: 146px;
          border-color: rgba(212,175,55,.44);
          background: rgba(255,250,235,.98);
          color: #171717;
          transform: translateX(2px);
          outline: none;
        }

        .v38-progress-step.is-active {
          width: 126px;
          border-color: #171717;
          background: #171717;
          color: white;
          box-shadow: 0 9px 25px rgba(23,23,23,.18);
        }

        .v38-progress-step.is-active:hover,
        .v38-progress-step.is-active:focus-visible {
          width: 146px;
          background: #171717;
          color: white;
        }

        .v38-progress-step:disabled {
          cursor: not-allowed;
          opacity: .55;
        }

        .v38-progress-dot {
          display: flex;
          height: 40px;
          width: 40px;
          flex: 0 0 40px;
          align-items: center;
          justify-content: center;
          border-radius: 999px;
          background: white;
          font-size: 9px;
          font-weight: 900;
          color: rgba(23,23,23,.45);
          transition: background .24s ease, color .24s ease;
        }

        .v38-progress-step.is-complete .v38-progress-dot {
          background: #F4E5AF;
          color: #7D5B08;
        }

        .v38-progress-step.is-active .v38-progress-dot {
          background: #D4AF37;
          color: #171717;
        }

        .v38-progress-label {
          min-width: 0;
          max-width: 0;
          overflow: hidden;
          margin-left: 0;
          opacity: 0;
          white-space: nowrap;
          font-size: 9.5px;
          font-weight: 900;
          letter-spacing: .055em;
          text-transform: uppercase;
          transition: max-width .28s cubic-bezier(.22,1,.36,1), margin-left .28s cubic-bezier(.22,1,.36,1), opacity .18s ease;
        }

        .v38-progress-step.is-active .v38-progress-label,
        .v38-progress-step:hover .v38-progress-label,
        .v38-progress-step:focus-visible .v38-progress-label {
          max-width: 92px;
          margin-left: 8px;
          opacity: 1;
        }

        @media (max-width: 1279px) {
          .v38-progress-dock {
            left: auto;
            right: 8px;
            top: 46%;
          }
          .v38-progress-step:hover:not(:disabled),
          .v38-progress-step:focus-visible:not(:disabled) {
            transform: translateX(-2px);
          }
        }

        @media (max-width: 767px) {
          .v38-progress-dock {
            right: 6px;
            top: 50%;
            gap: 6px;
          }
          .v38-progress-dock::before { left: 18px; }
          .v38-progress-step {
            width: 36px;
            height: 36px;
          }
          .v38-progress-dot {
            width: 34px;
            height: 34px;
            flex-basis: 34px;
            font-size: 8px;
          }
          .v38-progress-step.is-active {
            width: 36px;
          }
          .v38-progress-step.is-active .v38-progress-label {
            max-width: 0;
            margin-left: 0;
            opacity: 0;
          }
          .v38-progress-step:hover,
          .v38-progress-step:focus-visible,
          .v38-progress-step.is-active:hover,
          .v38-progress-step.is-active:focus-visible {
            width: 118px;
          }
          .v38-progress-step:hover .v38-progress-label,
          .v38-progress-step:focus-visible .v38-progress-label,
          .v38-progress-step.is-active:hover .v38-progress-label,
          .v38-progress-step.is-active:focus-visible .v38-progress-label {
            max-width: 72px;
            margin-left: 7px;
            opacity: 1;
          }
        }



        /* V47 - BLACK BOTANICAL RIGID HAMPER (Tailwind utility driven) */
        @keyframes v47BoxDrop {
          0% { opacity: 0; transform: translateX(-50%) translateY(-190px) scale(.82); filter: blur(3px); }
          62% { opacity: 1; transform: translateX(-50%) translateY(12px) scale(1.025); filter: blur(0); }
          82% { transform: translateX(-50%) translateY(-5px) scale(.992); }
          100% { opacity: 1; transform: translateX(-50%) translateY(0) scale(1); filter: blur(0); }
        }

        @keyframes v47LidOpen {
          0% { top: 38%; transform: translateX(-50%) perspective(1100px) rotateX(3deg) scale(1.015); }
          42% { top: 24%; transform: translateX(-50%) translateY(-10px) perspective(1100px) rotateX(9deg) scale(1.01); }
          76% { top: 1%; transform: translateX(-50%) translateY(-3px) perspective(1100px) rotateX(16deg) scale(.988); }
          100% { top: 3%; transform: translateX(-50%) perspective(1100px) rotateX(13deg) scale(.99); }
        }

        @keyframes v47InsideReveal {
          0% { opacity: 0; transform: scale(.96); }
          100% { opacity: 1; transform: scale(1); }
        }

        @keyframes v47GoldShine {
          0% { transform: translateX(-170%) skewX(-20deg); opacity: 0; }
          28% { opacity: .32; }
          62%, 100% { transform: translateX(350%) skewX(-20deg); opacity: 0; }
        }

        @keyframes v47BowFloat {
          0%, 100% { transform: translateY(0) rotate(-2deg); }
          50% { transform: translateY(-2px) rotate(1deg); }
        }

        /* V48 - PROPORTION FIXED HINGED BLACK BOTANICAL BOX */
        @keyframes v50BoxDrop {
          0% { opacity: 0; transform: translateY(-260px) scale(.96); filter: blur(1px); }
          54% { opacity: 1; transform: translateY(0) scale(1); filter: blur(0); }
          70% { transform: translateY(16px) scale(1.012); }
          84% { transform: translateY(-7px) scale(.998); }
          100% { opacity: 1; transform: translateY(0) scale(1); filter: blur(0); }
        }

        /* V79 - lock horizontal centering; animate only vertical free-fall. */
        @keyframes v79CenterFreeFall {
          0% { opacity: 0; transform: translate3d(0,var(--v79-drop-start,-380px),0) scale(.88); filter: blur(2px); }
          48% { opacity: 1; filter: blur(0); }
          72% { transform: translate3d(0,12px,0) scale(1.012); }
          84% { transform: translate3d(0,-5px,0) scale(.997); }
          100% { opacity: 1; transform: translate3d(0,0,0) scale(1); filter: blur(0); }
        }

        @keyframes v79ShipAway {
          0% { opacity: 1; transform: translate3d(0,0,0) scale(1); }
          16% { transform: translate3d(2%,-3px,0) scale(1.01); }
          100% { opacity: .08; transform: translate3d(138%,-12px,0) scale(.96); }
        }

        @keyframes v48LidOpen {
          0% { transform: translateX(-50%) translateY(92%) perspective(1250px) rotateX(0deg) scale(1); }
          46% { transform: translateX(-50%) translateY(48%) perspective(1250px) rotateX(20deg) scale(1.005); }
          78% { transform: translateX(-50%) translateY(-2%) perspective(1250px) rotateX(51deg) scale(.987); }
          100% { transform: translateX(-50%) translateY(0) perspective(1250px) rotateX(48deg) scale(.99); }
        }

        @keyframes v48InsideReveal {
          0% { opacity: 0; transform: scale(.97); }
          100% { opacity: 1; transform: scale(1); }
        }

        @keyframes v48GoldSheen {
          0% { transform: translateX(-170%) skewX(-18deg); opacity: 0; }
          28% { opacity: .26; }
          62%, 100% { transform: translateX(390%) skewX(-18deg); opacity: 0; }
        }

        @keyframes v48BowSettle {
          0% { opacity: 0; transform: translateX(-50%) translateY(-7px) scale(.92); }
          100% { opacity: 1; transform: translateX(-50%) translateY(0) scale(1); }
        }

        /* V80 - bow anchor never animates horizontally. Only the bow artwork settles vertically. */
        @keyframes v80BowSettle {
          0% { opacity: .72; transform: translateY(-6px) scale(.94); }
          100% { opacity: 1; transform: translateY(0) scale(1); }
        }

        @media (prefers-reduced-motion: reduce) {
          .v7-reveal, .v7-glow, .v7-spark, .v7-decoration, .v9-svg-box, .v9-svg-item, .v13-modal-backdrop, .v13-modal-panel,
          .v20-box-world, .v20-box-lid, .v20-pack-item, .v20-pack-card, .v20-packing-toast,
          .v20-decor-band, .v20-decor-band-v, .v20-packed-glow, .v20-filler span, .v30-step-in {
            animation-duration: .01ms !important;
            animation-iteration-count: 1 !important;
          }
        }
      `}</style>

      <section className="mx-auto w-full max-w-[1920px] px-3 sm:px-5 lg:px-6 xl:px-7 2xl:px-8">
        <div
          ref={mobileFlowRef}
          className={`scroll-mt-[76px] sm:scroll-mt-[108px] ${mobileStep === 1 ? "mb-2 grid grid-cols-1 gap-2 sm:mb-4 sm:grid-cols-[minmax(0,1fr)_auto_minmax(0,1fr)] sm:items-center sm:gap-3" : ""}`}
        >
          {mobileStep === 1 && (
            <>
          <h1
            style={{ fontFamily: DISPLAY_FONT }}
            className="min-w-0 text-[28px] font-semibold leading-[.96] tracking-[-.04em] text-[#171717] sm:col-start-1 sm:text-[34px] lg:text-[38px]"
          >
            Build your hamper
          </h1>

          <div className="justify-self-start sm:col-start-2 sm:row-start-1 sm:justify-self-center">
            {isEditingCartHamper ? (
              <span className="inline-flex h-9 items-center rounded-full border border-black/[0.08] bg-white px-3 text-[11px] font-bold text-black/55">
                Editing hamper
              </span>
            ) : (
              <OrderModeChooser
                mode={orderMode}
                onChange={(nextMode) => {
                  setOrderMode(nextMode);
                  setCartError("");
                }}
              />
            )}
          </div>

          <div aria-hidden="true" className="hidden sm:block sm:col-start-3 sm:row-start-1" />
            </>
          )}
        </div>

        <div
          className="mb-2 lg:sticky lg:z-[95] lg:mb-3 lg:rounded-[16px] lg:border lg:border-black/[0.055] lg:bg-[#FAF8F4]/95 lg:px-3 lg:py-2.5 lg:shadow-[0_10px_28px_rgba(35,24,13,.08)] lg:backdrop-blur-xl xl:mr-[430px] 2xl:mr-[484px]"
          style={{
            top: desktopHeaderVisible ? "84px" : "0px",
            transition: "top 240ms cubic-bezier(.22,1,.36,1)",
          }}
        >
          <div className="lg:flex lg:items-center lg:justify-between lg:gap-4">
            <V30Progress
              step={mobileStep}
              orderMode={orderMode}
              canContinueFromBox={canContinueFromBox}
              canContinueFromProducts={canContinueFromProducts}
              onStepChange={moveMobileStep}
            />

            <V30DesktopStepActions
              step={mobileStep}
              orderMode={orderMode}
              canContinueFromBox={canContinueFromBox}
              canContinueFromProducts={canContinueFromProducts}
              selectedDecorationCount={selectedDecorationCount}
              onStepChange={moveMobileStep}
            />
          </div>

          {mobileStep === 2 && (
            <div className="mt-2 hidden lg:block">
              <V75GiftFilterBar
                search={search}
                setSearch={setSearch}
                categoryFilter={categoryFilter}
                setCategoryFilter={setCategoryFilter}
                subcategoryFilter={subcategoryFilter}
                setSubcategoryFilter={setSubcategoryFilter}
                categories={categories}
                subcategories={subcategories}
              />
            </div>
          )}
        </div>

        {(editError || error) && (
          <div className="mt-4 rounded-[16px] border border-red-200 bg-red-50 px-4 py-3 text-[11px] font-semibold text-red-700">
            {editError || error}
          </div>
        )}

        <div className="mt-2 grid min-w-0 gap-5 sm:mt-4 xl:grid-cols-[minmax(0,1fr)_410px] xl:items-start 2xl:grid-cols-[minmax(0,1fr)_460px] 2xl:gap-6">
          <div className="min-w-0">
            {mobileStep === 1 && (
              <V30Panel
                number="01"
                eyebrow="Start with the base"
                title="Choose your hamper box"
                meta={selectedContainer ? selectedContainer.name : "Choose one box"}
              >
                {containers.length === 0 ? (
                  <V7Empty>No custom hamper boxes are available right now.</V7Empty>
                ) : (
                  <div data-hamper-boxes-grid="true" className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 sm:gap-3.5 lg:grid-cols-3 2xl:grid-cols-4">
                    {containers.map((container) => (
                      <div key={container._id} className="min-w-0">
                        <V7ContainerCard
                          container={container}
                          active={container._id === containerId}
                          onClick={() => {
                            if (container._id === containerId) return;
                            setContainerId(container._id);
                            setSelectedItems([]);
                            setSelectedDecorations([]);
                            setConfiguration(null);
                            setSelectionPending(false);
                            setCartError("");

                            // Box selection is the end of step 1. Move straight
                            // into gifts behind the HAMPORIUM ribbon transition.
                            moveMobileStep(2);
                          }}
                        />
                      </div>
                    ))}
                  </div>
                )}

                <V30StepActions
                  nextLabel="Add gifts"
                  nextDisabled={!canContinueFromBox}
                  onNext={() => moveMobileStep(2)}
                  hint={selectedContainer ? `${selectedContainer.name} selected` : "Select one box to continue."}
                />
              </V30Panel>
            )}

            {mobileStep === 2 && (
              <V34GiftWorkspace
                number="02"
                eyebrow="Curate the inside"
                title="Add your gifts"
                meta={selectedItemCount ? `${selectedItemCount} selected` : "Choose your favourites"}
              >
                <V30MobileLivePreview
                  selectedContainer={selectedContainer}
                  previewItems={previewItems}
                  previewDecorations={previewDecorations}
                  selectedItemCount={selectedItemCount}
                  selectedDecorationCount={selectedDecorationCount}
                  fillPercent={displayFillPercent}
                  configuration={configuration}
                  canIncreaseAnyItem={canIncreaseAnyItem}
                  validating={validating || selectionPending}
                  journeyState={deliveryJourney}
                />

                <div className="lg:hidden">
                  <V75GiftFilterBar
                    search={search}
                    setSearch={setSearch}
                    categoryFilter={categoryFilter}
                    setCategoryFilter={setCategoryFilter}
                    subcategoryFilter={subcategoryFilter}
                    setSubcategoryFilter={setSubcategoryFilter}
                    categories={categories}
                    subcategories={subcategories}
                  />
                </div>


                {visibleComponents.length === 0 ? (
                  <V7Empty>This box has reached its practical limit. Remove an item or choose a larger box.</V7Empty>
                ) : (
                  <div
                    data-hamper-products-grid="true"
                    className="mt-3 grid grid-cols-2 gap-2.5 sm:mt-4 sm:grid-cols-3 sm:gap-3.5 lg:grid-cols-4 2xl:grid-cols-5"
                  >
                    {paginatedComponents.map((component) => {
                      const quantity = selectedMap.get(component._id) || 0;
                      const candidate = candidateMap.get(String(component._id));
                      const missingPrice = component.sellingPrice === null || component.sellingPrice === undefined;
                      const builderBlocked = component.builderStatus?.selectable === false;
                      const cannotAddMore = Boolean(
                        builderBlocked ||
                          !candidate ||
                          candidate.selectable === false ||
                          Number(candidate.maxAdditionalQuantity || 0) <= 0
                      );

                      return (
                        <V7ProductCard
                          key={component._id}
                          component={component}
                          quantity={quantity}
                          selected={quantity > 0}
                          locked={missingPrice || builderBlocked || cannotAddMore}
                          checking={validating || selectionPending}
                          fitLeft={Number(candidate?.maxAdditionalQuantity || 0)}
                          recommendation={
                            cannotAddMore ? null : component.recommendation || null
                          }
                          onMinus={() => decrementItem(component)}
                          onPlus={() => incrementItem(component)}
                        />
                      );
                    })}
                  </div>
                )}

                {visibleComponents.length > 0 && (
                  <ProductPager
                    page={itemPage}
                    totalPages={totalItemPages}
                    totalItems={visibleComponents.length}
                    rangeStart={itemRangeStart}
                    rangeEnd={itemRangeEnd}
                    onPageChange={setItemPage}
                    compact
                  />
                )}

                <V30StepActions
                  backLabel="Box"
                  nextLabel="Finishing touches"
                  nextDisabled={!canContinueFromProducts}
                  onBack={() => moveMobileStep(1)}
                  onNext={() => moveMobileStep(3)}
                  hint={selectedItemCount ? `${selectedItemCount} gift${selectedItemCount === 1 ? "" : "s"} in your hamper` : "Add at least one gift to continue."}
                />
              </V34GiftWorkspace>
            )}

            {mobileStep === 3 && (
              <V30Panel
                number="03"
                eyebrow="Optional finish"
                title="Add the finishing touch"
                meta={selectedDecorationCount ? `${selectedDecorationCount} selected` : "Optional"}
              >
                {decorativeComponents.length > 0 && (
                  <div className="relative max-w-md">
                    <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-sm text-black/25">⌕</span>
                    <input
                      value={decorationSearch}
                      onChange={(event) => setDecorationSearch(event.target.value)}
                      placeholder="Search ribbon, flowers, tags…"
                      className="h-11 w-full rounded-full border border-[#D4AF37]/18 bg-[#FFFCF6] pl-9 pr-4 text-[11px] font-semibold outline-none transition focus:border-[#D4AF37] focus:ring-4 focus:ring-[#D4AF37]/8"
                    />
                  </div>
                )}

                {visibleDecorations.length === 0 ? (
                  <V7Empty>No decorative finishes are available yet.</V7Empty>
                ) : (
                  <div
                    data-hamper-decorations-grid="true"
                    className="mt-3 grid grid-cols-2 gap-2.5 sm:mt-4 sm:grid-cols-3 sm:gap-3.5 lg:grid-cols-4 2xl:grid-cols-5"
                  >
                    {paginatedDecorations.map((component) => (
                      <V7DecorationCard
                        key={component._id}
                        component={component}
                        quantity={decorationMap.get(component._id) || 0}
                        onMinus={() => decrementDecoration(component)}
                        onPlus={() => incrementDecoration(component)}
                      />
                    ))}
                  </div>
                )}

                {isMobileWizard && visibleDecorations.length > 0 && (
                  <ProductPager
                    page={decorationPage}
                    totalPages={totalDecorationPages}
                    totalItems={visibleDecorations.length}
                    rangeStart={decorationRangeStart}
                    rangeEnd={decorationRangeEnd}
                    onPageChange={setDecorationPage}
                    compact
                    label="Finishing touches"
                    scrollSelector='[data-hamper-decorations-grid="true"]'
                  />
                )}

                <V30StepActions
                  backLabel="Gifts"
                  nextLabel={selectedDecorationCount ? "Personalise" : "Skip & personalise"}
                  onBack={() => moveMobileStep(2)}
                  onNext={() => moveMobileStep(4)}
                  hint={selectedDecorationCount ? `${selectedDecorationCount} finishing touch${selectedDecorationCount === 1 ? "" : "es"} selected` : "Finishing touches are optional."}
                />
              </V30Panel>
            )}

            {mobileStep === 4 && (
              <V30Panel
                number="04"
                eyebrow="Make it personal"
                title="Personalise only what matters"
                meta={personalizationPayload ? "Personalisation added" : "Optional"}
              >
                <div className="space-y-3">
                  <details className="v30-details group rounded-[18px] border border-black/[0.07] bg-[#FBF9F5]" open={personalization.assets.length > 0}>
                    <summary className="flex cursor-pointer items-center justify-between gap-4 px-4 py-4 sm:px-5">
                      <div className="min-w-0">
                        <p className="text-[11px] font-black text-[#171717]">Artwork / logo</p>
                      </div>
                      <span className="v30-details-arrow flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-black/[0.08] bg-white text-[18px] leading-none text-black/40 transition-transform duration-300">+</span>
                    </summary>

                    <div className="border-t border-black/[0.06] px-4 pb-5 pt-4 sm:px-5">
                      <div className="grid gap-3 sm:grid-cols-2">
                        <label>
                          <span className="mb-1.5 block text-[12px] font-black uppercase tracking-[0.08em] text-black/32">Artwork type</span>
                          <select value={assetType} onChange={(event) => setAssetType(event.target.value)} className="h-11 w-full rounded-xl border border-black/[0.08] bg-white px-3 text-[11px] font-bold outline-none focus:border-[#D4AF37]">
                            {PERSONALIZATION_ASSET_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
                          </select>
                        </label>
                        <label>
                          <span className="mb-1.5 block text-[12px] font-black uppercase tracking-[0.08em] text-black/32">Placement</span>
                          <select value={assetPlacement} onChange={(event) => setAssetPlacement(event.target.value)} className="h-11 w-full rounded-xl border border-black/[0.08] bg-white px-3 text-[11px] font-bold outline-none focus:border-[#D4AF37]">
                            {PERSONALIZATION_PLACEMENT_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
                          </select>
                        </label>
                      </div>

                      <input
                        value={assetNotes}
                        maxLength={500}
                        onChange={(event) => setAssetNotes(event.target.value)}
                        placeholder="Placement note (optional)"
                        className="mt-3 h-11 w-full rounded-xl border border-black/[0.08] bg-white px-3 text-[11px] font-semibold outline-none focus:border-[#D4AF37]"
                      />

                      <div className="mt-3 flex flex-wrap items-center gap-3">
                        {user ? (
                          <label className={`inline-flex h-11 cursor-pointer items-center justify-center rounded-xl px-4 text-[11px] font-black uppercase tracking-[0.08em] text-white transition ${uploadingAsset || personalization.assets.length >= 4 ? "pointer-events-none bg-black/25" : "bg-[#171717] hover:bg-[#9A7316]"}`}>
                            {uploadingAsset ? "Uploading…" : "Upload image"}
                            <input type="file" accept="image/jpeg,image/png,image/webp,image/avif" disabled={uploadingAsset || personalization.assets.length >= 4} onChange={handlePersonalizationUpload} className="hidden" />
                          </label>
                        ) : (
                          <button type="button" onClick={() => navigateWithRibbon("/login")} className="h-11 rounded-xl bg-[#171717] px-4 text-[11px] font-black uppercase tracking-[0.08em] text-white">Login to upload</button>
                        )}
                        <span className="text-[11px] font-semibold text-black/30">{personalization.assets.length}/4 images · max 5 MB</span>
                      </div>

                      {personalizationError && <p className="mt-3 rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-[11px] font-semibold text-red-700">{personalizationError}</p>}

                      {personalization.assets.length > 0 && (
                        <div className="mt-4 grid gap-3 sm:grid-cols-2">
                          {personalization.assets.map((asset, index) => (
                            <div key={asset.publicId || `${asset.url}-${index}`} className="rounded-[14px] border border-black/[0.07] bg-white p-3">
                              <div className="flex gap-3">
                                <img src={asset.url} alt={asset.fileName || "Personalization artwork"} className="h-16 w-16 shrink-0 rounded-lg bg-[#F6F2EC] object-contain p-1" />
                                <div className="min-w-0 flex-1">
                                  <p className="truncate text-[12px] font-black">{asset.fileName || personalizationLabel(asset.type, PERSONALIZATION_ASSET_OPTIONS)}</p>
                                  <select value={asset.placement || "top_lid"} onChange={(event) => updatePersonalizationAsset(index, "placement", event.target.value)} className="mt-2 h-8 w-full rounded-lg border border-black/[0.07] bg-[#FAF8F5] px-2 text-[11px] font-bold outline-none">
                                    {PERSONALIZATION_PLACEMENT_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
                                  </select>
                                  <input
                                    value={asset.notes || ""}
                                    maxLength={500}
                                    onChange={(event) => updatePersonalizationAsset(index, "notes", event.target.value)}
                                    placeholder="Placement details"
                                    className="mt-2 h-8 w-full rounded-lg border border-black/[0.07] bg-[#FAF8F5] px-2 text-[11px] font-semibold outline-none"
                                  />
                                </div>
                                <button type="button" onClick={() => removePersonalizationAsset(index)} className="h-8 shrink-0 rounded-lg bg-red-50 px-2 text-[12px] font-black text-red-600">Remove</button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </details>

                  <details className="v30-details group rounded-[18px] border border-black/[0.07] bg-[#FBF9F5]" open={Boolean(personalization.message)}>
                    <summary className="flex cursor-pointer items-center justify-between gap-4 px-4 py-4 sm:px-5">
                      <div>
                        <p className="text-[11px] font-black text-[#171717]">Gift message</p>
                      </div>
                      <span className="v30-details-arrow flex h-8 w-8 items-center justify-center rounded-full border border-black/[0.08] bg-white text-[18px] text-black/40 transition-transform duration-300">+</span>
                    </summary>
                    <div className="border-t border-black/[0.06] px-4 pb-5 pt-4 sm:px-5">
                      <textarea rows="3" maxLength={500} value={personalization.message} onChange={(event) => setPersonalization((current) => ({ ...current, message: event.target.value }))} placeholder="e.g. Happy Anniversary, A & R" className="w-full resize-none rounded-xl border border-black/[0.08] bg-white p-3 text-[11px] font-semibold leading-5 outline-none focus:border-[#D4AF37]" />
                      <span className="mt-1 block text-right text-[12px] font-bold text-black/24">{personalization.message.length}/500</span>
                    </div>
                  </details>

                  <details className="v30-details group rounded-[18px] border border-black/[0.07] bg-[#FBF9F5]" open={Boolean(personalization.instructions)}>
                    <summary className="flex cursor-pointer items-center justify-between gap-4 px-4 py-4 sm:px-5">
                      <div>
                        <p className="text-[11px] font-black text-[#171717]">Packing notes</p>
                      </div>
                      <span className="v30-details-arrow flex h-8 w-8 items-center justify-center rounded-full border border-black/[0.08] bg-white text-[18px] text-black/40 transition-transform duration-300">+</span>
                    </summary>
                    <div className="border-t border-black/[0.06] px-4 pb-5 pt-4 sm:px-5">
                      <textarea rows="4" maxLength={1500} value={personalization.instructions} onChange={(event) => setPersonalization((current) => ({ ...current, instructions: event.target.value }))} placeholder="e.g. ivory ribbon, small logo, no plastic wrap" className="w-full resize-none rounded-xl border border-black/[0.08] bg-white p-3 text-[11px] font-semibold leading-5 outline-none focus:border-[#D4AF37]" />
                      <span className="mt-1 block text-right text-[12px] font-bold text-black/24">{personalization.instructions.length}/1500</span>
                    </div>
                  </details>
                </div>

                <V30StepActions
                  backLabel="Finishing"
                  nextLabel={orderMode === "bulk" ? "Quote details" : "Review hamper"}
                  onBack={() => moveMobileStep(3)}
                  onNext={() => moveMobileStep(5)}
                  hint={personalizationPayload ? "Personalisation saved to this hamper." : "Personalisation is optional."}
                />
              </V30Panel>
            )}

            {mobileStep === 5 && orderMode === "bulk" && (
              <V30Panel
                number="05"
                eyebrow="Final step"
                title="Tell us about the bulk order"
                meta={`${Number(bulkQuantity || 0).toLocaleString("en-IN")} hampers`}
              >
                <div className="grid gap-3 sm:grid-cols-2">
                  <BulkField label="Bulk quantity *">
                    <input type="number" min="1" max="100000" value={bulkQuantity} onChange={(event) => setBulkQuantity(event.target.value)} className="h-11 w-full rounded-xl border border-black/[0.08] bg-[#FAF8F5] px-3 text-[11px] font-bold outline-none focus:border-[#D4AF37] focus:bg-white" />
                  </BulkField>
                  <BulkField label="Required by *">
                    <input type="date" min={getToday()} value={bulkRequiredDate} onChange={(event) => setBulkRequiredDate(event.target.value)} className="h-11 w-full rounded-xl border border-black/[0.08] bg-[#FAF8F5] px-3 text-[11px] font-bold outline-none focus:border-[#D4AF37] focus:bg-white" />
                  </BulkField>
                  <BulkField label="Purpose">
                    <select value={bulkPurpose} onChange={(event) => setBulkPurpose(event.target.value)} className="h-11 w-full rounded-xl border border-black/[0.08] bg-[#FAF8F5] px-3 text-[11px] font-bold outline-none focus:border-[#D4AF37] focus:bg-white">
                      {BULK_PURPOSE_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
                    </select>
                  </BulkField>
                  <BulkField label="Delivery model">
                    <select value={bulkAddressModel} onChange={(event) => setBulkAddressModel(event.target.value)} className="h-11 w-full rounded-xl border border-black/[0.08] bg-[#FAF8F5] px-3 text-[11px] font-bold outline-none focus:border-[#D4AF37] focus:bg-white">
                      <option value="not_decided">Not decided yet</option>
                      <option value="single_address">Single address</option>
                      <option value="multiple_addresses">Multiple addresses</option>
                    </select>
                  </BulkField>
                  <BulkField label="Company / organisation">
                    <input value={bulkCompanyName} maxLength={200} onChange={(event) => setBulkCompanyName(event.target.value)} placeholder="Optional" className="h-11 w-full rounded-xl border border-black/[0.08] bg-[#FAF8F5] px-3 text-[11px] font-semibold outline-none focus:border-[#D4AF37] focus:bg-white" />
                  </BulkField>
                  <BulkField label="GSTIN">
                    <input value={bulkGstNumber} maxLength={40} onChange={(event) => setBulkGstNumber(event.target.value.toUpperCase())} placeholder="Optional" className="h-11 w-full rounded-xl border border-black/[0.08] bg-[#FAF8F5] px-3 text-[11px] font-semibold uppercase outline-none focus:border-[#D4AF37] focus:bg-white" />
                  </BulkField>
                </div>

                <div className="mt-3 grid gap-3 lg:grid-cols-2">
                  <BulkField label="Delivery locations">
                    <textarea rows="4" value={bulkDeliveryLocations} onChange={(event) => setBulkDeliveryLocations(event.target.value)} placeholder="City, office, venue or one location per line." className="w-full resize-none rounded-xl border border-black/[0.08] bg-[#FAF8F5] p-3 text-[11px] font-semibold leading-5 outline-none focus:border-[#D4AF37] focus:bg-white" />
                  </BulkField>
                  <BulkField label="Anything else for the quotation">
                    <textarea rows="4" maxLength={2000} value={bulkNotes} onChange={(event) => setBulkNotes(event.target.value)} placeholder="Delivery split, branding expectation, timeline or commercial note." className="w-full resize-none rounded-xl border border-black/[0.08] bg-[#FAF8F5] p-3 text-[11px] font-semibold leading-5 outline-none focus:border-[#D4AF37] focus:bg-white" />
                  </BulkField>
                </div>

                <div className="mt-5 xl:hidden">
                  <V7Studio
                    selectedContainer={selectedContainer}
                    previewItems={previewItems}
                    previewDecorations={previewDecorations}
                    selectedItemCount={selectedItemCount}
                    selectedDecorationCount={selectedDecorationCount}
                    fillPercent={displayFillPercent}
                    configuration={configuration}
                    personalization={personalizationPayload}
                    canIncreaseAnyItem={canIncreaseAnyItem}
                    validating={validating || selectionPending}
                    cartError={cartError}
                    canAddToCart={canPrimaryAction}
                    addingToCart={primaryBusy}
                    deliveryJourney={deliveryJourney}
                    user={user}
                    isEditingCartHamper={isEditingCartHamper}
                    orderMode={orderMode}
                    bulkQuantity={Number(bulkQuantity || 0)}
                    onModeChange={(nextMode) => { setOrderMode(nextMode); setCartError(""); }}
                    onAddToCart={handleRequestQuotation}
                  />
                </div>

                <V30StepActions backLabel="Personalise" onBack={() => moveMobileStep(4)} hint="Review the live hamper and submit the quotation from the summary." />
              </V30Panel>
            )}

            {mobileStep === 5 && orderMode !== "bulk" && (
              <V30Panel
                number="05"
                eyebrow="Final check"
                title={isEditingCartHamper ? "Review your changes" : "Review your hamper"}
                meta={
                  configuration?.orderable
                    ? isEditingCartHamper
                      ? "Ready to save"
                      : "Ready to add"
                    : "Review required"
                }
              >
                <div className="grid gap-2 sm:grid-cols-4">
                  <V30ReviewStat label="Box" value={selectedContainer?.name || "Not selected"} />
                  <V30ReviewStat label="Gifts" value={String(selectedItemCount)} />
                  <V30ReviewStat label="Gift fill" value={`${Math.round(displayFillPercent)}%`} />
                  <V30ReviewStat label="Personalisation" value={personalizationPayload ? "Added" : "None"} />
                </div>

                <V71ReviewContents
                  selectedContainer={selectedContainer}
                  selectedItems={selectedItems}
                  contentMap={contentMap}
                  selectedDecorations={selectedDecorations}
                  decorationComponentMap={decorationComponentMap}
                  personalization={personalizationPayload}
                />

                <div className="mt-5 xl:hidden">
                  <V7Studio
                    selectedContainer={selectedContainer}
                    previewItems={previewItems}
                    previewDecorations={previewDecorations}
                    selectedItemCount={selectedItemCount}
                    selectedDecorationCount={selectedDecorationCount}
                    fillPercent={displayFillPercent}
                    configuration={configuration}
                    personalization={personalizationPayload}
                    canIncreaseAnyItem={canIncreaseAnyItem}
                    validating={validating || selectionPending}
                    cartError={cartError}
                    canAddToCart={canPrimaryAction}
                    addingToCart={primaryBusy}
                    deliveryJourney={deliveryJourney}
                    user={user}
                    isEditingCartHamper={isEditingCartHamper}
                    orderMode={orderMode}
                    bulkQuantity={Number(bulkQuantity || 0)}
                    onModeChange={(nextMode) => { setOrderMode(nextMode); setCartError(""); }}
                    onAddToCart={handleAddToCart}
                  />
                </div>

                <V30StepActions backLabel="Personalise" onBack={() => moveMobileStep(4)} hint={isEditingCartHamper ? "Review the changes, then save the same cart hamper from the summary." : "Your live hamper summary is ready."} />
              </V30Panel>
            )}
          </div>

          <aside className="hidden xl:block xl:w-[410px] 2xl:w-[460px]" aria-label="Live hamper preview">
            <div
              className="v31-studio-compact v30-scrollbar-none fixed top-[88px] z-30 max-h-[calc(100vh-104px)] w-[410px] overflow-y-auto overscroll-contain pr-1 2xl:w-[460px]"
              style={{
                right: "max(1.75rem, calc((100vw - 1920px) / 2 + 1.75rem))",
              }}
            >
              <V7Studio
                selectedContainer={selectedContainer}
                previewItems={previewItems}
                previewDecorations={previewDecorations}
                selectedItemCount={selectedItemCount}
                selectedDecorationCount={selectedDecorationCount}
                fillPercent={displayFillPercent}
                configuration={configuration}
                personalization={personalizationPayload}
                canIncreaseAnyItem={canIncreaseAnyItem}
                validating={validating || selectionPending}
                cartError={cartError}
                canAddToCart={canPrimaryAction}
                addingToCart={primaryBusy}
                deliveryJourney={deliveryJourney}
                user={user}
                isEditingCartHamper={isEditingCartHamper}
                orderMode={orderMode}
                bulkQuantity={Number(bulkQuantity || 0)}
                onModeChange={(nextMode) => {
                  setOrderMode(nextMode);
                  setCartError("");
                }}
                onAddToCart={orderMode === "bulk" ? handleRequestQuotation : handleAddToCart}
              />
            </div>
          </aside>
        </div>
      </section>
    </main>
  );
};

const V30Progress = ({
  step,
  orderMode,
  canContinueFromBox,
  canContinueFromProducts,
  onStepChange,
}) => {
  const steps = [
    [1, "Choose box"],
    [2, "Add your gifts"],
    [3, "Finishing touch"],
    [4, "Personalise"],
    [5, orderMode === "bulk" ? "Quote details" : "Review hamper"],
  ];

  const maxReachable = !canContinueFromBox ? 1 : !canContinueFromProducts ? 2 : 5;

  return (
    <nav
      className="mb-2 flex flex-wrap items-center gap-2 py-0.5 sm:mb-3 sm:py-1 lg:mb-0 lg:flex-nowrap"
      aria-label="Hamper builder progress"
    >
      {steps.map(([number, label]) => {
        const active = step === number;
        const complete = step > number;
        const disabled = number > maxReachable;

        return (
          <button
            key={number}
            type="button"
            disabled={disabled}
            onClick={() => onStepChange(number)}
            aria-current={active ? "step" : undefined}
            aria-label={`${number}. ${label}${complete ? ", completed" : active ? ", current step" : ""}`}
            title={`${number}. ${label}`}
            className={`group/step flex h-8 items-center overflow-hidden rounded-full border transition-[width,border-color,background-color,color,box-shadow] duration-300 ease-out focus-visible:outline-none sm:h-9 ${
              active
                ? "w-[140px] border-[#171717] bg-[#171717] text-white shadow-[0_5px_16px_rgba(0,0,0,.10)] sm:w-[150px]"
                : complete
                  ? "w-8 border-[#D4AF37]/35 bg-[#FFF8DE] text-[#8A6815] hover:w-[140px] focus-visible:w-[140px] sm:w-9 sm:hover:w-[150px] sm:focus-visible:w-[150px]"
                  : "w-8 border-black/[0.08] bg-white text-black/45 hover:w-[140px] hover:border-black/15 hover:text-[#171717] focus-visible:w-[140px] sm:w-9 sm:hover:w-[150px] sm:focus-visible:w-[150px]"
            } disabled:cursor-not-allowed disabled:opacity-35`}
          >
            <span className="flex h-8 w-8 shrink-0 items-center justify-center text-[10px] font-black sm:h-9 sm:w-9 sm:text-[11px]">
              {complete ? "✓" : number}
            </span>
            <span
              className={`pointer-events-none mr-3 whitespace-nowrap text-[11px] font-extrabold transition-opacity duration-200 ${
                active
                  ? "opacity-100"
                  : "opacity-0 group-hover/step:opacity-100 group-focus-visible/step:opacity-100"
              }`}
            >
              {label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};

const V30DesktopStepActions = ({
  step,
  orderMode,
  canContinueFromBox,
  canContinueFromProducts,
  selectedDecorationCount,
  onStepChange,
}) => {
  let backLabel = "";
  let nextLabel = "";
  let nextDisabled = false;
  let backStep = null;
  let nextStep = null;

  if (step === 1) {
    nextLabel = "Add gifts";
    nextDisabled = !canContinueFromBox;
    nextStep = 2;
  } else if (step === 2) {
    backLabel = "Box";
    nextLabel = "Finishing touches";
    nextDisabled = !canContinueFromProducts;
    backStep = 1;
    nextStep = 3;
  } else if (step === 3) {
    backLabel = "Gifts";
    nextLabel = selectedDecorationCount ? "Personalise" : "Skip & personalise";
    backStep = 2;
    nextStep = 4;
  } else if (step === 4) {
    backLabel = "Finishing";
    nextLabel = orderMode === "bulk" ? "Quote details" : "Review hamper";
    backStep = 3;
    nextStep = 5;
  } else if (step === 5) {
    backLabel = "Personalise";
    backStep = 4;
  }

  return (
    <div className="hidden shrink-0 items-center gap-2 lg:flex lg:ml-3">
      {backStep && (
        <button
          type="button"
          onClick={() => onStepChange(backStep)}
          className="h-9 rounded-full border border-black/[0.08] bg-white px-4 text-[11px] font-black text-black/55 transition hover:border-black/20 hover:text-[#171717] active:scale-[.98]"
        >
          ← {backLabel}
        </button>
      )}

      {nextStep && (
        <button
          type="button"
          disabled={nextDisabled}
          onClick={() => onStepChange(nextStep)}
          className="h-9 rounded-full bg-[#171717] px-4 text-[11px] font-black text-white transition hover:bg-[#9A7316] active:scale-[.99] disabled:cursor-not-allowed disabled:bg-black/10 disabled:text-black/25"
        >
          {nextLabel} →
        </button>
      )}
    </div>
  );
};

const V75GiftFilterBar = ({
  search,
  setSearch,
  categoryFilter,
  setCategoryFilter,
  subcategoryFilter,
  setSubcategoryFilter,
  categories,
  subcategories,
}) => (
  <div className="flex min-w-0 flex-col gap-2 sm:flex-row sm:items-center">
    <div className="relative w-full shrink-0 sm:w-[220px] lg:w-[250px] xl:w-[230px] 2xl:w-[260px]">
      <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-[14px] text-black/24">⌕</span>
      <input
        value={search}
        onChange={(event) => setSearch(event.target.value)}
        placeholder="Search gifts"
        className="h-11 w-full rounded-full border border-black/[0.07] bg-white pl-10 pr-4 text-[16px] font-semibold text-[#171717] outline-none transition placeholder:text-black/35 focus:border-[#F47822]/55 focus:ring-4 focus:ring-[#F47822]/[0.06] sm:h-10 sm:text-[13px]"
      />
    </div>

    <div className="v30-scrollbar-none min-w-0 flex-1 overflow-x-auto">
      <div className="flex w-max items-center gap-2 pr-1">
        <button
          type="button"
          onClick={() => {
            setCategoryFilter("");
            setSubcategoryFilter("");
          }}
          className={`shrink-0 rounded-full border px-3.5 py-2.5 text-[13px] font-extrabold transition sm:py-2 sm:text-[12px] ${
            !categoryFilter && !subcategoryFilter
              ? "border-[#171717] bg-[#171717] text-white"
              : "border-black/[0.08] bg-white text-black/55 hover:border-black/20 hover:text-[#171717]"
          }`}
        >
          All
        </button>

        {categories.slice(0, 8).map((category) => (
          <button
            key={`category-${category}`}
            type="button"
            onClick={() => {
              setCategoryFilter(category);
              setSubcategoryFilter("");
            }}
            className={`shrink-0 rounded-full border px-3.5 py-2.5 text-[13px] font-extrabold transition sm:py-2 sm:text-[12px] ${
              categoryFilter === category && !subcategoryFilter
                ? "border-[#171717] bg-[#171717] text-white"
                : "border-black/[0.08] bg-white text-black/55 hover:border-black/20 hover:text-[#171717]"
            }`}
          >
            {category}
          </button>
        ))}

        {subcategories.map((subcategory) => (
          <button
            key={`subcategory-${subcategory}`}
            type="button"
            onClick={() => setSubcategoryFilter(subcategory)}
            className={`shrink-0 rounded-full border px-3.5 py-2.5 text-[13px] font-extrabold transition sm:py-2 sm:text-[12px] ${
              subcategoryFilter === subcategory
                ? "border-[#F47822] bg-[#FFF4EC] text-[#D85E0F]"
                : "border-black/[0.08] bg-white text-black/55 hover:border-[#F47822]/35 hover:text-[#D85E0F]"
            }`}
          >
            {subcategory}
          </button>
        ))}
      </div>
    </div>
  </div>
);

const V34GiftWorkspace = ({ children }) => (
  <section className="v34-gift-workspace min-w-0">
    <div>{children}</div>
  </section>
);

const V30Panel = ({ children }) => (
  <section className="v30-panel-mobile-sticky-safe v30-step-in min-w-0">
    <div>{children}</div>
  </section>
);

const V30StepActions = ({
  backLabel = "Back",
  nextLabel,
  nextDisabled = false,
  onBack,
  onNext,
}) => (
  <div className="v30-mobile-sticky-actions mt-5 pt-1">
    <div className={`grid gap-2 sm:ml-auto sm:w-fit ${
      onBack && nextLabel
        ? "grid-cols-[88px_minmax(0,1fr)] sm:grid-cols-[100px_170px]"
        : "grid-cols-1"
    }`}>
      {onBack && (
        <button
          type="button"
          onClick={onBack}
          className="h-11 rounded-xl border border-black/[0.08] bg-white px-3 text-[13px] font-black text-black/55 transition hover:border-black/20 hover:text-[#171717] active:scale-[.98] sm:text-[11px]"
        >
          ← {backLabel}
        </button>
      )}
      {nextLabel && (
        <button
          type="button"
          disabled={nextDisabled}
          onClick={onNext}
          className="h-11 rounded-xl bg-[#171717] px-4 text-[13px] font-black text-white transition hover:bg-[#9A7316] active:scale-[.99] disabled:cursor-not-allowed disabled:bg-black/10 disabled:text-black/25 sm:text-[11px]"
        >
          {nextLabel} →
        </button>
      )}
    </div>
  </div>
);

const V30MobileLivePreview = (props) => {
  const giftCount = Number(props.selectedItemCount || 0);
  const roundedFill = Math.round(Number(props.fillPercent || 0));
  const liveTotal =
    props.configuration?.pricing?.total ??
    props.selectedContainer?.sellingPrice ??
    null;

  return (
    <section className="v30-mobile-live md:hidden" aria-label="Live hamper preview">
      <V7OpenTop3D {...props} compact />

      <div className="v61-mobile-mini-stats">
        <div className="v61-mobile-mini-stat">
          <p className="text-[10px] font-bold uppercase tracking-[0.05em] text-black/38">Gifts</p>
          <p className="mt-0.5 text-[15px] font-black leading-none text-[#171717]">{giftCount}</p>
        </div>

        <div className="v61-mobile-mini-stat">
          <p className="text-[10px] font-bold uppercase tracking-[0.05em] text-black/38">Filled</p>
          <p className="mt-0.5 text-[15px] font-black leading-none text-[#171717]">{roundedFill}%</p>
        </div>

        <div className="v61-mobile-mini-stat text-right">
          <p className="text-[10px] font-bold uppercase tracking-[0.05em] text-black/38">Total</p>
          <p
            style={{ fontFamily: DISPLAY_FONT }}
            className="mt-0.5 truncate text-[18px] font-semibold leading-none text-[#F47822]"
          >
            {liveTotal === null || liveTotal === undefined
              ? "—"
              : formatCurrency(liveTotal)}
          </p>
        </div>
      </div>
    </section>
  );
};

const V30ReviewStat = ({ label, value }) => (
  <div className="min-w-0 border-b border-black/[0.06] px-1 py-3">
    <p className="text-[12px] font-bold text-black/35">{label}</p>
    <p className="mt-1 truncate text-[11px] font-black text-[#171717]" title={value}>{value}</p>
  </div>
);

const V71ReviewContents = ({
  selectedContainer,
  selectedItems = [],
  contentMap,
  selectedDecorations = [],
  decorationComponentMap,
  personalization,
}) => {
  const gifts = selectedItems
    .map((selection) => ({
      quantity: Number(selection.quantity || 0),
      component: contentMap?.get(String(selection.componentId)),
    }))
    .filter((entry) => entry.component && entry.quantity > 0);

  const decorations = selectedDecorations
    .map((selection) => ({
      quantity: Number(selection.quantity || 0),
      component: decorationComponentMap?.get(String(selection.componentId)),
    }))
    .filter((entry) => entry.component && entry.quantity > 0);

  return (
    <section className="mt-4 overflow-hidden rounded-[16px] border border-black/[0.07] bg-white">
      <div className="flex items-center justify-between gap-3 border-b border-black/[0.06] px-4 py-3">
        <p className="text-[13px] font-black text-[#171717]">Hamper contents</p>
        <span className="text-[11px] font-bold text-black/35">
          {gifts.reduce((sum, entry) => sum + entry.quantity, 0)} gifts
        </span>
      </div>

      {selectedContainer?.name && (
        <div className="flex items-start justify-between gap-3 border-b border-black/[0.05] px-4 py-3">
          <span className="text-[11px] font-bold text-black/35">Box</span>
          <span className="max-w-[72%] text-right text-[12px] font-black leading-5 text-[#171717]">
            {selectedContainer.name}
          </span>
        </div>
      )}

      <div className="divide-y divide-black/[0.05]">
        {gifts.map(({ component, quantity }) => (
          <div key={component._id} className="flex items-center justify-between gap-3 px-4 py-3">
            <p className="min-w-0 flex-1 text-[12px] font-extrabold leading-5 text-[#171717]">
              {component.name}
            </p>
            <span className="shrink-0 rounded-full bg-black/[0.045] px-2.5 py-1 text-[11px] font-black text-black/55">
              ×{quantity}
            </span>
          </div>
        ))}
      </div>

      {decorations.length > 0 && (
        <div className="border-t border-black/[0.06]">
          <div className="px-4 pb-1 pt-3 text-[10px] font-black uppercase tracking-[0.07em] text-black/35">
            Finishing touches
          </div>
          <div className="divide-y divide-black/[0.05]">
            {decorations.map(({ component, quantity }) => (
              <div key={component._id} className="flex items-center justify-between gap-3 px-4 py-2.5">
                <p className="min-w-0 flex-1 text-[12px] font-extrabold leading-5 text-[#171717]">
                  {component.name}
                </p>
                <span className="shrink-0 rounded-full bg-[#FFF8DE] px-2.5 py-1 text-[11px] font-black text-[#8A6815]">
                  ×{quantity}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {personalization && (
        <div className="border-t border-black/[0.06] px-4 py-3 text-[12px] font-extrabold text-[#171717]">
          Personalisation added
        </div>
      )}
    </section>
  );
};

const OrderModeChooser = ({ mode, onChange }) => (
  <div className="inline-grid w-[286px] max-w-full grid-cols-2 rounded-xl border border-black/[0.07] bg-white p-1 sm:w-[260px]">
    <button
      type="button"
      onClick={() => onChange("personal")}
      className={`h-9 rounded-lg px-4 text-[12px] font-black transition ${
        mode === "personal"
          ? "bg-[#171717] text-white"
          : "text-black/40 hover:text-[#171717]"
      }`}
    >
      Personal
    </button>
    <button
      type="button"
      onClick={() => onChange("bulk")}
      className={`h-9 rounded-lg px-4 text-[12px] font-black transition ${
        mode === "bulk"
          ? "bg-[#171717] text-white"
          : "text-black/40 hover:text-[#171717]"
      }`}
    >
      Bulk / Event
    </button>
  </div>
);

const MobileBuilderProgress = ({ step, orderMode }) => {
  const labels = [
    "Choose your box",
    "Add your gifts",
    "Finishing touches",
    "Personalise",
    orderMode === "bulk" ? "Quote details" : "Review hamper",
  ];

  return (
    <div className="rounded-[16px] border border-black/[0.07] bg-white px-3.5 py-3 shadow-[0_8px_24px_rgba(41,29,15,.04)]">
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0">
          <span className="text-[12px] font-black uppercase tracking-[0.11em] text-[#F47822]">
            Step {String(step).padStart(2, "0")} / 05
          </span>
          <p className="mt-0.5 truncate text-[11px] font-black text-[#171717]">
            {labels[step - 1]}
          </p>
        </div>
        <span className="shrink-0 rounded-full bg-[#F7F1E7] px-2.5 py-1 text-[12px] font-black uppercase tracking-[0.07em] text-[#8A6815]">
          {orderMode === "bulk" ? "Bulk / Event" : "Personal"}
        </span>
      </div>

      <div className="mt-2.5 grid grid-cols-5 gap-1.5" aria-hidden="true">
        {[1, 2, 3, 4, 5].map((item) => (
          <span
            key={item}
            className={`h-1.5 rounded-full transition-all duration-300 ${
              item <= step ? "bg-[#F47822]" : "bg-black/[0.07]"
            }`}
          />
        ))}
      </div>
    </div>
  );
};

const MobileStepActions = ({
  backLabel = "Back",
  nextLabel,
  nextDisabled = false,
  onBack,
  onNext,
  hint = "",
}) => (
  <div className="md:hidden">
    <div className="rounded-[18px] border border-black/[0.07] bg-white p-3.5 shadow-[0_10px_28px_rgba(40,27,13,.045)]">
      {hint && (
        <p className="mb-3 text-[12px] font-semibold leading-4 text-black/40">
          {hint}
        </p>
      )}

      <div className={`grid gap-2.5 ${onBack ? "grid-cols-[92px_minmax(0,1fr)]" : "grid-cols-1"}`}>
        {onBack && (
          <button
            type="button"
            onClick={onBack}
            className="flex h-12 items-center justify-center gap-1.5 rounded-xl border border-black/[0.09] bg-[#FAF8F5] px-3 text-[12px] font-black text-black/52 transition active:scale-[.98]"
          >
            ← {backLabel}
          </button>
        )}

        <button
          type="button"
          disabled={nextDisabled}
          onClick={onNext}
          className="flex h-12 min-w-0 items-center justify-center gap-2 rounded-xl bg-[#171717] px-4 text-center text-[12px] font-black uppercase tracking-[0.055em] text-white shadow-[0_10px_24px_rgba(23,23,23,.14)] transition active:scale-[.99] disabled:cursor-not-allowed disabled:bg-black/10 disabled:text-black/25 disabled:shadow-none"
        >
          <span className="truncate">{nextLabel}</span>
          <span aria-hidden="true">→</span>
        </button>
      </div>
    </div>
  </div>
);

const MobileLiveHamperStatus = ({
  selectedItemCount,
  fillPercent,
  configuration,
  selectedContainer,
}) => {
  const roundedFill = Math.round(Number(fillPercent || 0));
  const liveTotal =
    configuration?.pricing?.total ??
    selectedContainer?.sellingPrice ??
    null;

  return (
    <div className="mb-3 grid grid-cols-3 divide-x divide-black/[0.06] rounded-[14px] border border-black/[0.06] bg-white md:hidden">
      <div className="px-3 py-2.5">
        <span className="text-[11px] font-black text-[#171717]">{selectedItemCount}</span>
        <span className="ml-1 text-[11px] font-semibold text-black/35">gifts</span>
      </div>
      <div className="px-3 py-2.5 text-center">
        <span className="text-[11px] font-black text-[#171717]">{roundedFill}%</span>
        <span className="ml-1 text-[11px] font-semibold text-black/35">full</span>
      </div>
      <div className="min-w-0 px-3 py-2.5 text-right">
        <span className="truncate text-[11px] font-black text-[#F47822]">
          {liveTotal === null || liveTotal === undefined ? "—" : formatCurrency(liveTotal)}
        </span>
      </div>
    </div>
  );
};

const BulkField = ({ label, children }) => (
  <label className="block">
    <span className="mb-1.5 block text-[11px] font-black uppercase tracking-[0.08em] text-black/35">
      {label}
    </span>
    {children}
  </label>
);

const V7Section = ({ number, title, meta, gold = false, children }) => (
  <section className="v7-reveal border-b border-black/[0.08] pb-8 pt-2 sm:pb-10 sm:pt-3">
    <div className="flex items-center justify-between gap-4 pb-5 sm:pb-6">
      <div className="flex min-w-0 items-center gap-3.5">
        <span
          className={`relative flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-[12px] font-black ${
            gold
              ? "bg-[#9B7616] text-white"
              : "bg-[#9A6E32] text-white"
          }`}
        >
          {String(number).replace(/^0/, "")}
          <span className="absolute -bottom-2 left-1/2 h-[2px] w-5 -translate-x-1/2 bg-[#F47822]" />
        </span>

        <div className="min-w-0">
          <h2
            style={{ fontFamily: DISPLAY_FONT }}
            className="truncate text-[24px] font-semibold leading-none tracking-[-.025em] text-[#171717] sm:text-[30px]"
          >
            {title}
          </h2>
          {meta && (
            <p className="mt-1 truncate text-[11px] font-semibold text-black/34 sm:hidden">
              {meta}
            </p>
          )}
        </div>
      </div>

      <span className="hidden shrink-0 text-[11px] font-black uppercase tracking-[0.1em] text-black/26 sm:block">
        {meta}
      </span>
    </div>

    <div>{children}</div>
  </section>
);

const DetailModalPortal = ({ children, onClose }) => {
  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        onClose?.();
      }
    };

    document.addEventListener("keydown", handleKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [onClose]);

  if (typeof document === "undefined") return null;

  return createPortal(children, document.body);
};

const V11ContainerDetailsModal = ({
  container,
  active,
  onSelect,
  onClose,
}) => {
  const hasPrice =
    container.sellingPrice !== null &&
    container.sellingPrice !== undefined;
  const builderReady = container.builderStatus?.selectable !== false;
  const builderReasons = Array.isArray(container.builderStatus?.reasons)
    ? container.builderStatus.reasons
    : [];

  const hasMrp =
    hasPrice &&
    container.mrp !== null &&
    container.mrp !== undefined &&
    Number(container.mrp) > Number(container.sellingPrice);

  const detailRows = [
    ["Material", container.material],
    ["Code / SKU", container.code],
    ["Outer dimensions", formatDimensions(container.outerDimensions)],
    ["Inner dimensions", formatDimensions(container.innerDimensions)],
    ["Max content weight", formatWeight(container.maxContentWeight)],
    [
      "Usable volume",
      container.usableVolumePercent !== null &&
      container.usableVolumePercent !== undefined
        ? `${container.usableVolumePercent}%`
        : "Not specified",
    ],
    [
      "Maximum items",
      Number(container.maxItems || 0) > 0
        ? String(container.maxItems)
        : "Not specified",
    ],
  ];

  return (
    <DetailModalPortal onClose={onClose}>
      <div
        className="v13-modal-backdrop fixed inset-0 z-[99999] flex items-center justify-center bg-black/62 p-3 backdrop-blur-[5px] sm:p-6"
        role="dialog"
        aria-modal="true"
        aria-label={`${container.name} details`}
        onMouseDown={(event) => {
          if (event.target === event.currentTarget) onClose();
        }}
      >
        <div
          className="v13-modal-panel flex max-h-[calc(100dvh-24px)] w-full max-w-[900px] flex-col overflow-hidden rounded-[22px] border border-white/15 bg-white shadow-[0_35px_120px_rgba(0,0,0,.38)] sm:max-h-[88dvh] sm:rounded-[28px]"
          onMouseDown={(event) => event.stopPropagation()}
        >
          <div className="flex shrink-0 items-center justify-between gap-5 border-b border-black/[0.07] bg-white px-5 py-4 sm:px-6 sm:py-5">
            <div className="min-w-0">
              <div className="flex items-center gap-2.5">
                <span className="h-2 w-2 rounded-full bg-[#F47822]" />
                <p className="text-[11px] font-black uppercase tracking-[0.16em] text-[#F47822]">
                  Box details
                </p>
              </div>

              <h3
                style={{ fontFamily: DISPLAY_FONT }}
                className="mt-1.5 truncate text-[27px] font-semibold leading-none tracking-[-0.025em] text-[#171717] sm:text-[32px]"
              >
                {container.name}
              </h3>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-black/[0.08] bg-[#FAF8F5] text-[22px] leading-none text-black/48 transition hover:border-[#F47822]/35 hover:bg-[#FFF7F1] hover:text-[#F47822]"
              aria-label="Close box details"
            >
              ×
            </button>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain [scrollbar-width:thin]">
            <div className="grid lg:grid-cols-[350px_minmax(0,1fr)]">
              <div className="border-b border-black/[0.07] bg-[#F7F2EB] p-5 lg:border-b-0 lg:border-r lg:p-6">
                <div className="overflow-hidden rounded-[20px] border border-black/[0.06] bg-white shadow-[0_12px_30px_rgba(0,0,0,.04)]">
                  <div className="aspect-[4/3] bg-[#FBF8F4]">
                    <CatalogGalleryImage images={container.images} name={container.name} imageClassName="h-full w-full object-contain p-4" />
                  </div>
                </div>

                <div className="mt-5 flex items-end justify-between gap-4">
                  <div>
                    <p className="text-[11px] font-black uppercase tracking-[0.11em] text-black/30">
                      Box price
                    </p>
                    <div className="mt-1 flex flex-wrap items-baseline gap-2">
                      <span className="text-[25px] font-black text-[#171717]">
                        {hasPrice
                          ? formatCurrency(container.sellingPrice)
                          : "Price pending"}
                      </span>
                      {hasMrp && (
                        <span className="text-[11px] font-semibold text-black/30 line-through">
                          {formatCurrency(container.mrp)}
                        </span>
                      )}
                    </div>
                  </div>

                  {active && (
                    <span className="rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-[11px] font-black text-emerald-700">
                      ✓ Selected
                    </span>
                  )}
                </div>
              </div>

              <div className="p-5 sm:p-6 lg:p-7">
                <div className="flex items-center justify-between gap-4">
                  <p className="text-[12px] font-black uppercase tracking-[0.13em] text-[#9A7316]">
                    Box information
                  </p>
                  <span className="text-[11px] font-semibold text-black/28">
                    All available catalogue data
                  </span>
                </div>

                <div className="mt-3 grid gap-x-7 sm:grid-cols-2">
                  {detailRows.map(([label, value]) => (
                    <V10DetailRow
                      key={label}
                      label={label}
                      value={value}
                    />
                  ))}
                </div>

                {!builderReady && (
                  <div className="mt-5 rounded-[16px] border border-amber-200 bg-amber-50 px-4 py-3">
                    <p className="text-[11px] font-black uppercase tracking-[0.1em] text-amber-700">
                      Data pending for Custom Hamper
                    </p>
                    <p className="mt-1.5 text-[12px] font-semibold leading-5 text-amber-800/80">
                      {builderReasons.length
                        ? builderReasons.join(" · ")
                        : "This imported box is visible for review, but required builder data is incomplete."}
                    </p>
                  </div>
                )}

                {container.description && (
                  <div className="mt-5 rounded-[16px] bg-[#FAF8F5] p-4">
                    <p className="text-[11px] font-black uppercase tracking-[0.1em] text-black/32">
                      About this box
                    </p>
                    <p className="mt-2 text-[11px] font-semibold leading-5 text-black/52">
                      {container.description}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="shrink-0 border-t border-black/[0.07] bg-white px-5 py-4 sm:px-6">
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-end">
              <button
                type="button"
                onClick={onClose}
                className="h-11 rounded-[11px] border border-black/[0.09] bg-white px-5 text-[11px] font-black text-[#171717] transition hover:bg-[#FAF8F5]"
              >
                Close
              </button>

              <button
                type="button"
                onClick={() => {
                  if (!active) onSelect();
                  onClose();
                }}
                className={`h-11 rounded-[11px] px-6 text-[12px] font-black transition ${
                  active
                    ? "border border-emerald-200 bg-emerald-50 text-emerald-700"
                    : "bg-[#F47822] text-white hover:bg-[#171717]"
                }`}
              >
                {active
                  ? builderReady
                    ? "✓ Selected box"
                    : "✓ Previewing box"
                  : builderReady
                    ? "Select this box"
                    : "Preview this box"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </DetailModalPortal>
  );
};

// V88: Responsive Spotlight Hover is CSS-only and anchored to the card itself.
// No fixed-position photo portal, viewport calculations or extra image requests.
// Full product photos and manual controls remain in the existing Details modal.

const V7ContainerCard = ({ container, active, onClick }) => {
  const [detailsOpen, setDetailsOpen] = useState(false);
  // V89: Run this card's photo slideshow only while a real pointer hovers it.
  const [photoHovered, setPhotoHovered] = useState(false);
  const beginPhotoHover = (event) => {
    if (event.pointerType === "mouse" || event.pointerType === "pen") {
      setPhotoHovered(true);
    }
  };
  const endPhotoHover = () => setPhotoHovered(false);
  const hasPrice = container.sellingPrice !== null && container.sellingPrice !== undefined;
  const builderReady = container.builderStatus?.selectable !== false;
  const builderReasons = Array.isArray(container.builderStatus?.reasons)
    ? container.builderStatus.reasons : [];
  const popularity = container.popularity || null;
  const popularityLabel = popularity?.label || "";
  const hamperSoldCount = Number(popularity?.soldCount || 0);

  const handleCardClick = (event) => {
    if (event.target.closest("button")) return;
    setDetailsOpen(true);
  };

  return (
    <>
      <article
        className={`v83-card v85-box-card group cursor-pointer ${active ? "is-selected" : ""}`}
        style={v83CardTheme(container)}
        onPointerEnter={beginPhotoHover}
        onPointerLeave={endPhotoHover}
        onClick={handleCardClick}
        onKeyDown={(event) => {
          if (event.target !== event.currentTarget) return;
          if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            setDetailsOpen(true);
          }
        }}
        tabIndex={0}
        aria-label={`${container.name}. Click for box details.`}
      >
        <div className="v83-media">
          <div className="v83-photo">
            <CatalogGalleryImage
              images={container.images}
              name={container.name}
              imageClassName="h-full w-full object-cover"
              autoPlay={photoHovered && !detailsOpen}
              showControls={false}
            />
          </div>
          {popularityLabel && (
            <span className="v83-recommend" title={`${popularityLabel}${hamperSoldCount > 0 ? ` · ${hamperSoldCount} hampers chosen` : ""}`}>
              ★ {popularityLabel}
            </span>
          )}
          {!builderReady && (
            <span className="v83-pending" style={popularityLabel ? { top: "42px" } : undefined} title={builderReasons.join(", ")}>
              Data pending
            </span>
          )}
          {active && <span className="v83-quantity-badge">✓ Selected</span>}
        </div>
        <div className="v83-content">
          <div className="v83-topline">
            <span className="v83-category" title={container.material || "Hamper box"}>
              {container.material || "Hamper box"}
            </span>
            <span className="v83-topline-star" aria-hidden="true">✦</span>
          </div>
          <p className="v83-title" title={container.name}>{container.name}</p>
          <div className="v83-price-row">
            <span className="v83-price">
              {hasPrice ? formatCurrency(container.sellingPrice) : "Price pending"}
            </span>
          </div>
          <div className="v83-rule" aria-hidden="true" />
          <div className="v83-actions" onClick={(event) => event.stopPropagation()}>
            <button
              type="button"
              className="v83-btn v83-btn-details"
              onClick={(event) => { event.stopPropagation(); setDetailsOpen(true); }}
              aria-label={`View details for ${container.name}`}
            >
              Details ↗
            </button>
            <button
              type="button"
              className={`v83-btn ${active ? "v85-box-selected" : "v83-btn-add"}`}
              onClick={(event) => { event.stopPropagation(); if (!active) onClick(); }}
              aria-label={`${active ? "Selected" : builderReady ? "Select" : "Preview"} ${container.name}`}
            >
              {active ? "✓ Selected" : builderReady ? "Select" : "Preview"}
            </button>
          </div>
        </div>
      </article>
      {detailsOpen && (
        <V11ContainerDetailsModal
          container={container}
          active={active}
          onSelect={onClick}
          onClose={() => setDetailsOpen(false)}
        />
      )}
    </>
  );
};

const V7ContainerSpecRow = ({ label, value, divider = false }) => (
  <div
    className={`grid grid-cols-[52px_minmax(0,1fr)] items-center gap-2 px-3 py-2.5 ${
      divider ? "border-t border-black/[0.05]" : ""
    }`}
  >
    <span className="text-[12px] font-black uppercase tracking-[0.08em] text-black/28">
      {label}
    </span>
    <span
      className="truncate text-right text-[11px] font-extrabold text-black/58"
      title={value}
    >
      {value}
    </span>
  </div>
);

const V7ContainerMetric = ({ label, value }) => (
  <div className="min-w-0 rounded-[12px] border border-black/[0.055] bg-white px-3 py-2.5 shadow-[0_3px_10px_rgba(23,23,23,.02)]">
    <p className="text-[12px] font-black uppercase tracking-[0.08em] text-black/25">
      {label}
    </p>
    <p className="mt-1 truncate text-[11px] font-extrabold text-black/60" title={value}>
      {value}
    </p>
  </div>
);

const V7ProductSpec = ({ label, value, wide = false }) => (
  <div
    className={`min-w-0 rounded-[11px] border border-black/[0.055] bg-[#FAF8F5] px-2.5 py-2 ${
      wide ? "col-span-2" : ""
    }`}
  >
    <p className="text-[11px] font-black uppercase tracking-[0.07em] text-black/34">
      {label}
    </p>
    <p
      className="mt-1 truncate text-[12px] font-extrabold text-black/60"
      title={value}
    >
      {value}
    </p>
  </div>
);

const V7FoodInfo = ({ component }) => {
  const hasExpiry = Boolean(component.expiryDate);
  const hasShelfLife =
    component.shelfLifeDays !== null &&
    component.shelfLifeDays !== undefined;

  return (
    <div className="mt-2.5 overflow-hidden rounded-[12px] border border-[#E9C66A]/28 bg-[#FFFCF4]">
      <div className="flex items-center justify-between gap-3 px-3 py-2.5">
        <div className="min-w-0">
          <p className="text-[12px] font-black uppercase tracking-[0.08em] text-[#9B7616]/70">
            Best before / expiry
          </p>
          <p className="mt-1 truncate text-[11px] font-extrabold text-[#6D5313]">
            {hasExpiry ? formatDate(component.expiryDate) : "Not specified"}
          </p>
        </div>

        {hasShelfLife && (
          <span className="shrink-0 rounded-full bg-[#D4AF37]/12 px-2.5 py-1 text-[12px] font-black text-[#8A6815]">
            {component.shelfLifeDays} days
          </span>
        )}
      </div>

      {component.dietary && (
        <div className="border-t border-[#D4AF37]/12 px-3 py-2 text-[12px] font-bold text-[#8A6815]/75">
          {component.dietary}
        </div>
      )}
    </div>
  );
};

const V10QuickSpec = ({ label, value }) => (
  <div className="min-w-0 rounded-[9px] border border-black/[0.06] bg-[#FAF8F5] px-2 py-2">
    <p className="text-[12px] font-black uppercase tracking-[0.07em] text-black/35">
      {label}
    </p>
    <p
      className="mt-1 truncate text-[12px] font-extrabold text-black/62"
      title={value}
    >
      {value || "—"}
    </p>
  </div>
);

const V10DetailRow = ({ label, value, accent = false }) => (
  <div className="grid grid-cols-[118px_minmax(0,1fr)] gap-4 border-b border-black/[0.055] py-3 last:border-b-0">
    <span className="text-[11px] font-black uppercase tracking-[0.08em] text-black/32">
      {label}
    </span>
    <span
      className={`min-w-0 break-words text-[11px] font-bold leading-5 ${
        accent ? "text-[#F47822]" : "text-[#171717]"
      }`}
    >
      {value || "Not specified"}
    </span>
  </div>
);

const V10ProductDetailsModal = ({
  component,
  quantity,
  cannotIncrease,
  onMinus,
  onPlus,
  onClose,
  eyebrow = "Product details",
  addLabel = "+ Add to hamper",
}) => {
  const missingPrice =
    component.sellingPrice === null ||
    component.sellingPrice === undefined;
  const builderBlocked = component.builderStatus?.selectable === false;
  const builderReasons = Array.isArray(component.builderStatus?.reasons)
    ? component.builderStatus.reasons
    : [];

  const hasMrp =
    !missingPrice &&
    component.mrp !== null &&
    component.mrp !== undefined &&
    Number(component.mrp) > Number(component.sellingPrice);

  // V82: Only show meaningful facts actually supplied for this product.
  // Non-food gifts never show the food-only expiry/shelf-life/dietary slots.
  const productType = String(component.type || "").trim().toLowerCase();
  const foodCategory = `${component.category || ""} ${component.subcategory || ""}`.toLowerCase();
  const explicitlyNonFood = /non[\s-]?food/.test(`${productType} ${foodCategory}`);
  const isFood = !explicitlyNonFood && (
    productType === "food" ||
    /food|edible|snack|sweet|chocolate|bakery|beverage|drink|gourmet/.test(foodCategory)
  );

  const useful = (value) => {
    if (value === undefined || value === null || value === "") return false;
    if (typeof value === "number") return Number.isFinite(value) && value > 0;
    if (typeof value !== "string") return false;
    const text = value.trim().toLowerCase();
    return Boolean(text) && ![
      "—", "-", "n/a", "na", "not applicable", "not specified",
      "not provided", "not available", "none", "null", "undefined",
      "unknown", "not expiry tracked", "not tracked",
    ].includes(text);
  };

  const details = [];
  const include = (label, value) => {
    if (useful(value)) details.push([label, String(value).trim()]);
  };

  include("Brand", component.brand);
  include("Code / SKU", component.code);
  include("Category", component.category);
  include("Subcategory", component.subcategory);
  include("Size / pack", formatPackSize(component));
  include("Weight", formatWeight(component.weight));
  include("Dimensions", formatDimensions(component.dimensions));

  if (isFood) {
    if (component.expiryTracked !== false && component.expiryDate && formatDate(component.expiryDate) !== "—") {
      include("Expiry", formatDate(component.expiryDate));
    }
    if (Number(component.shelfLifeDays) > 0) {
      include("Shelf life", `${component.shelfLifeDays} days`);
    }
    include("Dietary", component.dietary);
  }

  // Display meaningful handling and customisation options, not a grid of "No".
  if (component.fragile === true) include("Handling", "Fragile – handle with care");
  if (component.personalizable === true) {
    include("Personalisation", component.personalizationMethod || "Available");
  }
  // The price area already communicates GST; do not duplicate unavailable tax data.
  const hasFoodFreshness = isFood && details.some(([label]) => label === "Expiry" || label === "Shelf life");

  return (
    <DetailModalPortal onClose={onClose}>
      <div
        className="v13-modal-backdrop fixed inset-0 z-[99999] flex items-center justify-center bg-black/62 p-3 backdrop-blur-[5px] sm:p-6"
        role="dialog"
        aria-modal="true"
        aria-label={`${component.name} details`}
        onMouseDown={(event) => {
          if (event.target === event.currentTarget) onClose();
        }}
      >
        <div
          className="v13-modal-panel flex max-h-[calc(100dvh-24px)] w-full max-w-[980px] flex-col overflow-hidden rounded-[22px] border border-white/15 bg-white shadow-[0_35px_120px_rgba(0,0,0,.38)] sm:max-h-[88dvh] sm:rounded-[28px]"
          onMouseDown={(event) => event.stopPropagation()}
        >
          <div className="flex shrink-0 items-center justify-between gap-5 border-b border-black/[0.07] bg-white px-5 py-4 sm:px-6 sm:py-5">
            <div className="min-w-0">
              <div className="flex items-center gap-2.5">
                <span className="h-2 w-2 rounded-full bg-[#F47822]" />
                <p className="text-[11px] font-black uppercase tracking-[0.16em] text-[#F47822]">
                  {eyebrow}
                </p>
              </div>

              <h3
                style={{ fontFamily: DISPLAY_FONT }}
                className="mt-1.5 truncate text-[27px] font-semibold leading-none tracking-[-0.025em] text-[#171717] sm:text-[32px]"
              >
                {component.name}
              </h3>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-black/[0.08] bg-[#FAF8F5] text-[22px] leading-none text-black/48 transition hover:border-[#F47822]/35 hover:bg-[#FFF7F1] hover:text-[#F47822]"
              aria-label="Close product details"
            >
              ×
            </button>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain [scrollbar-width:thin]">
            <div className="grid lg:grid-cols-[360px_minmax(0,1fr)]">
              <div className="border-b border-black/[0.07] bg-[#F7F2EB] p-5 lg:border-b-0 lg:border-r lg:p-6">
                <div className="overflow-hidden rounded-[20px] border border-black/[0.06] bg-white shadow-[0_12px_30px_rgba(0,0,0,.04)]">
                  <div className="aspect-square bg-[#FBF8F4]">
                    <CatalogGalleryImage images={component.images} name={component.name} imageClassName="h-full w-full object-contain" allowZoom />
                  </div>
                </div>

                <div className="mt-5 flex items-start justify-between gap-4">
                  <div>
                    <p className="text-[11px] font-black uppercase tracking-[0.11em] text-black/30">
                      Selling price
                    </p>
                    <div className="mt-1 flex flex-wrap items-baseline gap-2">
                      <span className="text-[25px] font-black text-[#171717]">
                        {missingPrice
                          ? "Price pending"
                          : formatCurrency(component.sellingPrice)}
                      </span>
                      {hasMrp && (
                        <span className="text-[11px] font-semibold text-black/30 line-through">
                          {formatCurrency(component.mrp)}
                        </span>
                      )}
                    </div>
                    {!missingPrice && (
                      <p className="mt-1 text-[11px] font-semibold text-black/34">
                        {taxLabel(component)}
                      </p>
                    )}
                  </div>

                  <span className="max-w-[46%] truncate rounded-full bg-white px-3 py-1.5 text-[12px] font-black uppercase tracking-[0.08em] text-black/42">
                    {component.subcategory || component.category || "Gift"}
                  </span>
                </div>
              </div>

              <div className="p-5 sm:p-6 lg:p-7">
                <div className="flex items-center justify-between gap-4">
                  <p className="text-[12px] font-black uppercase tracking-[0.13em] text-[#9A7316]">
                    Complete product information
                  </p>
                  <span className="text-[11px] font-semibold text-black/28">
                    Catalogue details
                  </span>
                </div>

                {details.length > 0 && (
                  <div className="mt-3 grid gap-x-7 sm:grid-cols-2">
                    {details.map(([label, value]) => (
                      <V10DetailRow
                        key={label}
                        label={label}
                        value={value}
                        accent={label === "Expiry" && Boolean(component.expiryDate)}
                      />
                    ))}
                  </div>
                )}

                {builderBlocked && (
                  <div className="mt-5 rounded-[16px] border border-amber-200 bg-amber-50 px-4 py-3">
                    <p className="text-[11px] font-black uppercase tracking-[0.1em] text-amber-700">
                      Data pending for Custom Hamper
                    </p>
                    <p className="mt-1.5 text-[12px] font-semibold leading-5 text-amber-800/80">
                      {builderReasons.length
                        ? builderReasons.join(" · ")
                        : "This imported item is visible for review, but required builder data is incomplete."}
                    </p>
                  </div>
                )}

                {useful(component.description) && (
                  <div className="mt-5 rounded-[16px] bg-[#FAF8F5] p-4">
                    <p className="text-[11px] font-black uppercase tracking-[0.1em] text-black/32">
                      Description
                    </p>
                    <p className="mt-2 text-[11px] font-semibold leading-5 text-black/52">
                      {component.description}
                    </p>
                  </div>
                )}

                {hasFoodFreshness && (
                  <div className="mt-4 flex items-start gap-3 border-l-[3px] border-[#D4AF37] bg-[#FFFCF5] px-4 py-3.5">
                    <span className="mt-0.5 text-[#9A7316]">✦</span>
                    <div>
                      <p className="text-[11px] font-black uppercase tracking-[0.1em] text-[#8B6817]">
                        Food freshness
                      </p>
                      <p className="mt-1.5 text-[12px] font-semibold leading-5 text-black/48">
                        Expiry and shelf-life values are shown directly from this catalogue item. Missing values are not invented.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="shrink-0 border-t border-black/[0.07] bg-white px-5 py-4 sm:px-6">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="hidden sm:block">
                <p className="text-[11px] font-black uppercase tracking-[0.1em] text-black/28">
                  In your hamper
                </p>
                <p className="mt-0.5 text-[12px] font-black text-[#171717]">
                  {quantity > 0 ? `${quantity} selected` : "Not added yet"}
                </p>
              </div>

              <div className="flex items-center gap-2 sm:min-w-[310px] sm:justify-end">
                <button
                  type="button"
                  onClick={onClose}
                  className="h-11 flex-1 rounded-[11px] border border-black/[0.09] bg-white px-5 text-[11px] font-black text-[#171717] transition hover:bg-[#FAF8F5] sm:flex-none"
                >
                  Close
                </button>

                {quantity > 0 ? (
                  <div className="grid h-11 flex-1 grid-cols-[44px_1fr_44px] overflow-hidden rounded-[11px] border border-[#F47822]/25 bg-[#FFF8F2] sm:w-[170px] sm:flex-none">
                    <button
                      type="button"
                      onClick={onMinus}
                      className="text-base font-black transition hover:bg-black/[0.04]"
                      aria-label={`Remove ${component.name}`}
                    >
                      −
                    </button>
                    <span className="flex items-center justify-center border-x border-[#F47822]/15 text-[13px] font-black">
                      {quantity}
                    </span>
                    <button
                      type="button"
                      disabled={cannotIncrease}
                      onClick={onPlus}
                      className="text-base font-black text-[#F47822] transition hover:bg-[#F47822] hover:text-white disabled:cursor-not-allowed disabled:opacity-25"
                      aria-label={`Add ${component.name}`}
                    >
                      +
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    disabled={cannotIncrease}
                    onClick={onPlus}
                    className="h-11 flex-1 rounded-[11px] bg-[#F47822] px-6 text-[12px] font-black text-white transition hover:bg-[#171717] disabled:cursor-not-allowed disabled:bg-black/10 disabled:text-black/25 sm:flex-none"
                  >
                    {addLabel}
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </DetailModalPortal>
  );
};

// V83 - palette is stable for each SKU, keeping a colourful collection without
// changing actual product photos or any price/stock/cart calculation.
const V83_CARD_THEMES = [
  { accent: "#DA5278", deep: "#983452", second: "#F4B381", soft: "#FFF1F4", tint: "#FCE0E9", border: "#F5C9D5", shadow: "rgba(177,64,105,.18)" },
  { accent: "#7562D9", deep: "#4D3DA8", second: "#C19DFF", soft: "#F3F0FF", tint: "#E7E1FF", border: "#D9D0FF", shadow: "rgba(106,82,196,.18)" },
  { accent: "#168F7C", deep: "#0D665B", second: "#79D7B7", soft: "#EEFAF5", tint: "#D6F3E6", border: "#C4E9DB", shadow: "rgba(28,132,105,.17)" },
  { accent: "#DB762F", deep: "#A94B23", second: "#F4C46E", soft: "#FFF6EB", tint: "#FDE7CF", border: "#F4D8BE", shadow: "rgba(181,102,39,.18)" },
  { accent: "#347DD2", deep: "#25589B", second: "#8FC9F0", soft: "#EFF8FF", tint: "#DCEEFF", border: "#C7E2F7", shadow: "rgba(49,110,174,.17)" },
  { accent: "#B45BA8", deep: "#813E82", second: "#E6A1D0", soft: "#FCF0F9", tint: "#F5DDF0", border: "#E9C9E4", shadow: "rgba(157,75,137,.18)" },
];

const v83CardTheme = (component) => {
  const key = String(component?._id || component?.code || component?.name || "gift");
  const palette = V83_CARD_THEMES[v7Hash(key) % V83_CARD_THEMES.length];
  return {
    "--v83-accent": palette.accent,
    "--v83-deep": palette.deep,
    "--v83-second": palette.second,
    "--v83-soft": palette.soft,
    "--v83-tint": palette.tint,
    "--v83-border": palette.border,
    "--v83-shadow": palette.shadow,
  };
};

const V7ProductCard = ({
  component,
  quantity,
  selected,
  locked,
  checking,
  fitLeft,
  recommendation = null,
  onMinus,
  onPlus,
}) => {
  const [detailsOpen, setDetailsOpen] = useState(false);
  // V89: Run this card's photo slideshow only while a real pointer hovers it.
  const [photoHovered, setPhotoHovered] = useState(false);
  const beginPhotoHover = (event) => {
    if (event.pointerType === "mouse" || event.pointerType === "pen") {
      setPhotoHovered(true);
    }
  };
  const endPhotoHover = () => setPhotoHovered(false);
  const missingPrice = component.sellingPrice === null || component.sellingPrice === undefined;
  const builderBlocked = component.builderStatus?.selectable === false;
  const builderReasons = Array.isArray(component.builderStatus?.reasons)
    ? component.builderStatus.reasons : [];
  const recommendationLabel = recommendation?.source === "container"
    ? Number(recommendation?.rank || 0) === 1 ? "Top pick" : "Recommended"
    : recommendation?.source === "overall" ? "Popular" : "";
  const recommendationPickedCount = Number(recommendation?.pickedCount || 0);
  const cannotIncrease = checking || missingPrice || builderBlocked || locked || quantity >= 99;
  const hasMrp = !missingPrice && component.mrp !== null && component.mrp !== undefined &&
    Number(component.mrp) > Number(component.sellingPrice);
  const handleCardClick = (event) => {
    if (event.target.closest("button")) return;
    setDetailsOpen(true);
  };
  const actionLabel = checking ? "Checking" : missingPrice || builderBlocked
    ? "Pending" : Number(fitLeft || 0) <= 0 ? "No fit" : "+ Add";

  return (
    <>
      <article
        className={`v83-card group cursor-pointer ${selected ? "is-selected" : ""}`}
        style={v83CardTheme(component)}
        onPointerEnter={beginPhotoHover}
        onPointerLeave={endPhotoHover}
        onClick={handleCardClick}
        onKeyDown={(event) => {
          if (event.target !== event.currentTarget) return;
          if (event.key === "Enter" || event.key === " ") {
            event.preventDefault(); setDetailsOpen(true);
          }
        }}
        tabIndex={0}
        aria-label={`${component.name}. Click for details.`}
      >
        <div className="v83-media">
          <div className="v83-photo">
            <CatalogGalleryImage images={component.images} name={component.name}
              imageClassName="h-full w-full object-cover" autoPlay={photoHovered && !detailsOpen} showControls={false} />
          </div>
          {recommendationLabel && !builderBlocked && (
            <span className="v83-recommend" title={`${recommendationLabel}${recommendationPickedCount > 0 ? ` · ${recommendationPickedCount} picked with this box` : ""}`}>
              ✦ {recommendationLabel}
            </span>
          )}
          {builderBlocked && (
            <span className="v83-pending" title={builderReasons.join(", ")}>Data pending</span>
          )}
          {selected && <span className="v83-quantity-badge">✓ {quantity} added</span>}
        </div>
        <div className="v83-content">
          <div className="v83-topline">
            <span className="v83-category" title={component.subcategory || component.category || "Gift collection"}>
              {component.subcategory || component.category || "Gift collection"}
            </span>
            <span className="v83-topline-star" aria-hidden="true">✦</span>
          </div>
          <p className="v83-title" title={component.name}>{component.name}</p>
          <div className="v83-price-row">
            <span className="v83-price">{missingPrice ? "Price pending" : formatCurrency(component.sellingPrice)}</span>
            {hasMrp && <span className="v83-mrp">{formatCurrency(component.mrp)}</span>}
          </div>
          <div className="v83-rule" aria-hidden="true" />
          <div className="v83-actions" onClick={(event) => event.stopPropagation()}>
            <button type="button" className="v83-btn v83-btn-details"
              onClick={(event) => { event.stopPropagation(); setDetailsOpen(true); }}
              aria-label={`View details for ${component.name}`}>
              Details ↗
            </button>
            {quantity > 0 ? (
              <div className="v83-qty">
                <button type="button" onClick={(event) => { event.stopPropagation(); onMinus(); }} aria-label={`Remove ${component.name}`}>−</button>
                <strong>{quantity}</strong>
                <button type="button" disabled={cannotIncrease} onClick={(event) => { event.stopPropagation(); onPlus(); }} aria-label={`Add ${component.name}`}>+</button>
              </div>
            ) : (
              <button type="button" disabled={cannotIncrease} className="v83-btn v83-btn-add"
                onClick={(event) => { event.stopPropagation(); onPlus(); }}>
                {actionLabel}
              </button>
            )}
          </div>
        </div>
      </article>
      {detailsOpen && (
        <V10ProductDetailsModal component={component} quantity={quantity}
          cannotIncrease={cannotIncrease} onMinus={onMinus} onPlus={onPlus}
          onClose={() => setDetailsOpen(false)} />
      )}
    </>
  );
};

const V7DecorationCard = ({ component, quantity, onMinus, onPlus }) => {
  const [detailsOpen, setDetailsOpen] = useState(false);
  // V89: Run this card's photo slideshow only while a real pointer hovers it.
  const [photoHovered, setPhotoHovered] = useState(false);
  const beginPhotoHover = (event) => {
    if (event.pointerType === "mouse" || event.pointerType === "pen") {
      setPhotoHovered(true);
    }
  };
  const endPhotoHover = () => setPhotoHovered(false);
  const selected = quantity > 0;
  const missingPrice = component.sellingPrice === null || component.sellingPrice === undefined;
  const builderBlocked = component.builderStatus?.selectable === false;
  const builderReasons = Array.isArray(component.builderStatus?.reasons)
    ? component.builderStatus.reasons : [];
  const cannotIncrease = missingPrice || builderBlocked || quantity >= 99;
  const handleCardClick = (event) => {
    if (event.target.closest("button")) return;
    setDetailsOpen(true);
  };

  return (
    <>
      <article className={`v83-card v83-decor group cursor-pointer ${selected ? "is-selected" : ""}`}
        style={v83CardTheme(component)} onPointerEnter={beginPhotoHover} onPointerLeave={endPhotoHover} onClick={handleCardClick}
        onKeyDown={(event) => {
          if (event.target !== event.currentTarget) return;
          if (event.key === "Enter" || event.key === " ") {
            event.preventDefault(); setDetailsOpen(true);
          }
        }}
        tabIndex={0} aria-label={`${component.name}. Click for details.`}>
        <div className="v83-media">
          <div className="v83-photo">
            <CatalogGalleryImage images={component.images} name={component.name}
              imageClassName="h-full w-full object-cover"
              fallback={<V7DecorPlaceholder component={component} />} autoPlay={photoHovered && !detailsOpen} showControls={false} />
          </div>
          {builderBlocked && <span className="v83-pending" title={builderReasons.join(", ")}>Data pending</span>}
          {selected && <span className="v83-quantity-badge">✓ {quantity} added</span>}
        </div>
        <div className="v83-content">
          <div className="v83-topline"><span className="v83-category">{component.subcategory || component.category || "The final touch"}</span><span className="v83-topline-star" aria-hidden="true">✦</span></div>
          <p className="v83-title" title={component.name}>{component.name}</p>
          <div className="v83-price-row">
            <span className="v83-price">{missingPrice ? "Price pending" : formatCurrency(component.sellingPrice)}</span>
          </div>
          <div className="v83-rule" aria-hidden="true" />
          <div className="v83-actions" onClick={(event) => event.stopPropagation()}>
            <button type="button" className="v83-btn v83-btn-details"
              onClick={(event) => { event.stopPropagation(); setDetailsOpen(true); }}
              aria-label={`View details for ${component.name}`}>
              Details ↗
            </button>
            {quantity > 0 ? (
              <div className="v83-qty">
                <button type="button" onClick={(event) => { event.stopPropagation(); onMinus(); }}
                  aria-label={`Remove ${component.name}`}>−</button>
                <strong>{quantity}</strong>
                <button type="button" disabled={cannotIncrease}
                  onClick={(event) => { event.stopPropagation(); onPlus(); }}
                  aria-label={`Add ${component.name}`}>+</button>
              </div>
            ) : (
              <button type="button" disabled={cannotIncrease} className="v83-btn v83-btn-add"
                onClick={(event) => { event.stopPropagation(); onPlus(); }}>
                + Add
              </button>
            )}
          </div>
        </div>
      </article>
      {detailsOpen && (
        <V10ProductDetailsModal component={component} quantity={quantity}
          cannotIncrease={cannotIncrease} onMinus={onMinus} onPlus={onPlus}
          onClose={() => setDetailsOpen(false)} eyebrow="Finishing details" addLabel="+ Add finishing" />
      )}
    </>
  );
};
const V7DecorPlaceholder = ({ component }) => {
  const name = String(component?.name || "").toLowerCase();

  if (/flower|rose|floral/.test(name)) {
    return (
      <div className="flex h-full items-center justify-center text-[28px] text-[#B7697C]">
        ✿
      </div>
    );
  }

  if (/ribbon|bow/.test(name)) {
    return (
      <div className="flex h-full items-center justify-center text-[26px] text-[#B78B18]">
        ⌁
      </div>
    );
  }

  if (/tag|card|note/.test(name)) {
    return (
      <div className="flex h-full items-center justify-center text-[24px] text-[#8A6B24]">
        ◇
      </div>
    );
  }

  return (
    <div className="flex h-full items-center justify-center text-[24px] text-[#B78B18]">
      ✦
    </div>
  );
};

const V7Studio = ({
  selectedContainer,
  previewItems,
  previewDecorations,
  selectedItemCount,
  selectedDecorationCount,
  fillPercent,
  configuration,
  personalization,
  canIncreaseAnyItem,
  validating,
  cartError,
  canAddToCart,
  addingToCart,
  deliveryJourney = "idle",
  user,
  isEditingCartHamper = false,
  orderMode = "personal",
  bulkQuantity = 0,
  onAddToCart,
}) => {
  const pricing = configuration?.pricing;
  const timing = configuration?.deliveryEstimate;
  const notReadyMessage =
    configuration && !configuration.orderable ? configuration.message : "";
  const roundedFill = Math.round(Number(fillPercent || 0));
  const unavailableCartMessage =
    /no longer available for custom gifting|inactive, unavailable for this channel|unavailable for custom hampers/i.test(
      String(cartError || "")
    )
      ? "One of the selected gifts or finishing touches changed availability. Update the selection once and try again."
      : cartError;

  return (
    <div className="v30-live-shell v34-live-flat min-w-0 xl:pl-1 2xl:pl-2">
      <div>
        <V7OpenTop3D
          selectedContainer={selectedContainer}
          previewItems={previewItems}
          previewDecorations={previewDecorations}
          selectedItemCount={selectedItemCount}
          selectedDecorationCount={selectedDecorationCount}
          fillPercent={fillPercent}
          configuration={configuration}
          canIncreaseAnyItem={canIncreaseAnyItem}
          validating={validating}
          journeyState={deliveryJourney}
        />

        <div className="mt-3 grid grid-cols-3 gap-2">
          <div className="rounded-xl bg-black/[0.035] px-3 py-3.5">
            <p className="text-[12px] font-black uppercase tracking-[0.07em] text-black/45 sm:text-[11px]">Gifts</p>
            <p className="mt-1.5 text-[19px] font-black leading-none text-[#171717] sm:text-[21px]">{selectedItemCount}</p>
          </div>
          <div className="rounded-xl bg-black/[0.035] px-3 py-3.5">
            <p className="text-[12px] font-black uppercase tracking-[0.07em] text-black/45 sm:text-[11px]">Filled</p>
            <p className="mt-1.5 text-[19px] font-black leading-none text-[#171717] sm:text-[21px]">{roundedFill}%</p>
          </div>
          <div className="min-w-0 rounded-xl bg-black/[0.035] px-3 py-3.5 text-right">
            <p className="text-[12px] font-black uppercase tracking-[0.07em] text-black/45 sm:text-[11px]">{orderMode === "bulk" ? "Per hamper" : "Total"}</p>
            <p style={{ fontFamily: DISPLAY_FONT }} className="mt-1 truncate text-[21px] font-semibold leading-none text-[#F47822] sm:text-[23px]">
              {pricing?.total === null || pricing?.total === undefined ? "—" : formatCurrency(pricing.total)}
            </p>
          </div>
        </div>


        {orderMode === "bulk" && pricing?.total !== null && pricing?.total !== undefined && (
          <div className="mt-3 flex items-center justify-between gap-3 border-y border-black/[0.10] py-2.5 text-[#171717]">
            <span className="text-[12px] font-black uppercase tracking-[0.07em] text-black/45 sm:text-[11px]">{Number(bulkQuantity || 0).toLocaleString("en-IN")} hampers</span>
            <span className="text-[13px] font-black sm:text-[14px]">{formatCurrency(Number(pricing.total || 0) * Number(bulkQuantity || 0))}</span>
          </div>
        )}

        {(timing?.expectedDeliveryDate || configuration?.earliestExpiryDate) && (
          <div className="mt-4 grid gap-2 sm:grid-cols-2">
            {timing?.expectedDeliveryDate && (
              <div className="flex items-center gap-2.5 border-t border-black/[0.06] py-2.5 text-[11px] font-bold text-black/62 sm:text-[12px]">
                <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-[#F47822]" />
                <span><strong className="font-black text-[#171717]">Delivery</strong> · {formatDate(timing.expectedDeliveryDate)}</span>
              </div>
            )}
            {configuration?.earliestExpiryDate && (
              <div className="flex items-center gap-2.5 border-t border-[#D4AF37]/18 py-2.5 text-[11px] font-bold text-black/62 sm:text-[12px]">
                <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-[#D4AF37]" />
                <span><strong className="font-black text-[#171717]">Earliest expiry</strong> · {formatDate(configuration.earliestExpiryDate)}</span>
              </div>
            )}
          </div>
        )}

        {notReadyMessage && selectedItemCount > 0 && (
          <div className="mt-3 border-l-[3px] border-amber-500 bg-amber-50 px-3.5 py-3 text-[11px] font-semibold leading-5 text-amber-900 sm:text-[12px]">
            {notReadyMessage}
          </div>
        )}
        {unavailableCartMessage && (
          <div className="mt-3 border-l-[3px] border-red-500 bg-red-50 px-3.5 py-3 text-[11px] font-semibold leading-5 text-red-700 sm:text-[12px]">
            {unavailableCartMessage}
          </div>
        )}

        <button
          type="button"
          onClick={onAddToCart}
          disabled={!canAddToCart}
          className={`v10-primary-cta mt-4 flex h-[48px] w-full items-center justify-center gap-3 rounded-[11px] px-5 text-[11px] font-black uppercase sm:text-[12px] tracking-[0.07em] transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:translate-y-0 disabled:bg-black/10 disabled:text-black/25 disabled:shadow-none ${
            orderMode === "bulk"
              ? "bg-[#171717] text-white shadow-[0_12px_28px_rgba(23,23,23,.16)] hover:bg-[#9B7616]"
              : "bg-[#F47822] text-white shadow-[0_12px_28px_rgba(244,120,34,.18)] hover:bg-[#171717]"
          }`}
        >
          {addingToCart
            ? orderMode === "bulk"
              ? "Submitting request…"
              : deliveryJourney === "shipping"
                ? "Sending for delivery…"
                : deliveryJourney === "packing"
                  ? "Packing hamper…"
                  : isEditingCartHamper
                    ? "Saving changes…"
                    : "Adding…"
            : user
              ? orderMode === "bulk"
                ? "Request quotation"
                : isEditingCartHamper
                  ? "Save hamper changes"
                  : "Add to cart"
              : orderMode === "bulk"
                ? "Login to request quote"
                : isEditingCartHamper
                  ? "Login to save changes"
                  : "Login to add"}
          {!addingToCart && <span>→</span>}
        </button>
 
      </div>
    </div>
  );
};

const V7TinyStat = ({ label, value }) => (
  <div className="min-w-[48px] text-right">
    <p className="text-[12px] font-black uppercase tracking-[0.09em] text-black/26">
      {label}
    </p>
    <p className="mt-1 text-[12px] font-black text-[#171717]">{value}</p>
  </div>
);

const V7PriceRow = ({ label, value }) => (
  <div className="flex items-center justify-between gap-3">
    <span className="text-black/42">{label}</span>
    <span className="font-bold text-[#171717]">
      {value === null || value === undefined ? "—" : formatCurrency(value)}
    </span>
  </div>
);

const v7Clamp = (value, min, max) =>
  Math.min(max, Math.max(min, Number(value || 0)));

const v7Cm = (value, unit = "cm") => {
  const number = Number(value);
  if (!Number.isFinite(number) || number <= 0) return 0;
  return unit === "mm" ? number / 10 : number;
};

const v7Geometry = (container) => {
  const d = container?.innerDimensions || {};
  const unit = d.unit || "cm";
  const length = v7Cm(d.length, unit) || 28;
  const width = v7Cm(d.width, unit) || 22;
  const height = v7Cm(d.height, unit) || 10;
  const volume = Math.max(1, length * width * height);
  const maxFoot = Math.max(length, width, 1);
  const scale = v7Clamp(Math.cbrt(volume) / 24, 0.78, 1.18);
  const displayWidth = v7Clamp(
    (205 + 64 * (length / maxFoot)) * scale,
    184,
    292
  );
  const displayDepth = v7Clamp(
    (124 + 60 * (width / maxFoot)) * scale,
    110,
    192
  );
  const wallHeight = v7Clamp(
    (48 + 70 * (height / maxFoot)) * scale,
    50,
    102
  );

  return {
    length,
    width,
    height,
    volume,
    displayWidth,
    displayDepth,
    wallHeight,
  };
};

const V7_PALETTES = [
  ["#F59A5A", "#9B4F24", "#FFD8B9"],
  ["#E6C45D", "#7C5B16", "#FFF0A7"],
  ["#77B88B", "#315E40", "#D6F0DD"],
  ["#D98EA3", "#7C4051", "#F8D9E2"],
  ["#8199D7", "#40558C", "#DDE6FB"],
  ["#BA8FD0", "#654676", "#F0DFF5"],
];

const v7Hash = (value = "") => {
  let hash = 0;
  for (let i = 0; i < value.length; i += 1) {
    hash = (hash * 31 + value.charCodeAt(i)) >>> 0;
  }
  return hash;
};

const v7Palette = (component) =>
  V7_PALETTES[
    v7Hash(String(component?._id || component?.name || "gift")) %
      V7_PALETTES.length
  ];

const v7ItemKind = (component) => {
  const source = [
    component?.name,
    component?.category,
    component?.subcategory,
    component?.segment,
    component?.sourceProductType,
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();

  if (/bottle|juice|drink|beverage|water|syrup|oil/.test(source)) {
    return "bottle";
  }
  if (/candle|jar|mug|cup|tin|can/.test(source)) return "cylinder";
  if (/chocolate|cookie|biscuit|snack|chips|wafer|bar/.test(source)) {
    return "snack";
  }
  if (/book|card|notebook|diary|frame/.test(source)) return "flat";
  return "gift";
};

const v9PointString = (points = []) =>
  points
    .map(([x, y]) => `${Number(x).toFixed(1)},${Number(y).toFixed(1)}`)
    .join(" ");

const v9LerpPoint = (from, to, amount) => [
  from[0] + (to[0] - from[0]) * amount,
  from[1] + (to[1] - from[1]) * amount,
];

const v9BoxGeometry = (container) => {
  const real = v7Geometry(container);
  const maxHorizontal = Math.max(real.length, real.width, 1);
  const widthRatio = real.length / maxHorizontal;
  const depthRatio = real.width / maxHorizontal;
  const heightRatio = real.height / maxHorizontal;

  const openingWidth = v7Clamp(278 + widthRatio * 62, 280, 340);
  const openingDepth = v7Clamp(94 + depthRatio * 52, 102, 148);
  const wallScreenHeight = v7Clamp(62 + heightRatio * 78, 66, 122);

  const centerX = 220;
  const backY = 48;
  const frontY = backY + openingDepth;
  const backHalf = openingWidth * 0.43;
  const frontHalf = openingWidth * 0.5;

  const outer = {
    backLeft: [centerX - backHalf, backY],
    backRight: [centerX + backHalf, backY],
    frontRight: [centerX + frontHalf, frontY],
    frontLeft: [centerX - frontHalf, frontY],
  };

  const horizontalInset = v7Clamp(openingWidth * 0.065, 18, 24);
  const floorDropBack = wallScreenHeight * 0.6;
  const floorDropFront = wallScreenHeight * 0.42;

  const inner = {
    backLeft: [
      outer.backLeft[0] + horizontalInset,
      outer.backLeft[1] + floorDropBack,
    ],
    backRight: [
      outer.backRight[0] - horizontalInset,
      outer.backRight[1] + floorDropBack,
    ],
    frontRight: [
      outer.frontRight[0] - horizontalInset * 1.15,
      outer.frontRight[1] + floorDropFront,
    ],
    frontLeft: [
      outer.frontLeft[0] + horizontalInset * 1.15,
      outer.frontLeft[1] + floorDropFront,
    ],
  };

  return {
    ...real,
    openingWidth,
    openingDepth,
    wallScreenHeight,
    outer,
    inner,
    viewWidth: 440,
    viewHeight: 320,
  };
};

const v9FloorPoint = (geometry, u, v) => {
  const left = v9LerpPoint(
    geometry.inner.backLeft,
    geometry.inner.frontLeft,
    v
  );
  const right = v9LerpPoint(
    geometry.inner.backRight,
    geometry.inner.frontRight,
    v
  );

  return v9LerpPoint(left, right, u);
};

const v9OuterPoint = (geometry, u, v) => {
  const left = v9LerpPoint(
    geometry.outer.backLeft,
    geometry.outer.frontLeft,
    v
  );
  const right = v9LerpPoint(
    geometry.outer.backRight,
    geometry.outer.frontRight,
    v
  );

  return v9LerpPoint(left, right, u);
};

const v9RibbonBand = (
  geometry,
  { axis = "vertical", center = 0.5, width = 0.1 } = {}
) => {
  const start = Math.max(0, center - width / 2);
  const end = Math.min(1, center + width / 2);

  if (axis === "horizontal") {
    return [
      v9OuterPoint(geometry, 0, start),
      v9OuterPoint(geometry, 1, start),
      v9OuterPoint(geometry, 1, end),
      v9OuterPoint(geometry, 0, end),
    ];
  }

  return [
    v9OuterPoint(geometry, start, 0),
    v9OuterPoint(geometry, end, 0),
    v9OuterPoint(geometry, end, 1),
    v9OuterPoint(geometry, start, 1),
  ];
};

const v9SvgItemSize = (component, geometry, kind, count) => {
  const dimensions = component?.dimensions || {};
  const unit = dimensions.unit || "cm";
  let length = v7Cm(dimensions.length, unit);
  let width = v7Cm(dimensions.width, unit);
  let height = v7Cm(dimensions.height, unit);

  const fallback = {
    bottle: [5, 5, 17],
    cylinder: [8, 8, 10],
    snack: [9, 5, 12],
    flat: [11, 4, 7],
    gift: [8, 7, 8],
  }[kind];

  if (!length || !width || !height) {
    [length, width, height] = fallback;
  }

  const crowdScale =
    count > 14 ? 0.72 : count > 10 ? 0.8 : count > 7 ? 0.88 : 1;

  return {
    width: v7Clamp(
      (28 + 34 * (length / Math.max(geometry.length, 1))) * crowdScale,
      24,
      kind === "flat" ? 52 : 48
    ),
    depth: v7Clamp(
      (15 + 24 * (width / Math.max(geometry.width, 1))) * crowdScale,
      13,
      30
    ),
    height: v7Clamp(
      (27 + 48 * (height / Math.max(geometry.height, 1))) * crowdScale,
      kind === "bottle" ? 38 : 24,
      kind === "bottle" ? 68 : 56
    ),
  };
};

const v9SvgPlacement = ({ index, count, geometry, itemSize }) => {
  const layerCapacity = count > 12 ? 9 : count > 7 ? 8 : 6;
  const layer = Math.floor(index / layerCapacity);
  const slot = index % layerCapacity;
  const slotsThisLayer = Math.min(
    layerCapacity,
    Math.max(1, count - layer * layerCapacity)
  );
  const aspect = geometry.length / Math.max(geometry.width, 1);
  const columns = Math.max(
    2,
    Math.min(4, Math.ceil(Math.sqrt(slotsThisLayer * aspect)))
  );
  const rows = Math.max(1, Math.ceil(slotsThisLayer / columns));
  const row = Math.floor(slot / columns);
  const column = slot % columns;
  const sidePadding = 0.1;
  const depthPadding = 0.12;
  const centeredU = columns === 1 ? 0.5 : (column + 0.5) / columns;
  const centeredV = rows === 1 ? 0.55 : (row + 0.5) / rows;
  const u = sidePadding + centeredU * (1 - sidePadding * 2);
  const v = depthPadding + centeredV * (1 - depthPadding * 2);
  const point = v9FloorPoint(geometry, u, v);
  const layerLift = layer * v7Clamp(itemSize.height * 0.26, 9, 16);
  const turn = columns > 2 ? (column - (columns - 1) / 2) * 1.15 : 0;

  return {
    x: point[0],
    y: point[1] - layerLift,
    turn,
  };
};

const V9SvgGift = ({ component, index, count, geometry }) => {
  const kind = v7ItemKind(component);
  const palette = v7Palette(component);
  const size = v9SvgItemSize(component, geometry, kind, count);
  const placement = v9SvgPlacement({
    index,
    count,
    geometry,
    itemSize: size,
  });
  const [primary, dark, light] = palette;
  const width = size.width;
  const depth = size.depth;
  const height = size.height;
  const skew = depth * 0.48;
  const depthRise = depth * 0.3;
  const topY = -height;
  const hash = v7Hash(String(component?._id || component?.name || index));
  const animationStyle = {
    "--v9-turn": `${placement.turn}deg`,
    animationDelay: `${Math.min(index * 55, 520)}ms`,
  };

  if (kind === "bottle") {
    const bodyWidth = Math.max(18, width * 0.64);
    const bodyHeight = Math.max(34, height * 0.82);
    const neckWidth = Math.max(8, bodyWidth * 0.42);
    const neckHeight = Math.max(8, height * 0.18);

    return (
      <g transform={`translate(${placement.x} ${placement.y})`}>
        <g className="v9-svg-item" style={animationStyle}>
          <ellipse
            cx="0"
            cy="4"
            rx={bodyWidth * 0.62}
            ry="6"
            fill="rgba(0,0,0,.22)"
          />
          <rect
            x={-bodyWidth / 2}
            y={-bodyHeight}
            width={bodyWidth}
            height={bodyHeight}
            rx={bodyWidth * 0.24}
            fill={`url(#v9-item-${hash})`}
            stroke="rgba(20,15,10,.32)"
            strokeWidth="1"
          />
          <ellipse
            cx="0"
            cy={-bodyHeight}
            rx={bodyWidth / 2}
            ry={Math.max(4, bodyWidth * 0.16)}
            fill={light}
            stroke="rgba(20,15,10,.25)"
          />
          <rect
            x={-neckWidth / 2}
            y={-bodyHeight - neckHeight}
            width={neckWidth}
            height={neckHeight}
            rx="3"
            fill={primary}
            stroke="rgba(20,15,10,.25)"
          />
          <ellipse
            cx="0"
            cy={-bodyHeight - neckHeight}
            rx={neckWidth / 2}
            ry="3"
            fill={light}
          />
        </g>
      </g>
    );
  }

  if (kind === "cylinder") {
    const bodyWidth = Math.max(24, width * 0.82);
    const bodyHeight = Math.max(26, height * 0.72);

    return (
      <g transform={`translate(${placement.x} ${placement.y})`}>
        <g className="v9-svg-item" style={animationStyle}>
          <ellipse
            cx="0"
            cy="4"
            rx={bodyWidth * 0.62}
            ry="6"
            fill="rgba(0,0,0,.20)"
          />
          <rect
            x={-bodyWidth / 2}
            y={-bodyHeight}
            width={bodyWidth}
            height={bodyHeight}
            rx="8"
            fill={`url(#v9-item-${hash})`}
            stroke="rgba(20,15,10,.28)"
          />
          <ellipse
            cx="0"
            cy={-bodyHeight}
            rx={bodyWidth / 2}
            ry={Math.max(7, bodyWidth * 0.24)}
            fill={light}
            stroke="rgba(20,15,10,.25)"
          />
        </g>
      </g>
    );
  }

  const a = [-width / 2, topY];
  const b = [width / 2, topY];
  const c = [width / 2 + skew, topY + depthRise];
  const d = [-width / 2 + skew, topY + depthRise];
  const bb = [b[0], b[1] + height];
  const cc = [c[0], c[1] + height];
  const dd = [d[0], d[1] + height];

  return (
    <g transform={`translate(${placement.x} ${placement.y})`}>
      <g className="v9-svg-item" style={animationStyle}>
        <ellipse
          cx={skew * 0.18}
          cy="6"
          rx={width * 0.66}
          ry="7"
          fill="rgba(0,0,0,.20)"
        />
        <polygon
          points={v9PointString([d, c, cc, dd])}
          fill={dark}
          stroke="rgba(20,15,10,.28)"
          strokeWidth="1"
        />
        <polygon
          points={v9PointString([b, c, cc, bb])}
          fill={primary}
          stroke="rgba(20,15,10,.24)"
          strokeWidth="1"
        />
        <polygon
          points={v9PointString([a, b, c, d])}
          fill={kind === "snack" ? `url(#v9-snack-${hash})` : light}
          stroke="rgba(20,15,10,.30)"
          strokeWidth="1"
        />

        {kind === "gift" && (
          <>
            <path
              d={`M ${skew * 0.15} ${topY + 1} L ${skew * 0.42} ${
                topY + depthRise - 1
              }`}
              stroke={dark}
              strokeWidth="4"
              opacity=".52"
            />
            <path
              d={`M ${-width * 0.13} ${topY + depthRise * 0.52} L ${
                width * 0.78
              } ${topY + depthRise * 0.52}`}
              stroke={dark}
              strokeWidth="4"
              opacity=".52"
            />
          </>
        )}
      </g>
    </g>
  );
};

const V9HamperSvg = ({
  selectedContainer,
  previewItems,
  selectedItemCount,
  fillPercent,
  packed = false,
}) => {
  const geometry = v9BoxGeometry(selectedContainer);
  const visibleItems = previewItems.slice(0, 18);
  const organizedItems = [...visibleItems].sort((left, right) => {
    const leftKind = v7ItemKind(left.component);
    const rightKind = v7ItemKind(right.component);
    const leftSize = v9SvgItemSize(
      left.component,
      geometry,
      leftKind,
      visibleItems.length
    );
    const rightSize = v9SvgItemSize(
      right.component,
      geometry,
      rightKind,
      visibleItems.length
    );
    const leftScore = leftSize.width * leftSize.depth + leftSize.height * 0.35;
    const rightScore =
      rightSize.width * rightSize.depth + rightSize.height * 0.35;
    return rightScore - leftScore;
  });

  const overflowCount = Math.max(0, selectedItemCount - visibleItems.length);
  const { outer, inner } = geometry;

  const outerPoints = [
    outer.backLeft,
    outer.backRight,
    outer.frontRight,
    outer.frontLeft,
  ];

  const floorPoints = [
    inner.backLeft,
    inner.backRight,
    inner.frontRight,
    inner.frontLeft,
  ];

  return (
    <svg
      viewBox={`0 0 ${geometry.viewWidth} ${geometry.viewHeight}`}
      className="h-full w-full overflow-visible"
      role="img"
      aria-label="Animated open hamper packing preview"
    >
      <defs>
        <linearGradient id="v9-floor" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#8B6231" />
          <stop offset="52%" stopColor="#5F3D1E" />
          <stop offset="100%" stopColor="#2E1A0D" />
        </linearGradient>
        <linearGradient id="v9-back-wall" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#B07A3B" stopOpacity="0.98" />
          <stop offset="100%" stopColor="#5D391A" stopOpacity="0.98" />
        </linearGradient>
        <linearGradient id="v9-side-wall" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#96632D" stopOpacity="0.96" />
          <stop offset="100%" stopColor="#432612" stopOpacity="0.96" />
        </linearGradient>
        <linearGradient id="v9-front-wall" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#AA7334" stopOpacity="0.56" />
          <stop offset="100%" stopColor="#4A2A14" stopOpacity="0.72" />
        </linearGradient>
        <linearGradient id="v11-ribbon" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#7E1717" />
          <stop offset="46%" stopColor="#D74A39" />
          <stop offset="72%" stopColor="#B52822" />
          <stop offset="100%" stopColor="#671515" />
        </linearGradient>
        <linearGradient
          id="v11-ribbon-light"
          x1="0"
          y1="0"
          x2="1"
          y2="1"
        >
          <stop offset="0%" stopColor="#F07A65" />
          <stop offset="50%" stopColor="#C83D34" />
          <stop offset="100%" stopColor="#7F1C1B" />
        </linearGradient>
        <radialGradient id="v11-knot" cx="35%" cy="25%" r="75%">
          <stop offset="0%" stopColor="#F58A70" />
          <stop offset="58%" stopColor="#C83D34" />
          <stop offset="100%" stopColor="#741A19" />
        </radialGradient>
        <pattern
          id="v9-wicker"
          width="12"
          height="12"
          patternUnits="userSpaceOnUse"
          patternTransform="rotate(18)"
        >
          <rect width="12" height="12" fill="transparent" />
          <rect
            x="0"
            y="0"
            width="5"
            height="12"
            fill="rgba(255,226,169,.12)"
          />
          <rect
            x="6"
            y="0"
            width="2"
            height="12"
            fill="rgba(38,20,8,.18)"
          />
        </pattern>
        <pattern
          id="v9-liner"
          width="20"
          height="20"
          patternUnits="userSpaceOnUse"
        >
          <circle cx="5" cy="6" r="2" fill="rgba(255,238,190,.18)" />
          <circle cx="14" cy="14" r="2" fill="rgba(244,194,94,.12)" />
        </pattern>
        <filter id="v9-shadow" x="-40%" y="-60%" width="180%" height="220%">
          <feGaussianBlur stdDeviation="10" />
        </filter>
        <filter
          id="v9-item-shadow"
          x="-50%"
          y="-80%"
          width="200%"
          height="260%"
        >
          <feDropShadow
            dx="0"
            dy="7"
            stdDeviation="5"
            floodColor="#000000"
            floodOpacity="0.36"
          />
        </filter>

        {organizedItems.map(({ id, component }, index) => {
          const [primary, dark, light] = v7Palette(component);
          const hash = v7Hash(
            String(component?._id || component?.name || index)
          );

          return (
            <g key={`defs-${id}`}>
              <linearGradient
                id={`v9-item-${hash}`}
                x1="0"
                y1="0"
                x2="1"
                y2="1"
              >
                <stop offset="0%" stopColor={light} />
                <stop offset="55%" stopColor={primary} />
                <stop offset="100%" stopColor={dark} />
              </linearGradient>
              <pattern
                id={`v9-snack-${hash}`}
                width="10"
                height="10"
                patternUnits="userSpaceOnUse"
              >
                <rect width="10" height="10" fill={light} />
                <rect width="5" height="10" fill={primary} opacity=".88" />
              </pattern>
            </g>
          );
        })}
      </defs>

      <ellipse
        cx="220"
        cy="275"
        rx={geometry.openingWidth * 0.54}
        ry="24"
        fill="rgba(0,0,0,.58)"
        filter="url(#v9-shadow)"
      />

      <g className="v9-svg-box">
        <polygon
          points={v9PointString(floorPoints)}
          fill="url(#v9-floor)"
          stroke="rgba(239,204,129,.34)"
          strokeWidth="2"
        />
        <polygon
          points={v9PointString(floorPoints)}
          fill="url(#v9-liner)"
          opacity={0.4 + Math.min(100, fillPercent) / 420}
        />

        <polygon
          points={v9PointString([
            outer.backLeft,
            outer.backRight,
            inner.backRight,
            inner.backLeft,
          ])}
          fill="url(#v9-back-wall)"
          stroke="rgba(246,213,145,.38)"
          strokeWidth="2"
        />
        <polygon
          points={v9PointString([
            outer.backLeft,
            outer.backRight,
            inner.backRight,
            inner.backLeft,
          ])}
          fill="url(#v9-wicker)"
          opacity=".82"
        />

        <polygon
          points={v9PointString([
            outer.backLeft,
            outer.frontLeft,
            inner.frontLeft,
            inner.backLeft,
          ])}
          fill="url(#v9-side-wall)"
          stroke="rgba(241,202,124,.34)"
          strokeWidth="2"
        />
        <polygon
          points={v9PointString([
            outer.backRight,
            outer.frontRight,
            inner.frontRight,
            inner.backRight,
          ])}
          fill="url(#v9-side-wall)"
          stroke="rgba(241,202,124,.34)"
          strokeWidth="2"
        />

        {fillPercent > 0 && (
          <polygon
            points={v9PointString(
              floorPoints.map(([x, y]) => [
                220 + (x - 220) * (0.9 + Math.min(100, fillPercent) / 1000),
                y - Math.min(18, fillPercent * 0.1),
              ])
            )}
            fill="rgba(224,177,91,.18)"
            stroke="rgba(240,207,139,.16)"
            strokeWidth="1"
          />
        )}

        <g filter="url(#v9-item-shadow)">
          {organizedItems.map(({ id, component }, index) => (
            <V9SvgGift
              key={id}
              component={component}
              index={index}
              count={organizedItems.length}
              geometry={geometry}
            />
          ))}
        </g>

        <polygon
          points={v9PointString([
            outer.frontLeft,
            outer.frontRight,
            inner.frontRight,
            inner.frontLeft,
          ])}
          fill="url(#v9-front-wall)"
          stroke="rgba(246,210,140,.52)"
          strokeWidth="2.5"
        />
        <polygon
          points={v9PointString([
            outer.frontLeft,
            outer.frontRight,
            inner.frontRight,
            inner.frontLeft,
          ])}
          fill="url(#v9-wicker)"
          opacity=".42"
        />

        <polygon
          points={v9PointString(outerPoints)}
          fill="none"
          stroke="#E7C56F"
          strokeWidth="6"
          strokeLinejoin="round"
        />
        <polygon
          points={v9PointString(floorPoints)}
          fill="none"
          stroke="rgba(244,213,153,.26)"
          strokeWidth="2"
          strokeLinejoin="round"
        />

        {Object.values(outer).map(([x, y], index) => (
          <g key={`corner-${index}`}>
            <circle cx={x} cy={y} r="6" fill="#F1D47E" opacity=".95" />
            <circle cx={x} cy={y} r="2.4" fill="#6A421B" />
          </g>
        ))}

        {sealed && (
          <g className="v9-lid-close">
            <polygon
              points={v9PointString(outerPoints)}
              fill="url(#v9-back-wall)"
              stroke="#E7C56F"
              strokeWidth="6"
              strokeLinejoin="round"
            />
            <polygon
              points={v9PointString(outerPoints)}
              fill="url(#v9-wicker)"
              opacity=".90"
            />

            <polygon
              points={v9PointString(
                v9RibbonBand(geometry, {
                  axis: "vertical",
                  center: 0.5,
                  width: 0.105,
                })
              )}
              fill="url(#v11-ribbon)"
              opacity=".98"
            />
            <polygon
              points={v9PointString(
                v9RibbonBand(geometry, {
                  axis: "horizontal",
                  center: 0.51,
                  width: 0.16,
                })
              )}
              fill="url(#v11-ribbon)"
              opacity=".98"
            />

            {(() => {
              const knot = v9OuterPoint(geometry, 0.5, 0.51);

              return (
                <g transform={`translate(${knot[0]} ${knot[1]})`}>
                  <path
                    d="M -4 0 C -18 -18 -42 -17 -48 -4 C -52 8 -31 14 -7 7 Z"
                    fill="url(#v11-ribbon-light)"
                    stroke="rgba(91,24,19,.58)"
                    strokeWidth="1.5"
                  />
                  <path
                    d="M 4 0 C 18 -18 42 -17 48 -4 C 52 8 31 14 7 7 Z"
                    fill="url(#v11-ribbon-light)"
                    stroke="rgba(91,24,19,.58)"
                    strokeWidth="1.5"
                  />
                  <path
                    d="M -8 7 L -25 31 L -2 20 L 0 9 Z"
                    fill="#A62F28"
                    opacity=".96"
                  />
                  <path
                    d="M 8 7 L 25 31 L 2 20 L 0 9 Z"
                    fill="#8F211E"
                    opacity=".96"
                  />
                  <ellipse
                    cx="0"
                    cy="1"
                    rx="11"
                    ry="8"
                    fill="url(#v11-knot)"
                    stroke="rgba(91,24,19,.55)"
                    strokeWidth="1.5"
                  />
                </g>
              );
            })()}

            <text
              x="220"
              y={v9OuterPoint(geometry, 0.5, 0.76)[1]}
              textAnchor="middle"
              fill="rgba(255,244,214,.78)"
              fontSize="8"
              fontWeight="800"
              letterSpacing="2.1"
            >
              HAMPORIUM
            </text>
          </g>
        )}
      </g>

      {overflowCount > 0 && (
        <g transform="translate(360 245)">
          <rect
            x="-38"
            y="-14"
            width="76"
            height="28"
            rx="14"
            fill="rgba(23,23,23,.92)"
            stroke="rgba(212,175,55,.35)"
          />
          <text
            x="0"
            y="4"
            textAnchor="middle"
            fill="#E4C666"
            fontSize="11"
            fontWeight="800"
          >
            +{overflowCount} packed
          </text>
        </g>
      )}
    </svg>
  );
};

const V20_PACKING_SLOTS = [
  { x: 30, y: 34, rotate: -7, scale: 0.86, z: 20 },
  { x: 49, y: 33, rotate: 4, scale: 0.88, z: 21 },
  { x: 68, y: 35, rotate: -5, scale: 0.86, z: 20 },
  { x: 24, y: 49, rotate: 5, scale: 0.92, z: 24 },
  { x: 41, y: 48, rotate: -6, scale: 0.94, z: 25 },
  { x: 58, y: 47, rotate: 4, scale: 0.96, z: 26 },
  { x: 75, y: 49, rotate: -5, scale: 0.90, z: 24 },
  { x: 31, y: 63, rotate: -4, scale: 0.92, z: 30 },
  { x: 49, y: 62, rotate: 2, scale: 1.0, z: 32 },
  { x: 67, y: 63, rotate: 5, scale: 0.92, z: 31 },
  { x: 24, y: 76, rotate: 4, scale: 0.84, z: 34 },
  { x: 40, y: 76, rotate: -3, scale: 0.86, z: 35 },
  { x: 57, y: 77, rotate: 4, scale: 0.84, z: 35 },
  { x: 73, y: 76, rotate: -4, scale: 0.82, z: 34 },
  { x: 17, y: 62, rotate: -6, scale: 0.76, z: 28 },
  { x: 82, y: 61, rotate: 6, scale: 0.76, z: 28 },
  { x: 36, y: 90, rotate: -2, scale: 0.74, z: 38 },
  { x: 61, y: 90, rotate: 2, scale: 0.74, z: 38 },
];

const v20BoxStyleProfile = (container) => {
  const text = [
    container?.name,
    container?.slug,
    container?.type,
    container?.category,
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();

  let shape = "magnetic";

  if (/round|hat box|hatbox|cylinder|tube|jar|oval/.test(text)) {
    shape = "round";
  } else if (/tray|basket|platter|sleeve/.test(text)) {
    shape = "tray";
  } else if (/curved|capsule|arched/.test(text)) {
    shape = "curved";
  }

  let theme = "signature";

  if (/royal|diwali|festive|premium|signature|celebration|grand/.test(text)) {
    theme = "royal";
  } else if (/magnetic|rigid|luxury|classic|edit/.test(text)) {
    theme = "magnetic";
  } else if (/chest|trunk|wood|crate|treasure/.test(text)) {
    theme = "chest";
  } else if (/ivory|wedding|floral|rose|pearl/.test(text)) {
    theme = "ivory";
  } else if (/emerald|forest|botanical|green/.test(text)) {
    theme = "emerald";
  } else if (shape === "round") {
    theme = "couture";
  }

  return { shape, theme };
};

const v20ContainerPalette = (container, profile = { shape: "magnetic", theme: "signature" }) => {
  const themes = {
    magnetic: {
      main: "#B88443",
      light: "#F1D7AA",
      dark: "#7E4B1D",
      deep: "#3E210F",
      trim: "#F8E7B8",
      satin: "#F8EDDC",
      glow: "rgba(244,189,90,.34)",
      ribbonA: "#EBCB72",
      ribbonB: "#8A5A10",
      chip: "Luxury rigid magnetic hamper",
      collection: "Private Gift Atelier",
      badge: "HAMPORIUM",
    },
    royal: {
      main: "#8D2F2F",
      light: "#E3A767",
      dark: "#561515",
      deep: "#290A0D",
      trim: "#F6D47B",
      satin: "#F4D9BC",
      glow: "rgba(244,164,73,.36)",
      ribbonA: "#FFD27A",
      ribbonB: "#A86B11",
      chip: "Festive royal hamper",
      collection: "Celebration Edition",
      badge: "HAMPORIUM",
    },
    chest: {
      main: "#6B4324",
      light: "#CFA56B",
      dark: "#3C2315",
      deep: "#1C120C",
      trim: "#E9C784",
      satin: "#EEE0CE",
      glow: "rgba(215,160,87,.30)",
      ribbonA: "#F2D58C",
      ribbonB: "#8E5D18",
      chip: "3D premium gift chest",
      collection: "Treasure Keepsake Box",
      badge: "HAMPORIUM",
    },
    ivory: {
      main: "#C7B090",
      light: "#F5EBDC",
      dark: "#887156",
      deep: "#4C3F31",
      trim: "#F6E8C6",
      satin: "#FFF8EE",
      glow: "rgba(243,214,170,.32)",
      ribbonA: "#F3E1AE",
      ribbonB: "#B28C3B",
      chip: "Ivory couture hamper",
      collection: "Soft Luxe Edition",
      badge: "HAMPORIUM",
    },
    emerald: {
      main: "#335845",
      light: "#8CAD97",
      dark: "#1D3328",
      deep: "#0D1914",
      trim: "#E7D79A",
      satin: "#E9F1EB",
      glow: "rgba(138,189,151,.28)",
      ribbonA: "#F0DEA2",
      ribbonB: "#8D6A1B",
      chip: "Emerald house hamper",
      collection: "Botanical Signature",
      badge: "HAMPORIUM",
    },
    couture: {
      main: "#B07C9A",
      light: "#F1D6E5",
      dark: "#6F4560",
      deep: "#3B2335",
      trim: "#F8E7C5",
      satin: "#FFF3F6",
      glow: "rgba(235,187,216,.28)",
      ribbonA: "#F8E6B4",
      ribbonB: "#A97A28",
      chip: "Round couture hamper",
      collection: "Maison Capsule",
      badge: "HAMPORIUM",
    },
    signature: {
      main: "#C88A4A",
      light: "#F0D2AA",
      dark: "#8B5427",
      deep: "#4D2B14",
      trim: "#F7E2B2",
      satin: "#FBF1E4",
      glow: "rgba(244,189,90,.32)",
      ribbonA: "#EBCB72",
      ribbonB: "#8A5A10",
      chip: "Signature hamper",
      collection: "Hamporium Atelier",
      badge: "HAMPORIUM",
    },
  };

  const profileTheme = profile?.theme && themes[profile.theme] ? profile.theme : null;
  if (profileTheme) return themes[profileTheme];

  const fallbackKeys = Object.keys(themes);
  const seed = String(container?._id || container?.name || "hamper");
  return themes[fallbackKeys[v7Hash(seed) % fallbackKeys.length]];
};

const v20PackingSize = (component, count, compact = false) => {
  const kind = v7ItemKind(component);
  const base = {
    bottle: [46, 84],
    cylinder: [62, 68],
    snack: [76, 62],
    flat: [78, 52],
    gift: [70, 62],
  }[kind] || [68, 62];

  const crowdScale = count > 14 ? 0.78 : count > 10 ? 0.86 : count > 7 ? 0.94 : 1.12;

  const compactScale = compact ? 0.80 : 1;

  return {
    kind,
    width: Math.round(base[0] * crowdScale * compactScale),
    height: Math.round(base[1] * crowdScale * compactScale),
  };
};

const V20PackingItem = ({ entry, index, count, compact = false }) => {
  const component = entry.component;
  const slot = V20_PACKING_SLOTS[index % V20_PACKING_SLOTS.length];
  const size = v20PackingSize(component, count, compact);
  const image = component?.images?.[0]?.url || "";
  const name = String(component?.name || "Gift");
  const stagger = Math.min(index * 28, 250);

  return (
    <div
      className={`v20-pack-item v20-kind-${size.kind} ${
        entry.phase === "enter"
          ? "is-entering"
          : entry.phase === "exit"
            ? "is-exiting"
            : ""
      }`}
      style={{
        left: `${slot.x}%`,
        top: `${slot.y}%`,
        width: `${size.width}px`,
        height: `${size.height}px`,
        zIndex: slot.z + index,
        "--v20-rotate": `${slot.rotate}deg`,
        "--v20-scale": slot.scale,
        animationDelay: entry.phase === "enter" ? `${stagger}ms` : "0ms",
      }}
      title={name}
    >
      <div className="v20-pack-card">
        {image ? (
          <img
            src={image}
            alt=""
            aria-hidden="true"
            className="v20-pack-image"
            draggable="false"
          />
        ) : (
          <div className="v20-pack-fallback" aria-hidden="true">
            {name.slice(0, 1).toUpperCase()}
          </div>
        )}

        <span className="v20-pack-label">{name}</span>
      </div>
    </div>
  );
};

const V78BotanicalArt = () => (
  <svg viewBox="0 0 1000 360" preserveAspectRatio="none" aria-hidden="true" className="h-full w-full">
    <g fill="none" stroke="currentColor" strokeWidth="2.35" strokeLinecap="round" strokeLinejoin="round">
      <path d="M32 310C110 270 148 190 234 78" />
      <path d="M79 272C64 236 68 211 82 184" />
      <path d="M82 271C113 248 130 222 137 192" />
      <ellipse cx="80" cy="194" rx="12" ry="27" transform="rotate(-30 80 194)" />
      <ellipse cx="133" cy="203" rx="12" ry="28" transform="rotate(32 133 203)" />
      <path d="M133 201C163 186 182 164 194 137" />
      <ellipse cx="191" cy="140" rx="12" ry="29" transform="rotate(-39 191 140)" />
      <g transform="translate(268 102)">
        {[0, 60, 120, 180, 240, 300].map((angle) => (
          <ellipse key={angle} cx="0" cy="-35" rx="14" ry="36" transform={`rotate(${angle})`} />
        ))}
        <circle r="10" />
        <path d="M-11-2C-3-15 12-13 15-1M-9 6C1 16 14 10 16 1" />
      </g>
      <path d="M395 322C456 267 478 204 502 108" />
      <path d="M431 266C407 251 394 230 389 208" />
      <ellipse cx="395" cy="211" rx="12" ry="29" transform="rotate(-42 395 211)" />
      <path d="M457 224C487 210 505 190 515 165" />
      <ellipse cx="510" cy="166" rx="12" ry="29" transform="rotate(43 510 166)" />
      <g transform="translate(590 186)">
        {[0, 51, 102, 153, 204, 255, 306].map((angle) => (
          <ellipse key={angle} cx="0" cy="-45" rx="17" ry="47" transform={`rotate(${angle})`} />
        ))}
        <circle r="14" />
        <path d="M-14-3C-6-19 12-20 17-5M-16 6C-3 20 15 17 18 2" />
      </g>
      <path d="M692 309C749 258 783 190 852 78" />
      <path d="M725 274C706 254 697 231 697 208" />
      <ellipse cx="700" cy="211" rx="12" ry="29" transform="rotate(-38 700 211)" />
      <path d="M762 234C792 221 808 200 818 175" />
      <ellipse cx="815" cy="176" rx="12" ry="29" transform="rotate(42 815 176)" />
      <g transform="translate(896 111)">
        {[0, 60, 120, 180, 240, 300].map((angle) => (
          <ellipse key={angle} cx="0" cy="-30" rx="12" ry="31" transform={`rotate(${angle})`} />
        ))}
        <circle r="9" />
      </g>
      <path d="M648 72C700 53 744 50 796 61" />
      <ellipse cx="698" cy="59" rx="10" ry="22" transform="rotate(73 698 59)" />
      <ellipse cx="748" cy="57" rx="10" ry="22" transform="rotate(98 748 57)" />
    </g>
  </svg>
);

const V78RibbonBow = ({ compact = false }) => (
  <div className={`relative ${compact ? "h-[46px] w-[88px]" : "h-[72px] w-[138px]"}`}>
    <span className="absolute left-[2%] top-[7%] h-[45%] w-[43%] -rotate-[10deg] rounded-[70%_28%_62%_38%] bg-[linear-gradient(135deg,#8E5E0A_0%,#D7A631_34%,#F2D577_55%,#A66F12_100%)] shadow-[inset_0_1px_0_rgba(255,248,209,.6),0_5px_10px_rgba(0,0,0,.22)]" />
    <span className="absolute right-[2%] top-[7%] h-[45%] w-[43%] rotate-[10deg] rounded-[28%_70%_38%_62%] bg-[linear-gradient(225deg,#8E5E0A_0%,#D7A631_34%,#F2D577_55%,#A66F12_100%)] shadow-[inset_0_1px_0_rgba(255,248,209,.6),0_5px_10px_rgba(0,0,0,.22)]" />
    <span className="absolute left-[31%] top-[42%] h-[55%] w-[18%] rotate-[8deg] [clip-path:polygon(0_0,100%_5%,80%_100%,50%_82%,16%_100%)] bg-[linear-gradient(90deg,#9A650D,#E3B84F_48%,#A66D0D)] shadow-[0_5px_8px_rgba(0,0,0,.18)]" />
    <span className="absolute right-[31%] top-[42%] h-[58%] w-[18%] -rotate-[8deg] [clip-path:polygon(0_0,100%_5%,84%_100%,50%_82%,20%_100%)] bg-[linear-gradient(90deg,#9A650D,#E3B84F_48%,#A66D0D)] shadow-[0_5px_8px_rgba(0,0,0,.18)]" />
    <span className="absolute left-1/2 top-[24%] z-10 h-[30%] w-[20%] -translate-x-1/2 rounded-[7px] bg-[radial-gradient(circle_at_32%_24%,#FFE9A6,#D9A632_52%,#8C5C08_100%)] shadow-[0_5px_10px_rgba(0,0,0,.28),inset_0_1px_0_rgba(255,250,218,.72)]" />
  </div>
);

const V7OpenTop3D = ({
  selectedContainer,
  previewItems,
  previewDecorations,
  selectedItemCount,
  selectedDecorationCount,
  fillPercent,
  journeyState = "idle",
  compact = false,
}) => {
  const [liveItems, setLiveItems] = useState(() => previewItems.map((item) => ({ ...item, phase: "stable" })));
  const [packingNote, setPackingNote] = useState("");
  const [boxEntryPhase, setBoxEntryPhase] = useState("idle");
  const previousIdsRef = useRef(new Set(previewItems.map((item) => item.id)));
  const timersRef = useRef([]);

  const roundedFill = Math.min(100, Math.round(Number(fillPercent || 0)));
  const isPacking = journeyState === "packing";
  const isShipping = journeyState === "shipping";
  const sealed = roundedFill >= 100 || isPacking || isShipping;
  const dropping = boxEntryPhase === "drop";
  const opening = boxEntryPhase === "opening";
  const lidClosed = sealed || dropping;

  const clearTimers = () => {
    timersRef.current.forEach((timer) => window.clearTimeout(timer));
    timersRef.current = [];
  };

  useEffect(() => {
    clearTimers();
    previousIdsRef.current = new Set(previewItems.map((item) => item.id));
    setLiveItems(previewItems.map((item) => ({ ...item, phase: "stable" })));

    if (!selectedContainer) {
      setBoxEntryPhase("idle");
      setPackingNote("");
      return undefined;
    }

    setBoxEntryPhase("drop");
    setPackingNote(`${selectedContainer.name} selected`);
    timersRef.current.push(window.setTimeout(() => {
      setBoxEntryPhase("opening");
      setPackingNote("Opening your hamper box");
    }, 950));
    timersRef.current.push(window.setTimeout(() => setPackingNote("Box ready - start adding gifts"), 1660));
    timersRef.current.push(window.setTimeout(() => setBoxEntryPhase("idle"), 2110));
    timersRef.current.push(window.setTimeout(() => setPackingNote(""), 2520));
    return clearTimers;
  }, [selectedContainer?._id]);

  useEffect(() => {
    const previous = previousIdsRef.current;
    const nextIds = new Set(previewItems.map((item) => item.id));
    const added = previewItems.filter((item) => !previous.has(item.id));
    const removed = new Set([...previous].filter((id) => !nextIds.has(id)));

    setLiveItems((current) => {
      const currentMap = new Map(current.map((item) => [item.id, item]));
      const next = previewItems.map((item) => ({ ...item, phase: currentMap.has(item.id) ? "stable" : "enter" }));
      const exiting = current.filter((item) => removed.has(item.id)).map((item) => ({ ...item, phase: "exit" }));
      return [...next, ...exiting];
    });
    previousIdsRef.current = nextIds;

    if (added.length) setPackingNote(`Adding ${added.at(-1)?.component?.name || "gift"}`);
    else if (removed.size) setPackingNote("Gift removed - space updated");

    const settle = window.setTimeout(() => {
      setLiveItems(previewItems.map((item) => ({ ...item, phase: "stable" })));
      if (added.length || removed.size) setPackingNote("");
    }, 950);
    return () => window.clearTimeout(settle);
  }, [previewItems]);

  useEffect(() => clearTimers, []);

  const visibleItems = liveItems.slice(0, compact ? 12 : 18);
  const worldSize = compact
    ? "bottom-[22px] h-[150px] w-[96%] max-w-[420px]"
    : "bottom-[34px] h-[276px] w-[96%] max-w-[720px] sm:h-[320px] xl:h-[350px]";

  return (
    <div className={`v60-live-stage relative isolate overflow-hidden rounded-[22px] border border-black/[0.055] bg-[radial-gradient(circle_at_50%_20%,#fff_0%,#fbf9f5_42%,#f1ece5_72%,#e8e0d6_100%)] shadow-[inset_0_1px_0_rgba(255,255,255,.98),0_16px_38px_rgba(39,27,14,.06)] ${compact ? "min-h-[165px]" : "min-h-[320px] sm:min-h-[380px] xl:min-h-[430px]"}`}>
      <div aria-hidden="true" className="absolute inset-x-[10%] bottom-[5%] h-[54px] rounded-full bg-black/[0.12] blur-[26px]" />

      {(packingNote || isPacking || isShipping) && (
        <div className="v60-packing-note absolute left-1/2 top-3 z-[160] max-w-[82%] -translate-x-1/2 truncate rounded-full border border-[#C7A254]/25 bg-white/95 px-3 py-1.5 text-[10px] font-black text-black/55 shadow-[0_8px_22px_rgba(0,0,0,.07)] backdrop-blur-xl sm:text-[11px]">
          {isShipping ? "Hamper packed - preparing delivery" : isPacking ? "Finishing your hamper" : packingNote}
        </div>
      )}

      {!selectedContainer ? (
        <div className="absolute left-1/2 top-1/2 z-20 w-[70%] -translate-x-1/2 -translate-y-1/2 rounded-[16px] border border-dashed border-black/15 bg-white/75 px-4 py-4 text-center text-[11px] font-extrabold leading-5 text-black/40 backdrop-blur-md">
          Choose a box to start building your hamper.
        </div>
      ) : (
        <div
          key={selectedContainer._id}
          className={`v78-box-world absolute left-1/2 z-10 ${worldSize}`}
        >
          <div
            className={`relative h-full w-full [transform-style:preserve-3d] ${dropping ? "animate-[v79CenterFreeFall_.92s_cubic-bezier(.18,.88,.24,1.02)_both]" : ""} ${isShipping ? "animate-[v79ShipAway_1.45s_cubic-bezier(.3,.75,.18,1)_forwards]" : ""}`}
            style={{ "--v79-drop-start": compact ? "-220px" : "-390px" }}
          >
          <div aria-hidden="true" className="absolute bottom-[1%] left-1/2 h-[10%] w-[82%] -translate-x-1/2 rounded-full bg-black/30 blur-[14px]" />

          {/* BODY: shallow front wall, wide visible interior */}
          <div className="v98-box-body absolute bottom-[10%] left-[5%] right-[5%] top-[47%] z-[24] overflow-visible rounded-[22px] border border-white/[0.07] bg-[linear-gradient(145deg,#1b1b1d_0%,#0d0d0f_48%,#070708_100%)] shadow-[0_20px_30px_rgba(0,0,0,.22),inset_0_1px_0_rgba(255,255,255,.06)]">
            <div className="absolute inset-x-[2.8%] top-[5%] bottom-[24%] overflow-hidden rounded-[16px] border border-[#CBA34A]/30 bg-[radial-gradient(circle_at_50%_18%,rgba(210,168,83,.13),transparent_28%),linear-gradient(180deg,#171719_0%,#09090a_100%)] shadow-[inset_0_18px_34px_rgba(0,0,0,.48),inset_0_0_0_1px_rgba(255,255,255,.025)]">
              <div className="pointer-events-none absolute inset-[8px] rounded-[11px] border border-[#D4AF37]/14" />

              {/* black paper filler */}
              <div className="pointer-events-none absolute inset-x-[4%] bottom-[3%] z-[8] h-[34%] overflow-hidden opacity-90">
                {Array.from({ length: 28 }).map((_, index) => (
                  <span
                    key={index}
                    className="absolute bottom-[8%] h-[4px] rounded-full bg-gradient-to-r from-[#0a0a0a] via-[#2b2b2d] to-[#080808] shadow-[0_1px_2px_rgba(255,255,255,.035)]"
                    style={{
                      left: `${(index * 17) % 96}%`,
                      width: `${18 + (index % 5) * 7}px`,
                      transform: `translateX(-50%) rotate(${(index * 29) % 170 - 85}deg) translateY(${(index % 4) * -7}px)`,
                    }}
                  />
                ))}
              </div>

              <div className="absolute inset-[7%_5%_10%] z-20 overflow-hidden rounded-[10px] [&_.v20-pack-item]:drop-shadow-[0_9px_12px_rgba(0,0,0,.28)] [&_.v20-pack-card]:rounded-[11px] [&_.v20-pack-card]:border-black/10 [&_.v20-pack-card]:bg-white [&_.v20-pack-card]:shadow-[0_8px_15px_rgba(0,0,0,.23)] [&_.v20-pack-image]:rounded-[9px] [&_.v20-pack-label]:hidden">
                {visibleItems.map((entry, index) => (
                  <V20PackingItem key={entry.id} entry={entry} index={index} count={visibleItems.length} compact={compact} />
                ))}
              </div>

              {selectedDecorationCount > 0 && !sealed && <V7DecorationOverlay decorations={previewDecorations} />}
            </div>

            {/* front side is intentionally shallow so it never hides the hamper */}
            <div className="absolute inset-x-0 bottom-0 z-[50] h-[29%] rounded-b-[21px] border-t border-[#D4AF37]/40 bg-[linear-gradient(180deg,#131315_0%,#09090a_54%,#050506_100%)] shadow-[0_12px_18px_rgba(0,0,0,.24),inset_0_1px_0_rgba(255,255,255,.045)]">
              <div className="absolute inset-x-[6%] top-[22%] h-px bg-gradient-to-r from-transparent via-[#D5AE4D]/70 to-transparent" />
            </div>
          </div>

          {/* LID: full-size and separate from body when open; same footprint when closed */}
          <div
            className={`absolute left-1/2 h-[42%] w-[90%] origin-bottom [backface-visibility:hidden] [transform-style:preserve-3d] transition-[top,transform] duration-700 ease-[cubic-bezier(.22,.86,.24,1)] ${lidClosed ? "z-[78]" : "z-[18]"}`}
            style={{
              top: lidClosed ? "46%" : "1%",
              transform: lidClosed
                ? "translateX(-50%) rotateX(0deg) scale(1)"
                : "translateX(-50%) perspective(1300px) rotateX(-3deg) scale(.99)",
            }}
          >
            <div className="absolute inset-x-[1.2%] -bottom-[8px] h-[12px] rounded-b-[10px] border-x border-b border-white/[0.055] bg-gradient-to-b from-[#121214] via-[#09090a] to-[#050506] shadow-[0_8px_14px_rgba(0,0,0,.24)]" />
            <div className="absolute inset-0 overflow-hidden rounded-[20px] border border-white/[0.085] bg-[radial-gradient(circle_at_24%_8%,rgba(255,255,255,.05),transparent_24%),linear-gradient(145deg,#19191b_0%,#0e0e10_44%,#070708_78%,#111113_100%)] shadow-[0_20px_34px_rgba(0,0,0,.24),inset_0_1px_0_rgba(255,255,255,.08),inset_0_-10px_20px_rgba(0,0,0,.36)]">
              <div className="pointer-events-none absolute inset-[8px] rounded-[14px] border border-[#D4AF37]/38" />
              <div className="pointer-events-none absolute inset-[15px] rounded-[10px] border border-[#D4AF37]/13" />
              <div className="absolute inset-[10px] z-[4] text-[#D2A83D] opacity-[.94]">
                <V78BotanicalArt />
              </div>
              <div className="pointer-events-none absolute -left-[20%] -top-[20%] z-[6] h-[145%] w-[14%] skew-x-[-18deg] bg-gradient-to-r from-transparent via-white/10 to-transparent animate-[v48GoldSheen_5.8s_ease-in-out_infinite]" />
            </div>
            {!lidClosed && <div className="absolute bottom-[-2px] left-1/2 h-[8px] w-[14%] -translate-x-1/2 rounded-t-[4px] bg-[linear-gradient(90deg,#85570b,#e4b548,#fff0a8,#ad7817)] shadow-[0_2px_8px_rgba(0,0,0,.22)]" />}
          </div>

          {/* gold band + bow always stay on the front face, visible open and closed */}
          <div className="absolute bottom-[16%] left-[7%] right-[7%] z-[84] h-[3px] rounded-full bg-[linear-gradient(90deg,#7F530A,#E0B34B_28%,#FFE89A_50%,#D4A334_72%,#7F530A)] shadow-[0_2px_5px_rgba(0,0,0,.2)]" />
          <div
            className="absolute bottom-[0%] left-1/2 z-[96]"
            style={{ transform: "translateX(-50%)" }}
          >
            <div className={sealed || opening ? "animate-[v80BowSettle_.46s_ease-out_both]" : ""}>
              <V78RibbonBow compact={compact} />
            </div>
          </div>

          {isShipping && (
            <div className="absolute left-1/2 top-0 z-[170] -translate-x-1/2 rounded-full border border-[#D8B052]/25 bg-[#0B0B0C] px-3 py-1.5 text-[10px] font-black uppercase tracking-[.07em] text-[#F2D17A] shadow-[0_12px_24px_rgba(0,0,0,.16)]">
              Packed - heading to you
            </div>
          )}
          </div>
        </div>
      )}

      {selectedContainer && (
        <div className="v60-capacity-line absolute inset-x-[14px] bottom-[8px] z-[180] flex items-center gap-2">
          <div className="h-1 flex-1 overflow-hidden rounded-full bg-black/[0.075]">
            <div className="h-full rounded-full bg-gradient-to-r from-[#9A6A18] via-[#D5AD57] to-[#F0D58F] transition-[width] duration-500 ease-out" style={{ width: `${roundedFill}%` }} />
          </div>
          <span className="w-[42px] shrink-0 text-right text-[12px] font-black text-black/45">{isShipping ? "Ready" : `${roundedFill}%`}</span>
        </div>
      )}
    </div>
  );
};

const V7DecorationOverlay = ({ decorations }) => {
  const positions = [
    "left-[14%] top-[47%] rotate-[-8deg]",
    "right-[14%] top-[47%] rotate-[8deg]",
    "left-[24%] bottom-[10%] rotate-[5deg]",
    "right-[24%] bottom-[10%] rotate-[-5deg]",
  ];

  return (
    <>
      <span className="v20-decor-band pointer-events-none" />
      <span className="v20-decor-band-v pointer-events-none" />

      {decorations.map(({ component }, index) => (
        <div
          key={`${component._id}-${index}`}
          className={`v7-decoration absolute z-[72] ${positions[index]}`}
          style={{ animationDelay: `${index * 70}ms` }}
        >
          <Decoration3DToken component={component} />
        </div>
      ))}
    </>
  );
};

const Decoration3DToken = ({ component }) => {
  const name = String(component?.name || "").toLowerCase();
  const image = component?.images?.[0]?.url || "";

  if (image) {
    return (
      <div className="h-11 w-11 overflow-hidden rounded-full border border-[#D4AF37]/30 bg-white p-1 shadow-[0_8px_14px_rgba(0,0,0,.26)]">
        <img
          src={image}
          alt=""
          aria-hidden="true"
          className="h-full w-full rounded-full object-contain"
          draggable="false"
        />
      </div>
    );
  }

  if (/flower|floral|rose|petal/.test(name)) {
    return (
      <div className="relative h-10 w-10 drop-shadow-[0_7px_6px_rgba(0,0,0,.35)]">
        {[0, 45, 90, 135].map((rotate) => (
          <span
            key={rotate}
            className="absolute left-1/2 top-1/2 h-3.5 w-8 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gradient-to-r from-[#F7C4CF] to-[#B75D75]"
            style={{
              transform: `translate(-50%, -50%) rotate(${rotate}deg)`,
            }}
          />
        ))}
        <span className="absolute left-1/2 top-1/2 h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#D4AF37] shadow-inner" />
      </div>
    );
  }

  if (/ribbon|bow/.test(name)) {
    return (
      <div className="relative h-9 w-11 drop-shadow-[0_7px_6px_rgba(0,0,0,.35)]">
        <span className="absolute left-0 top-2 h-6 w-7 rotate-[18deg] rounded-[70%_30%_65%_35%] bg-gradient-to-br from-[#E7CA63] to-[#9C7315]" />
        <span className="absolute right-0 top-2 h-6 w-7 rotate-[-18deg] rounded-[30%_70%_35%_65%] bg-gradient-to-bl from-[#F0D979] to-[#9C7315]" />
        <span className="absolute left-1/2 top-1/2 h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#F5DE88]" />
      </div>
    );
  }

  if (/tag|card|note/.test(name)) {
    return (
      <div className="relative h-9 w-11 rotate-[-8deg] rounded-[5px] border border-[#D4AF37]/35 bg-[#FFF7E5] shadow-[0_7px_9px_rgba(0,0,0,.28)]">
        <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full border border-[#9A7316]" />
        <span className="absolute left-2 top-3 h-1 w-6 rounded bg-[#D4AF37]/35" />
        <span className="absolute left-2 top-5 h-1 w-5 rounded bg-[#D4AF37]/20" />
      </div>
    );
  }

  return (
    <div className="flex h-10 w-10 items-center justify-center rounded-full border border-[#E5C85D]/45 bg-[#FFF9F2] text-base text-[#A77812] shadow-[0_8px_13px_rgba(0,0,0,.3)]">
      ✦
    </div>
  );
};

const ProductPager = ({
  page,
  totalPages,
  totalItems,
  rangeStart,
  rangeEnd,
  onPageChange,
  compact = false,
  label = "Products",
  scrollSelector = '[data-hamper-products-grid="true"]',
}) => {
  const pages = [];
  const start = Math.max(1, Math.min(page - 1, totalPages - 2));
  const end = Math.min(totalPages, start + 2);

  for (
    let current = Math.max(1, end - 2);
    current <= end;
    current += 1
  ) {
    pages.push(current);
  }

  const go = (nextPage) => {
    const safePage = Math.min(totalPages, Math.max(1, nextPage));
    onPageChange(safePage);

    window.requestAnimationFrame(() => {
      document
        .querySelector(scrollSelector)
        ?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  };

  if (compact) {
    return (
      <div className="mt-5 rounded-[14px] border border-black/[0.06] bg-[#FAF8F5] p-3">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-[12px] font-black uppercase tracking-[0.07em] text-black/38">
              {label}
            </p>
            <p className="mt-0.5 text-[11px] font-semibold text-black/48">
              {rangeStart}–{rangeEnd} of {totalItems} · Page {page} of {totalPages}
            </p>
          </div>

          <div className="flex shrink-0 items-center gap-2">
            <button
              type="button"
              disabled={page <= 1}
              onClick={() => go(page - 1)}
              className="flex h-10 w-10 items-center justify-center rounded-full border border-black/10 bg-white text-[16px] font-black text-[#171717] transition active:scale-95 disabled:cursor-not-allowed disabled:opacity-25"
              aria-label={`Previous ${label.toLowerCase()}`}
            >
              ←
            </button>
            <button
              type="button"
              disabled={page >= totalPages}
              onClick={() => go(page + 1)}
              className="flex h-10 min-w-[82px] items-center justify-center rounded-full bg-[#171717] px-4 text-[12px] font-black uppercase tracking-[0.06em] text-white transition active:scale-95 disabled:cursor-not-allowed disabled:bg-black/10 disabled:text-black/25"
            >
              Next →
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mt-6 flex flex-col gap-3 rounded-[12px] border border-black/[0.06] bg-[#FAF8F5] px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between">
      <p className="text-[11px] font-semibold text-black/46">
        Showing{" "}
        <span className="font-black text-[#171717]">
          {rangeStart}–{rangeEnd}
        </span>{" "}
        of <span className="font-black text-[#171717]">{totalItems}</span>{" "}
        {label.toLowerCase()}
      </p>

      <div className="flex items-center gap-2">
        <button
          type="button"
          disabled={page <= 1}
          onClick={() => go(page - 1)}
          className="h-9 rounded-xl border border-black/10 bg-white px-3 text-[12px] font-black uppercase tracking-[0.06em] text-black/55 transition hover:border-[#F47822] hover:text-[#F47822] disabled:cursor-not-allowed disabled:opacity-30"
        >
          ← Prev
        </button>

        {pages.map((pageNumber) => (
          <button
            key={pageNumber}
            type="button"
            onClick={() => go(pageNumber)}
            className={`h-9 min-w-9 rounded-xl px-3 text-[12px] font-black transition ${
              pageNumber === page
                ? "bg-[#171717] text-white shadow-sm"
                : "border border-black/10 bg-white text-black/45 hover:border-[#F47822] hover:text-[#F47822]"
            }`}
          >
            {pageNumber}
          </button>
        ))}

        <button
          type="button"
          disabled={page >= totalPages}
          onClick={() => go(page + 1)}
          className="h-9 rounded-xl border border-black/10 bg-white px-3 text-[12px] font-black uppercase tracking-[0.06em] text-black/55 transition hover:border-[#F47822] hover:text-[#F47822] disabled:cursor-not-allowed disabled:opacity-30"
        >
          Next →
        </button>
      </div>
    </div>
  );
};

const V7Empty = ({ children }) => (
  <div className="mt-3 rounded-[14px] border border-dashed border-black/10 bg-[#FAF8F5] px-5 py-6 text-center text-[12px] font-semibold leading-5 text-black/40">
    {children}
  </div>
);

// V91: The two image nodes stay mounted and swap opacity instead of being
// replaced on each slide. The next photo has already been decoded by the
// CatalogGalleryImage hover timer before it arrives as `src` here.
const StableHoverCardPhoto = ({ src, name, imageClassName }) => {
  const [layers, setLayers] = useState(() => ({
    sources: [src, ""],
    active: 0,
    pending: null,
  }));

  useEffect(() => {
    setLayers((before) => {
      if (before.sources[before.active] === src && before.pending === null) {
        return before;
      }
      const target = 1 - before.active;
      if (before.pending === target && before.sources[target] === src) {
        return before;
      }
      const sources = [...before.sources];
      sources[target] = src;
      return { ...before, sources, pending: target };
    });
  }, [src]);

  useEffect(() => {
    if (layers.pending === null) return undefined;
    // First paint the predecoded next photo underneath at opacity 0,
    // then crossfade it over the outgoing image in the following frame.
    let secondFrame = 0;
    const firstFrame = window.requestAnimationFrame(() => {
      secondFrame = window.requestAnimationFrame(() => {
        setLayers((before) => before.pending === null
          ? before
          : { ...before, active: before.pending, pending: null });
      });
    });
    return () => {
      window.cancelAnimationFrame(firstFrame);
      window.cancelAnimationFrame(secondFrame);
    };
  }, [layers.pending, layers.sources[0], layers.sources[1]]);

  return (
    <div className="relative h-full w-full" role="img" aria-label={`${name} product photo`}>
      {layers.sources.map((photo, slot) => photo ? (
        <img
          key={slot}
          src={photo}
          alt=""
          aria-hidden="true"
          loading="eager"
          decoding="async"
          draggable={false}
          className={`v91-card-photo-layer pointer-events-none absolute inset-0 ${imageClassName}`}
          style={{ opacity: layers.active === slot ? 1 : 0 }}
        />
      ) : null)}
    </div>
  );
};

// All imported views share this lightweight image switcher. No change to packing/fit logic.
// V89: Only hovered cards cycle. Details remain manual with a full-size viewer.
// The previous image remains underneath until the next image has faded in.
const CatalogGalleryImage = ({
  images = [],
  name = "Product",
  imageClassName = "h-full w-full object-contain",
  fallback = null,
  autoPlay = false,
  allowZoom = false,
  showControls = true,
}) => {
  const pictures = useMemo(() => {
    const entries = Array.isArray(images) ? images : [];
    return [...new Set(entries
      .map((image) => typeof image === "string"
        ? image
        : image?.url || image?.secure_url || image?.src || image?.location)
      .filter((url) => typeof url === "string" && /^https?:\/\//i.test(url)))];
  }, [images]);

  const galleryRef = useRef(null);
  const decodedImagesRef = useRef(new Map());
  const [slide, setSlide] = useState({ index: 0, previous: null });
  const [visible, setVisible] = useState(false);
  const [zoomed, setZoomed] = useState(false);
  const count = pictures.length;
  const currentIndex = count ? slide.index % count : 0;
  const previousIndex = count && slide.previous !== null ? slide.previous % count : null;
  const current = pictures[currentIndex] || "";
  // Stable even when the API supplies a new array with the same photo URLs.
  const gallerySignature = pictures.join("\u001f");

  useEffect(() => {
    decodedImagesRef.current.clear();
    setSlide({ index: 0, previous: null });
    setZoomed(false);
  }, [gallerySignature]);

  useEffect(() => {
    if (!autoPlay || count < 2) return undefined;
    const target = galleryRef.current;
    if (!target) return undefined;
    if (typeof IntersectionObserver === "undefined") {
      setVisible(true);
      return undefined;
    }
    const observer = new IntersectionObserver(
      ([entry]) => setVisible(entry.isIntersecting),
      { rootMargin: "100px 0px" }
    );
    observer.observe(target);
    return () => observer.disconnect();
  }, [autoPlay, count]);

  const changeSlide = (direction) => {
    if (count < 2) return;
    setSlide((before) => ({
      index: (before.index + direction + count) % count,
      previous: before.index % count,
    }));
  };

  useEffect(() => {
    if (!autoPlay || count < 2 || !visible || zoomed) return undefined;
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches) return undefined;
    // V90: Quick hover slideshow with decoded-image handoff, preventing
    // blank flashes if the next Cloudinary photo is not ready yet.
    let cancelled = false;
    let timer = 0;
    let position = currentIndex;

    const ensureDecoded = (url) => {
      const cached = decodedImagesRef.current.get(url);
      if (cached) return cached;

      const ready = new Promise((resolve) => {
        const image = new Image();
        image.decoding = "async";
        image.onload = async () => {
          try { await image.decode?.(); } catch { /* onload already succeeded */ }
          resolve(true);
        };
        image.onerror = () => resolve(false);
        image.src = url;
      });
      decodedImagesRef.current.set(url, ready);
      return ready;
    };

    const advance = async () => {
      if (cancelled) return;
      if (document.visibilityState !== "visible") {
        timer = window.setTimeout(advance, 350);
        return;
      }
      const next = (position + 1) % count;
      const ready = await ensureDecoded(pictures[next]);
      if (cancelled) return;

      // Skip an unavailable URL rather than displaying a blank image.
      position = next;
      if (ready) {
        setSlide((before) => ({
          index: next,
          previous: before.index % count,
        }));
      }
      // Keep one image warmed up ahead of the current photo.
      void ensureDecoded(pictures[(position + 1) % count]);
      timer = window.setTimeout(advance, 1600);
    };

    void ensureDecoded(pictures[(position + 1) % count]);
    timer = window.setTimeout(advance, 450);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [autoPlay, count, visible, zoomed, gallerySignature]);

  // When hover ends, display the default product image again. Other cards never rotate.
  useEffect(() => {
    if (autoPlay) return;
    setSlide((before) =>
      before.index === 0 && before.previous === null
        ? before
        : { index: 0, previous: before.index === 0 ? null : before.index }
    );
  }, [autoPlay]);

  // Capture zoom keyboard input before the outer modal's Escape handler runs.
  useEffect(() => {
    if (!zoomed) return undefined;
    const onKey = (event) => {
      if (!["Escape", "ArrowLeft", "ArrowRight"].includes(event.key)) return;
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation?.();
      if (event.key === "Escape") setZoomed(false);
      if (event.key === "ArrowLeft") changeSlide(-1);
      if (event.key === "ArrowRight") changeSlide(1);
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [zoomed, count]);

  const go = (event, direction) => {
    event.preventDefault();
    event.stopPropagation();
    changeSlide(direction);
  };

  const galleryPhoto = current ? (
    !showControls && !allowZoom ? (
      <StableHoverCardPhoto src={current} name={name} imageClassName={imageClassName} />
    ) : (
      <>
        {previousIndex !== null && pictures[previousIndex] !== current && (
          <img
            key={`prev-${pictures[previousIndex]}`}
            src={pictures[previousIndex]}
            alt=""
            aria-hidden="true"
            className={`pointer-events-none absolute inset-0 ${imageClassName}`}
            loading="lazy"
            decoding="async"
          />
        )}
        <img
          key={current}
          src={current}
          alt={`${name} - image ${currentIndex + 1}`}
          loading="lazy"
          decoding="async"
          className={`pointer-events-none absolute inset-0 ${imageClassName} ${previousIndex !== null ? "v82-gallery-fade" : ""}`}
        />
      </>
    )
  ) : fallback || <NoImage />;

  return (
    <div
      ref={galleryRef}
      className="relative h-full w-full overflow-hidden"
    >
      {allowZoom && current ? (
        <button
          type="button"
          onClick={(event) => { event.preventDefault(); event.stopPropagation(); setZoomed(true); }}
          className="absolute inset-0 h-full w-full cursor-zoom-in overflow-hidden"
          title={`View a larger photo of ${name}`}
          aria-label={`Enlarge ${name} image`}
        >
          {galleryPhoto}
          <span className="absolute right-2 top-2 z-10 rounded-full bg-[#171717]/75 px-2.5 py-1 text-[10px] font-bold text-white">⤢ Enlarge</span>
        </button>
      ) : galleryPhoto}

      {showControls && count > 1 && (
        <>
          <div className="pointer-events-none absolute inset-x-1 top-1/2 z-10 flex -translate-y-1/2 justify-between">
            <button type="button" onClick={(event) => go(event, -1)} aria-label={`Previous ${name} image`}
              className="pointer-events-auto flex h-7 w-7 items-center justify-center rounded-full bg-[#171717]/80 text-[19px] text-white shadow-md transition hover:bg-[#F47822]">‹</button>
            <button type="button" onClick={(event) => go(event, 1)} aria-label={`Next ${name} image`}
              className="pointer-events-auto flex h-7 w-7 items-center justify-center rounded-full bg-[#171717]/80 text-[19px] text-white shadow-md transition hover:bg-[#F47822]">›</button>
          </div>
          <span className="pointer-events-none absolute bottom-1 right-1 z-10 rounded-full bg-black/70 px-2 py-0.5 text-[10px] font-bold text-white">{currentIndex + 1} / {count}</span>
        </>
      )}
      {zoomed && current && typeof document !== "undefined" && createPortal(
        <div
          className="fixed inset-0 flex items-center justify-center bg-black/95 p-3 sm:p-8"
          style={{ zIndex: 100010 }}
          role="dialog"
          aria-modal="true"
          aria-label={`${name} large image viewer`}
          onMouseDown={(event) => { if (event.currentTarget === event.target) setZoomed(false); }}
        >
          <img
            key={`zoom-${current}`}
            src={current}
            alt={`${name} - image ${currentIndex + 1} of ${count}`}
            className="max-h-[88dvh] max-w-[94vw] select-none object-contain"
            draggable={false}
          />
          <button
            type="button"
            className="absolute right-4 top-4 flex h-11 w-11 items-center justify-center rounded-full bg-white/15 text-2xl text-white hover:bg-white/25"
            aria-label="Close enlarged image"
            onClick={() => setZoomed(false)}
          >×</button>
          {count > 1 && (
            <>
              <button type="button" onClick={(event) => go(event, -1)}
                className="absolute left-2 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full bg-white/15 text-3xl text-white hover:bg-white/25 sm:left-6"
                aria-label="Previous photo">‹</button>
              <button type="button" onClick={(event) => go(event, 1)}
                className="absolute right-2 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full bg-white/15 text-3xl text-white hover:bg-white/25 sm:right-6"
                aria-label="Next photo">›</button>
            </>
          )}
          <span className="absolute bottom-4 left-1/2 -translate-x-1/2 rounded-full bg-white/15 px-4 py-2 text-[12px] font-semibold text-white">
            {currentIndex + 1} / {count}
          </span>
        </div>, document.body
      )}
    </div>
  );
};

const NoImage = () => (
  <div className="flex h-full items-center justify-center bg-gradient-to-br from-[#F1ECE5] to-[#E8DFD4] text-[12px] font-bold uppercase tracking-[0.1em] text-black/25">
    No image
  </div>
);

const CustomHamperSkeleton = () => (
  <main className="min-h-screen bg-[#F6F1E9] px-3 pb-16 pt-[92px] sm:px-5 lg:px-7">
    <div className="mx-auto w-full max-w-[1760px]">
      <div className="h-[250px] animate-pulse rounded-[30px] bg-[#171614]/90" />
      <div className="mt-4 h-[64px] animate-pulse rounded-[18px] bg-white" />
      <div className="mt-5 grid gap-5 xl:grid-cols-[minmax(0,1fr)_460px]">
        <div className="h-[620px] animate-pulse rounded-[28px] bg-white" />
        <div className="h-[610px] animate-pulse rounded-[28px] bg-white" />
      </div>
    </div>
  </main>
);

export default CustomHamper;
