const formatCurrency = (amount) => {
  if (amount === null || amount === undefined) return "";

  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);
};

export default formatCurrency;