import mongoose from "mongoose";
import { closeSync, fstatSync, openSync, readFileSync, readSync } from "node:fs";
import { inflateRawSync } from "node:zlib";
import * as XLSXModule from "xlsx";

import Product from "./product.model.js";
import SKU from "./sku.model.js";
import Category from "./category.model.js";
import Collection from "./collection.model.js";
import Component from "./component.model.js";
import Container from "./container.model.js";
import Order from "../orders/order.model.js";

import asyncHandler from "../../utils/asyncHandler.js";
import { getPagination, getPaginationMeta } from "../../utils/pagination.js";
import {
  ORDER_PAYMENT_STATUS,
  ORDER_STATUS,
  PRODUCT_STATUS,
} from "../../constants/statuses.js";
import uploadFile, { deleteFile } from "../../helpers/uploadFile.js";
import ProductMasterArchive from "./productMasterArchive.model.js";
import {
  componentArchiveReasons,
  containerArchiveReasons,
  hamperArchiveReasons,
  hasWebsiteImage,
  buildComponentPublicFilter,
  buildContainerPublicFilter,
  websiteImageMongoFilter,
  inspectContainerWebsiteVisibility,
} from "./catalogReadiness.service.js";
import { ProductMasterImageSyncJob } from "./productMasterImageSync.model.js";
import { syncProductMasterImageEntry, parseDriveAssetLink } from "./productMasterImages.service.js";
import {
  calculateCatalogPricing,
  normalizeDiscountConfig,
  validateDiscountConfig,
} from "../tax/tax.service.js";

// `xlsx` is CommonJS in many Node deployments. Depending on the Node/ESM
// interop path, functions can live on the namespace object or on `default`.
// Normalize it once so `read`, `utils`, etc. are reliable on Render as well.
const XLSX = XLSXModule.default?.utils ? XLSXModule.default : XLSXModule;

/* =========================================================
   COMMON HELPERS
========================================================= */

const isValidId = (id) => mongoose.isValidObjectId(id);

const disableCatalogCaching = (res) => {
  res.setHeader(
    "Cache-Control",
    "no-store, no-cache, must-revalidate, proxy-revalidate"
  );
  res.setHeader("Pragma", "no-cache");
  res.setHeader("Expires", "0");
};

const createSlug = (value = "") =>
  String(value)
    .trim()
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");

const escapeRegex = (value = "") =>
  String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const parseBoolean = (value) => {
  if (value === true || value === "true") return true;
  if (value === false || value === "false") return false;
  return undefined;
};

const normalizeTags = (tags) => {
  if (!Array.isArray(tags)) return [];

  return [
    ...new Set(
      tags
        .map((tag) => String(tag).trim().toLowerCase())
        .filter(Boolean)
    ),
  ];
};

const toPlainObject = (value) => {
  if (!value) return {};
  if (typeof value.toObject === "function") return value.toObject();
  return { ...value };
};

const getReferenceId = (value) => value?._id || value || null;

const toUtcDay = (value = new Date()) => {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return null;

  return new Date(
    Date.UTC(
      date.getUTCFullYear(),
      date.getUTCMonth(),
      date.getUTCDate()
    )
  );
};

const addCalendarDays = (date, days = 0) => {
  const result = toUtcDay(date);
  if (!result) return null;
  result.setUTCDate(result.getUTCDate() + Number(days || 0));
  return result;
};

const parseCourierDays = (value, fallback = null) => {
  const source = value === undefined || value === null || value === "" ? fallback : value;

  if (source === undefined || source === null || source === "") {
    return { valid: true, value: null };
  }

  const days = Number(source);

  if (!Number.isInteger(days) || days < 0 || days > 60) {
    return {
      valid: false,
      message: "Courier days must be a whole number between 0 and 60",
    };
  }

  return { valid: true, value: days };
};

/* =========================================================
   SLUG / TAXONOMY HELPERS
========================================================= */

const ensureUniqueSlug = async (Model, source, excludeId = null) => {
  const baseSlug = createSlug(source);

  if (!baseSlug) {
    throw new Error("Unable to create a valid slug");
  }

  let slug = baseSlug;
  let counter = 2;

  while (true) {
    const filter = { slug };
    if (excludeId) filter._id = { $ne: excludeId };

    const exists = await Model.exists(filter);
    if (!exists) return slug;

    slug = `${baseSlug}-${counter}`;
    counter += 1;
  }
};

const validateCategory = async (categoryId) => {
  if (!isValidId(categoryId)) return null;
  return Category.findById(categoryId);
};

const validateCollections = async (collectionIds = []) => {
  if (!Array.isArray(collectionIds)) return null;
  if (collectionIds.length === 0) return [];

  const uniqueIds = [...new Set(collectionIds.map(String))];
  if (!uniqueIds.every((id) => isValidId(id))) return null;

  const collections = await Collection.find({
    _id: { $in: uniqueIds },
  }).select("_id");

  return collections.length === uniqueIds.length ? uniqueIds : null;
};

const resolveCategoryFilter = async (value) => {
  if (!value) return null;

  if (isValidId(value)) {
    const category = await Category.findById(value).select("_id").lean();
    return category?._id || null;
  }

  const category = await Category.findOne({
    slug: String(value).trim().toLowerCase(),
  })
    .select("_id")
    .lean();

  return category?._id || null;
};

const resolveCollectionFilter = async (value) => {
  if (!value) return null;

  if (isValidId(value)) {
    const collection = await Collection.findById(value).select("_id").lean();
    return collection?._id || null;
  }

  const collection = await Collection.findOne({
    slug: String(value).trim().toLowerCase(),
  })
    .select("_id")
    .lean();

  return collection?._id || null;
};

const syncProductPriceRange = async (productId) => {
  const activeSkus = await SKU.find({ product: productId, isActive: true })
    .select("price")
    .lean();

  if (activeSkus.length === 0) {
    await Product.findByIdAndUpdate(productId, {
      minPrice: null,
      maxPrice: null,
      skuCount: 0,
    });
    return;
  }

  const prices = activeSkus.map((sku) => sku.price);

  await Product.findByIdAndUpdate(productId, {
    minPrice: Math.min(...prices),
    maxPrice: Math.max(...prices),
    skuCount: activeSkus.length,
  });
};


const buildCatalogCardPricing = (skus = []) => {
  const pricedSkus = (Array.isArray(skus) ? skus : [])
    .filter((sku) => Number.isFinite(Number(sku?.price)))
    .sort((a, b) => {
      const priceDiff = Number(a.price) - Number(b.price);
      if (priceDiff !== 0) return priceDiff;

      return Number(a.sortOrder || 0) - Number(b.sortOrder || 0);
    });

  const sku = pricedSkus[0] || null;

  if (!sku) {
    return {
      skuId: null,
      skuCode: "",
      sellingPrice: null,
      mrp: null,
      compareAtPrice: null,
      discountAmount: 0,
      discountPercent: 0,
      hasDiscount: false,
    };
  }

  const sellingPrice = Number(sku.price);
  const mrp =
    sku.mrp !== null &&
    sku.mrp !== undefined &&
    Number.isFinite(Number(sku.mrp))
      ? Number(sku.mrp)
      : null;

  const explicitCompareAt =
    sku.compareAtPrice !== null &&
    sku.compareAtPrice !== undefined &&
    Number.isFinite(Number(sku.compareAtPrice))
      ? Number(sku.compareAtPrice)
      : null;

  const compareAtPrice =
    explicitCompareAt !== null &&
    explicitCompareAt > sellingPrice
      ? explicitCompareAt
      : mrp !== null && mrp > sellingPrice
        ? mrp
        : null;

  const discountAmount =
    compareAtPrice !== null
      ? money(compareAtPrice - sellingPrice)
      : 0;

  const discountPercent =
    compareAtPrice !== null && compareAtPrice > 0
      ? Math.round(
          ((compareAtPrice - sellingPrice) /
            compareAtPrice) *
            100
        )
      : 0;

  return {
    skuId: sku._id || null,
    skuCode: sku.code || "",
    sellingPrice,
    mrp,
    compareAtPrice,
    discountAmount,
    discountPercent,
    hasDiscount:
      compareAtPrice !== null &&
      discountPercent > 0,
  };
};

/* =========================================================
   SHARED CATALOG CONSTANTS
========================================================= */

const DIMENSION_UNITS = ["mm", "cm"];
const WEIGHT_UNITS = ["g", "kg"];
const STOCK_UNITS = ["pc", "g", "kg", "ml", "l", "mm", "cm", "m"];
const COMPONENT_TYPES = ["food", "non_food", "packaging"];
const PUBLIC_COMPONENT_TYPES = ["food", "non_food"];
const HAMPER_ROLES = ["content", "decoration"];
const AVAILABILITY_VALUES = ["in_stock", "incoming", "out_of_stock"];
const CHANNEL_KEYS = ["corporate", "wedding", "diwali", "hamperOne"];
const SOURCE_TYPES = ["manual", "product_master", "google_sheet"];

/* =========================================================
   UNIT HELPERS
========================================================= */

const dimensionToCm = (value, unit = "cm") => {
  const number = Number(value);
  if (!Number.isFinite(number)) return null;
  return unit === "mm" ? number / 10 : number;
};

const weightToGrams = (value, unit = "g") => {
  const number = Number(value);
  if (!Number.isFinite(number)) return null;
  return unit === "kg" ? number * 1000 : number;
};

const convertQuantity = (value, fromUnit = "pc", toUnit = "pc") => {
  const number = Number(value);
  if (!Number.isFinite(number)) return null;

  const from = String(fromUnit || "pc").toLowerCase();
  const to = String(toUnit || "pc").toLowerCase();

  if (from === to) return number;
  if (from === "g" && to === "kg") return number / 1000;
  if (from === "kg" && to === "g") return number * 1000;
  if (from === "ml" && to === "l") return number / 1000;
  if (from === "l" && to === "ml") return number * 1000;
  if (from === "mm" && to === "cm") return number / 10;
  if (from === "cm" && to === "mm") return number * 10;
  if (from === "cm" && to === "m") return number / 100;
  if (from === "m" && to === "cm") return number * 100;
  if (from === "mm" && to === "m") return number / 1000;
  if (from === "m" && to === "mm") return number * 1000;

  return null;
};

const optionalNumber = (value) => {
  if (value === undefined || value === null || value === "") return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : NaN;
};

const validateOptionalNumber = (
  value,
  label,
  { min = 0, max = null, integer = false } = {}
) => {
  if (value === undefined || value === null || value === "") return null;

  const number = Number(value);
  if (!Number.isFinite(number)) return `${label} must be a valid number`;
  if (integer && !Number.isInteger(number)) return `${label} must be a whole number`;
  if (number < min) return `${label} must be at least ${min}`;
  if (max !== null && number > max) return `${label} cannot exceed ${max}`;
  return null;
};

const validateBooleanValue = (value, label) => {
  if (value === undefined) return null;
  return parseBoolean(value) === undefined ? `${label} must be true or false` : null;
};

const validateChannels = (channels) => {
  if (!channels) return null;

  for (const key of CHANNEL_KEYS) {
    const error = validateBooleanValue(channels[key], `channels.${key}`);
    if (error) return error;
  }

  return null;
};

const normalizeChannels = (channels = {}, current = {}) => {
  const result = {};

  for (const key of CHANNEL_KEYS) {
    const parsed = parseBoolean(channels[key]);
    result[key] = parsed === undefined ? Boolean(current?.[key]) : parsed;
  }

  return result;
};

const validateSource = (source) => {
  if (!source) return null;

  if (source.type && !SOURCE_TYPES.includes(source.type)) {
    return "Invalid source type";
  }

  for (const field of ["sourceUpdatedAt", "lastSyncedAt"]) {
    if (source[field] && Number.isNaN(new Date(source[field]).getTime())) {
      return `Invalid source.${field}`;
    }
  }

  return null;
};

const normalizeSource = (source = {}, current = {}) => ({
  type: SOURCE_TYPES.includes(source.type)
    ? source.type
    : current?.type || "manual",
  externalSku:
    source.externalSku !== undefined
      ? String(source.externalSku || "").trim()
      : current?.externalSku || "",
  sourceUpdatedAt:
    source.sourceUpdatedAt !== undefined
      ? source.sourceUpdatedAt
        ? new Date(source.sourceUpdatedAt)
        : null
      : current?.sourceUpdatedAt || null,
  lastSyncedAt:
    source.lastSyncedAt !== undefined
      ? source.lastSyncedAt
        ? new Date(source.lastSyncedAt)
        : null
      : current?.lastSyncedAt || null,
});

const hasPrice = (value) => {
  if (value === undefined || value === null || value === "") return false;
  const number = Number(value);
  return Number.isFinite(number) && number >= 0;
};

const money = (value) => Number(Number(value || 0).toFixed(2));

const applyPricingControlFields = (document, body, fallbackSource = "manual") => {
  if (body.taxEnabled !== undefined) {
    document.taxEnabled = parseBoolean(body.taxEnabled);
  }

  if (body.discount !== undefined) {
    document.discount = normalizeDiscountConfig(
      body.discount,
      toPlainObject(document.discount)
    );
  }

  if (body.pricingSource !== undefined) {
    document.pricingSource = SOURCE_TYPES.includes(body.pricingSource)
      ? body.pricingSource
      : fallbackSource;
  }

  if (body.taxSource !== undefined) {
    document.taxSource = SOURCE_TYPES.includes(body.taxSource)
      ? body.taxSource
      : fallbackSource;
  }
};

/* =========================================================
   COMPONENT HELPERS
========================================================= */

const normalizeDimensions = (dimensions = {}) => {
  const length = Number(dimensions.length);
  const width = Number(dimensions.width);
  const height = Number(dimensions.height);

  return {
    length: Number.isFinite(length) ? length : null,
    width: Number.isFinite(width) ? width : null,
    height: Number.isFinite(height) ? height : null,
    unit: DIMENSION_UNITS.includes(dimensions.unit) ? dimensions.unit : "cm",
  };
};

const normalizeWeight = (weight = {}) => {
  const value = Number(weight.value);

  return {
    value: Number.isFinite(value) ? value : null,
    unit: WEIGHT_UNITS.includes(weight.unit) ? weight.unit : "g",
  };
};

const normalizeAvailability = (availability = {}, { stockUnit = true } = {}) => {
  const rawQuantity = availability.availableQuantity;
  const quantity = rawQuantity === undefined || rawQuantity === null || rawQuantity === ""
    ? null
    : Number(rawQuantity);

  const normalized = {
    status: AVAILABILITY_VALUES.includes(availability.status)
      ? availability.status
      : "in_stock",
    availableQuantity:
      quantity === null
        ? null
        : Number.isFinite(quantity) && quantity >= 0
          ? quantity
          : null,
    nextAvailableDate: availability.nextAvailableDate
      ? new Date(availability.nextAvailableDate)
      : null,
  };

  if (stockUnit) {
    normalized.unit = STOCK_UNITS.includes(availability.unit)
      ? availability.unit
      : "pc";
  }

  return normalized;
};

const validateAvailabilityPayload = (availability, { stockUnit = true, label = "availability" } = {}) => {
  if (!availability) return null;

  if (
    availability.status &&
    !AVAILABILITY_VALUES.includes(availability.status)
  ) {
    return `Invalid ${label} status`;
  }

  if (
    stockUnit &&
    availability.unit &&
    !STOCK_UNITS.includes(availability.unit)
  ) {
    return `Invalid ${label} unit`;
  }

  if (
    availability.availableQuantity !== undefined &&
    availability.availableQuantity !== null &&
    availability.availableQuantity !== ""
  ) {
    const quantity = Number(availability.availableQuantity);

    if (!Number.isFinite(quantity) || quantity < 0) {
      return `${label} quantity must be a valid non-negative number`;
    }
  }

  if (
    availability.status === "incoming" &&
    !availability.nextAvailableDate
  ) {
    return `Next available date is required when ${label} status is incoming`;
  }

  if (
    availability.nextAvailableDate &&
    Number.isNaN(new Date(availability.nextAvailableDate).getTime())
  ) {
    return `Invalid ${label} next available date`;
  }

  return null;
};

const validateComponentPayload = ({
  type,
  hamperRole = "content",
  expiryDate,
  expiryTracked,
  shelfLifeDays,
  dimensions,
  weight,
  customerSelectable,
  availability,
  channels,
  piecesPerUom,
  productPriority,
  mrp,
  sellingPrice,
  latestUnitCost,
  actualLandedCost,
  taxPercent,
  taxEnabled,
  discount,
  minGrossMarginPercent,
  moqQty,
  leadTimeDays,
  fragile,
  personalizable,
  hamperUse,
  source,
}) => {
  if (!COMPONENT_TYPES.includes(type)) return "Invalid component type";
  if (!HAMPER_ROLES.includes(hamperRole)) return "Invalid hamper role";
  if (hamperRole === "decoration" && type !== "non_food") {
    return "Decorative materials must use the non_food component type";
  }

  if (expiryDate && Number.isNaN(new Date(expiryDate).getTime())) {
    return "Invalid expiry date";
  }

  if (dimensions?.unit && !DIMENSION_UNITS.includes(dimensions.unit)) {
    return "Dimension unit must be mm or cm";
  }

  if (weight?.unit && !WEIGHT_UNITS.includes(weight.unit)) {
    return "Weight unit must be g or kg";
  }

  if (customerSelectable === true && hamperRole !== "decoration") {
    const length = Number(dimensions?.length);
    const width = Number(dimensions?.width);
    const height = Number(dimensions?.height);
    const weightValue = Number(weight?.value);

    if (
      !Number.isFinite(length) ||
      !Number.isFinite(width) ||
      !Number.isFinite(height) ||
      length <= 0 ||
      width <= 0 ||
      height <= 0
    ) {
      return "Length, width and height are required for customer-selectable components";
    }

    if (!Number.isFinite(weightValue) || weightValue <= 0) {
      return "Weight is required for customer-selectable components";
    }
  }

  if (dimensions) {
    for (const key of ["length", "width", "height"]) {
      const raw = dimensions[key];
      if (raw === undefined || raw === null || raw === "") continue;

      const value = Number(raw);
      if (!Number.isFinite(value) || value < 0) {
        return `${key} must be a valid non-negative number`;
      }
    }
  }

  if (weight?.value !== undefined && weight?.value !== null && weight?.value !== "") {
    const value = Number(weight.value);
    if (!Number.isFinite(value) || value < 0) {
      return "Weight must be a valid non-negative number";
    }
  }

  const booleanChecks = [
    [expiryTracked, "expiryTracked"],
    [fragile, "fragile"],
    [personalizable, "personalizable"],
    [hamperUse, "hamperUse"],
    [taxEnabled, "taxEnabled"],
  ];

  for (const [value, label] of booleanChecks) {
    const error = validateBooleanValue(value, label);
    if (error) return error;
  }

  const numberChecks = [
    [piecesPerUom, "Pieces per UOM", { min: 0 }],
    [productPriority, "Product priority", { min: 0 }],
    [mrp, "MRP", { min: 0 }],
    [sellingPrice, "Selling price", { min: 0 }],
    [latestUnitCost, "Latest unit cost", { min: 0 }],
    [actualLandedCost, "Actual landed cost", { min: 0 }],
    [taxPercent, "Tax percent", { min: 0, max: 100 }],
    [minGrossMarginPercent, "Minimum gross margin percent", { min: 0, max: 100 }],
    [moqQty, "MOQ quantity", { min: 0 }],
    [leadTimeDays, "Lead time days", { min: 0 }],
    [shelfLifeDays, "Shelf life days", { min: 0 }],
  ];

  for (const [value, label, options] of numberChecks) {
    const error = validateOptionalNumber(value, label, options);
    if (error) return error;
  }

  const discountError = validateDiscountConfig(discount);
  if (discountError) return discountError;

  const channelError = validateChannels(channels);
  if (channelError) return channelError;

  const sourceError = validateSource(source);
  if (sourceError) return sourceError;

  return validateAvailabilityPayload(availability, {
    stockUnit: true,
    label: "component availability",
  });
};

const applyTextFields = (document, body, fields) => {
  for (const field of fields) {
    if (body[field] !== undefined) {
      document[field] = String(body[field] || "").trim();
    }
  }
};

const applyNumberFields = (document, body, fields) => {
  for (const field of fields) {
    if (body[field] !== undefined) {
      document[field] = optionalNumber(body[field]);
    }
  }
};

const applyComponentMasterFields = (component, body) => {
  applyTextFields(component, body, [
    "skuBarcode",
    "sizePack",
    "uom",
    "sourceProductType",
    "taxonomyBaseId",
    "categoryCode",
    "category",
    "subcategory",
    "segment",
    "dietary",
    "personalizationMethod",
    "hsnSac",
    "decorationType",
  ]);

  applyNumberFields(component, body, [
    "piecesPerUom",
    "productPriority",
    "mrp",
    "sellingPrice",
    "latestUnitCost",
    "actualLandedCost",
    "taxPercent",
    "minGrossMarginPercent",
    "moqQty",
    "leadTimeDays",
    "shelfLifeDays",
  ]);

  for (const field of [
    "fragile",
    "expiryTracked",
    "personalizable",
    "hamperUse",
    "countsTowardBoxCapacity",
  ]) {
    if (body[field] !== undefined) component[field] = parseBoolean(body[field]);
  }

  if (component.hamperRole === "decoration") {
    component.countsTowardBoxCapacity = false;
  }

  if (body.channels !== undefined) {
    component.channels = normalizeChannels(body.channels, toPlainObject(component.channels));
  }

  if (body.source !== undefined) {
    component.source = normalizeSource(body.source, toPlainObject(component.source));
  }

  applyPricingControlFields(
    component,
    body,
    component.source?.type || "manual"
  );
};

const applyContainerMasterFields = (container, body) => {
  applyTextFields(container, body, [
    "skuBarcode",
    "sourceProductType",
    "taxonomyBaseId",
    "categoryCode",
    "category",
    "subcategory",
    "segment",
    "hsnSac",
  ]);

  applyNumberFields(container, body, [
    "productPriority",
    "mrp",
    "sellingPrice",
    "latestUnitCost",
    "actualLandedCost",
    "taxPercent",
    "leadTimeDays",
  ]);

  if (body.hamperUse !== undefined) container.hamperUse = parseBoolean(body.hamperUse);

  if (body.channels !== undefined) {
    container.channels = normalizeChannels(body.channels, toPlainObject(container.channels));
  }

  if (body.source !== undefined) {
    container.source = normalizeSource(body.source, toPlainObject(container.source));
  }

  applyPricingControlFields(
    container,
    body,
    container.source?.type || "manual"
  );
};

const validateAndNormalizeMaterialItems = async (
  items = [],
  { fieldName = "internalMaterials", activeOnly = true } = {}
) => {
  if (!Array.isArray(items)) {
    return { valid: false, message: `${fieldName} must be an array` };
  }

  if (items.length === 0) return { valid: true, items: [] };

  const normalized = [];
  const ids = [];
  const seen = new Set();

  for (let index = 0; index < items.length; index += 1) {
    const item = items[index];
    const componentId = getReferenceId(item?.component);

    if (!isValidId(componentId)) {
      return {
        valid: false,
        message: `Invalid component ID in ${fieldName} at item ${index + 1}`,
      };
    }

    const id = String(componentId);
    if (seen.has(id)) {
      return {
        valid: false,
        message: `Duplicate components are not allowed in ${fieldName}`,
      };
    }

    seen.add(id);
    ids.push(id);

    const quantity = Number(item.quantity);
    if (!Number.isFinite(quantity) || quantity <= 0) {
      return {
        valid: false,
        message: `Quantity must be greater than 0 in ${fieldName} item ${index + 1}`,
      };
    }

    normalized.push({
      component: componentId,
      quantity,
      unit: String(item.unit || "pc").trim() || "pc",
      specification: String(item.specification || "").trim(),
      notes: String(item.notes || "").trim(),
    });
  }

  const components = await Component.find({ _id: { $in: ids } })
    .select("_id name type isActive")
    .lean();

  if (components.length !== ids.length) {
    return {
      valid: false,
      message: `One or more ${fieldName} components do not exist`,
    };
  }

  for (const component of components) {
    if (activeOnly && !component.isActive) {
      return {
        valid: false,
        message: `${component.name} is inactive and cannot be used in ${fieldName}`,
      };
    }

    if (component.type !== "packaging") {
      return {
        valid: false,
        message: `${component.name} is not a packaging component`,
      };
    }
  }

  return { valid: true, items: normalized };
};

/* =========================================================
   CONTAINER HELPERS
========================================================= */

// Incomplete procurement boxes are legitimate Admin/Archive records.
// Do NOT convert missing capacity to 0 or NaN in MongoDB.
const normalizeContainerDimensions = (dimensions) => {
  if (!dimensions) return undefined;
  const fields = [dimensions.length, dimensions.width, dimensions.height];
  if (fields.some((value) => value === undefined || value === null || value === "")) {
    return undefined;
  }
  const [length, width, height] = fields.map(Number);
  if (![length, width, height].every((value) => Number.isFinite(value) && value > 0)) {
    return undefined;
  }
  return {
    length,
    width,
    height,
    unit: DIMENSION_UNITS.includes(dimensions.unit) ? dimensions.unit : "cm",
  };
};

const normalizeWeightCapacity = (weight) => {
  if (!weight || weight.value === undefined || weight.value === null || weight.value === "") {
    return undefined;
  }
  const value = Number(weight.value);
  if (!Number.isFinite(value) || value <= 0) return undefined;
  return { value, unit: WEIGHT_UNITS.includes(weight.unit) ? weight.unit : "kg" };
};

const validateProductionLeadTime = (leadTime = {}) => {
  for (const field of ["personalizationDays", "assemblyDays", "packingDays"]) {
    const raw = leadTime[field];
    if (raw === undefined || raw === null || raw === "") continue;

    const value = Number(raw);
    if (!Number.isInteger(value) || value < 0) {
      return `${field} must be a non-negative whole number`;
    }
  }

  return null;
};

const normalizeProductionLeadTime = (leadTime = {}) => ({
  personalizationDays: Number(leadTime.personalizationDays ?? 0),
  assemblyDays: Number(leadTime.assemblyDays ?? 0),
  packingDays: Number(leadTime.packingDays ?? 0),
});

const validateContainerPayload = ({
  outerDimensions,
  innerDimensions,
  maxContentWeight,
  usableVolumePercent,
  maxItems,
  availability,
  productionLeadTime,
  defaultCourierDays,
  channels,
  hamperUse,
  customerSelectable,
  productPriority,
  mrp,
  sellingPrice,
  latestUnitCost,
  actualLandedCost,
  taxPercent,
  taxEnabled,
  discount,
  leadTimeDays,
  source,
}) => {
  // Customer-selectable boxes need verified physical capacity. Admin-only
  // boxes may be stored and edited while supplier capacity fields are missing.
  const selectable = parseBoolean(customerSelectable) === true;
  const checkDimensions = (label, data, required) => {
    if (!data) return required ? `${label} dimensions are required` : null;
    const values = [data.length, data.width, data.height];
    const anyEntered = values.some((value) => value !== undefined && value !== null && value !== "");
    if (!anyEntered && !required) return null;
    if (data.unit && !DIMENSION_UNITS.includes(data.unit)) {
      return `${label} dimension unit must be mm or cm`;
    }
    for (const key of ["length", "width", "height"]) {
      const raw = data[key];
      if (raw === undefined || raw === null || raw === "" || !Number.isFinite(Number(raw)) || Number(raw) <= 0) {
        return `${label} ${key} must be greater than 0`;
      }
    }
    return null;
  };

  const outerError = checkDimensions("Outer", outerDimensions, true);
  if (outerError) return outerError;
  const innerError = checkDimensions("Inner", innerDimensions, selectable);
  if (innerError) return innerError;

  const hasInner = Boolean(
    innerDimensions &&
    [innerDimensions.length, innerDimensions.width, innerDimensions.height].every(
      (value) => value !== undefined && value !== null && value !== "" && Number(value) > 0
    )
  );
  if (hasInner) {
    const outerUnit = outerDimensions.unit || "cm";
    const innerUnit = innerDimensions.unit || "cm";
    const outerLength = dimensionToCm(outerDimensions.length, outerUnit);
    const outerWidth = dimensionToCm(outerDimensions.width, outerUnit);
    const outerHeight = dimensionToCm(outerDimensions.height, outerUnit);
    const innerLength = dimensionToCm(innerDimensions.length, innerUnit);
    const innerWidth = dimensionToCm(innerDimensions.width, innerUnit);
    const innerHeight = dimensionToCm(innerDimensions.height, innerUnit);
    if (innerLength > outerLength || innerWidth > outerWidth || innerHeight > outerHeight) {
      return "Inner dimensions cannot be larger than outer dimensions";
    }
  }

  const weightEntered = Boolean(
    maxContentWeight &&
    maxContentWeight.value !== undefined &&
    maxContentWeight.value !== null &&
    maxContentWeight.value !== ""
  );
  if (selectable && !weightEntered) return "Maximum content weight is required";
  if (weightEntered) {
    const weightValue = Number(maxContentWeight.value);
    if (!Number.isFinite(weightValue) || weightValue <= 0) {
      return "Maximum content weight must be greater than 0";
    }
    if (maxContentWeight.unit && !WEIGHT_UNITS.includes(maxContentWeight.unit)) {
      return "Weight unit must be g or kg";
    }
  }

  const percentage = Number(usableVolumePercent);
  if (!Number.isFinite(percentage) || percentage < 1 || percentage > 100) {
    return "Usable volume percent must be between 1 and 100";
  }

  const parsedMaxItems = Number(maxItems);
  if (!Number.isInteger(parsedMaxItems) || parsedMaxItems < 0) {
    return "Max items must be a non-negative integer";
  }

  const availabilityError = validateAvailabilityPayload(availability, {
    stockUnit: false,
    label: "container availability",
  });
  if (availabilityError) return availabilityError;

  const leadError = validateProductionLeadTime(productionLeadTime || {});
  if (leadError) return leadError;

  const courier = parseCourierDays(defaultCourierDays, null);
  if (!courier.valid) return courier.message;

  const booleanError = validateBooleanValue(hamperUse, "hamperUse");
  if (booleanError) return booleanError;

  const taxEnabledError = validateBooleanValue(taxEnabled, "taxEnabled");
  if (taxEnabledError) return taxEnabledError;

  const discountError = validateDiscountConfig(discount);
  if (discountError) return discountError;

  const numberChecks = [
    [productPriority, "Product priority", { min: 0 }],
    [mrp, "MRP", { min: 0 }],
    [sellingPrice, "Selling price", { min: 0 }],
    [latestUnitCost, "Latest unit cost", { min: 0 }],
    [actualLandedCost, "Actual landed cost", { min: 0 }],
    [taxPercent, "Tax percent", { min: 0, max: 100 }],
    [leadTimeDays, "Lead time days", { min: 0 }],
  ];

  for (const [value, label, options] of numberChecks) {
    const error = validateOptionalNumber(value, label, options);
    if (error) return error;
  }

  const channelError = validateChannels(channels);
  if (channelError) return channelError;

  const sourceError = validateSource(source);
  if (sourceError) return sourceError;

  return null;
};

const calculateContainerCapacity = (container) => {
  const dimensions = container?.innerDimensions;
  if (!dimensions) return null;

  const length = dimensionToCm(dimensions.length, dimensions.unit);
  const width = dimensionToCm(dimensions.width, dimensions.unit);
  const height = dimensionToCm(dimensions.height, dimensions.unit);

  if (![length, width, height].every((value) => Number.isFinite(value) && value > 0)) return null;

  const totalVolume = length * width * height;
  const percentage = Number(container.usableVolumePercent);
  const usableVolume = totalVolume * (Number.isFinite(percentage) ? percentage / 100 : 0.85);

  return {
    totalVolumeCm3: Number(totalVolume.toFixed(2)),
    usableVolumeCm3: Number(usableVolume.toFixed(2)),
  };
};

const validateContainerReference = async (containerId) => {
  if (containerId === undefined || containerId === null || containerId === "") {
    return { valid: true, containerId: null };
  }

  if (!isValidId(containerId)) {
    return { valid: false, message: "Invalid container ID" };
  }

  const container = await Container.findById(containerId)
    .select("_id isActive")
    .lean();

  if (!container) return { valid: false, message: "Container not found" };
  if (!container.isActive) {
    return { valid: false, message: "Inactive container cannot be assigned to an SKU" };
  }

  return { valid: true, containerId: container._id };
};

/* =========================================================
   SKU / HAMPER HELPERS
========================================================= */

const calculateEarliestExpiryDate = async (hamperContents = []) => {
  if (!Array.isArray(hamperContents) || hamperContents.length === 0) return null;

  const componentIds = [
    ...new Set(
      hamperContents
        .map((item) => String(getReferenceId(item?.component) || ""))
        .filter((id) => isValidId(id))
    ),
  ];

  if (componentIds.length === 0) return null;

  const foodComponents = await Component.find({
    _id: { $in: componentIds },
    type: "food",
    expiryDate: { $ne: null },
  })
    .select("expiryDate")
    .lean();

  const dates = foodComponents
    .map((component) => component.expiryDate && new Date(component.expiryDate))
    .filter((date) => date && !Number.isNaN(date.getTime()));

  if (dates.length === 0) return null;
  return new Date(Math.min(...dates.map((date) => date.getTime())));
};

const validateAndNormalizeHamperContents = async (items = []) => {
  if (!Array.isArray(items)) {
    return { valid: false, message: "hamperContents must be an array" };
  }

  if (items.length === 0) {
    return { valid: true, items: [], earliestExpiryDate: null };
  }

  const normalized = [];
  const ids = [];
  const seen = new Set();

  for (let index = 0; index < items.length; index += 1) {
    const item = items[index];
    const componentId = getReferenceId(item?.component);

    if (!isValidId(componentId)) {
      return {
        valid: false,
        message: `Invalid component ID in hamperContents at item ${index + 1}`,
      };
    }

    const id = String(componentId);
    if (seen.has(id)) {
      return {
        valid: false,
        message: "Duplicate components are not allowed in hamper contents",
      };
    }

    seen.add(id);
    ids.push(id);

    const quantity = Number(item.quantity);
    if (!Number.isFinite(quantity) || quantity <= 0) {
      return {
        valid: false,
        message: `Quantity must be greater than 0 in hamperContents item ${index + 1}`,
      };
    }

    let isOptional = false;
    if (item.isOptional !== undefined) {
      const parsed = parseBoolean(item.isOptional);
      if (parsed === undefined) {
        return {
          valid: false,
          message: `isOptional must be true or false in hamperContents item ${index + 1}`,
        };
      }
      isOptional = parsed;
    }

    const sortOrder = item.sortOrder !== undefined ? Number(item.sortOrder) : index;
    if (!Number.isFinite(sortOrder)) {
      return {
        valid: false,
        message: `Invalid sortOrder in hamperContents item ${index + 1}`,
      };
    }

    normalized.push({
      component: componentId,
      quantity,
      unit: String(item.unit || "pc").trim() || "pc",
      displayName: String(item.displayName || "").trim(),
      sortOrder,
      isOptional,
    });
  }

  const components = await Component.find({ _id: { $in: ids } })
    .select("_id name type hamperRole expiryDate isActive")
    .lean();

  if (components.length !== ids.length) {
    return {
      valid: false,
      message: "One or more hamper content components do not exist",
    };
  }

  for (const component of components) {
    if (!component.isActive) {
      return {
        valid: false,
        message: `${component.name} is inactive and cannot be added to hamper contents`,
      };
    }

    if (component.type === "packaging") {
      return {
        valid: false,
        message: `${component.name} is a packaging component and cannot be added to customer-facing hamper contents`,
      };
    }

    if ((component.hamperRole || "content") === "decoration") {
      return {
        valid: false,
        message: `${component.name} is a decoration and must be stored in the separate decorations field`,
      };
    }
  }

  const expiryDates = components
    .filter((component) => component.type === "food" && component.expiryDate)
    .map((component) => new Date(component.expiryDate))
    .filter((date) => !Number.isNaN(date.getTime()));

  return {
    valid: true,
    items: normalized,
    earliestExpiryDate:
      expiryDates.length > 0
        ? new Date(Math.min(...expiryDates.map((date) => date.getTime())))
        : null,
  };
};

const validateAndNormalizeDecorations = async (items = []) => {
  if (!Array.isArray(items)) {
    return { valid: false, message: "decorations must be an array" };
  }

  if (items.length === 0) {
    return { valid: true, items: [] };
  }

  const normalized = [];
  const ids = [];
  const seen = new Set();

  for (let index = 0; index < items.length; index += 1) {
    const item = items[index];
    const componentId = getReferenceId(item?.component);

    if (!isValidId(componentId)) {
      return {
        valid: false,
        message: `Invalid component ID in decorations at item ${index + 1}`,
      };
    }

    const id = String(componentId);
    if (seen.has(id)) {
      return {
        valid: false,
        message: "Duplicate components are not allowed in decorations",
      };
    }

    seen.add(id);
    ids.push(id);

    const quantity = Number(item.quantity);
    if (!Number.isFinite(quantity) || quantity <= 0) {
      return {
        valid: false,
        message: `Quantity must be greater than 0 in decorations item ${index + 1}`,
      };
    }

    let isOptional = false;
    if (item.isOptional !== undefined) {
      const parsed = parseBoolean(item.isOptional);
      if (parsed === undefined) {
        return {
          valid: false,
          message: `isOptional must be true or false in decorations item ${index + 1}`,
        };
      }
      isOptional = parsed;
    }

    const sortOrder = item.sortOrder !== undefined ? Number(item.sortOrder) : index;
    if (!Number.isFinite(sortOrder)) {
      return {
        valid: false,
        message: `Invalid sortOrder in decorations item ${index + 1}`,
      };
    }

    normalized.push({
      component: componentId,
      quantity,
      unit: String(item.unit || "pc").trim() || "pc",
      displayName: String(item.displayName || "").trim(),
      sortOrder,
      isOptional,
    });
  }

  const components = await Component.find({ _id: { $in: ids } })
    .select("_id name type hamperRole isActive customerSelectable")
    .lean();

  if (components.length !== ids.length) {
    return { valid: false, message: "One or more decoration components do not exist" };
  }

  for (const component of components) {
    if (!component.isActive) {
      return {
        valid: false,
        message: `${component.name} is inactive and cannot be used as a decoration`,
      };
    }

    if ((component.hamperRole || "content") !== "decoration") {
      return {
        valid: false,
        message: `${component.name} is not configured as a decoration`,
      };
    }
  }

  return { valid: true, items: normalized };
};

const syncSkuExpiryForComponent = async (componentId) => {
  const skus = await SKU.find({
    "hamperContents.component": componentId,
  }).select("_id hamperContents earliestExpiryDate");

  for (const sku of skus) {
    sku.earliestExpiryDate = await calculateEarliestExpiryDate(sku.hamperContents);
    await sku.save();
  }
};

/* =========================================================
   AVAILABILITY / ETA ENGINE
========================================================= */

const resolveDependencyReadyDate = (
  dependency,
  today,
  { requiredQuantity = null, requiredUnit = "pc", stockUnit = true } = {}
) => {
  if (!dependency) {
    return { ready: false, readyDate: null, reason: "REFERENCE_NOT_FOUND" };
  }

  if (dependency.isActive === false) {
    return { ready: false, readyDate: null, reason: "INACTIVE" };
  }

  const availability = dependency.availability || {};
  const status = availability.status || "in_stock";
  const availableQuantity =
    availability.availableQuantity === undefined ||
    availability.availableQuantity === null ||
    availability.availableQuantity === ""
      ? null
      : Number(availability.availableQuantity);

  let enoughNow = true;

  if (
    requiredQuantity !== null &&
    availableQuantity !== null &&
    Number.isFinite(availableQuantity)
  ) {
    const targetUnit = stockUnit ? availability.unit || "pc" : "pc";
    const requiredInStockUnit = convertQuantity(
      requiredQuantity,
      requiredUnit,
      targetUnit
    );

    if (requiredInStockUnit !== null) {
      enoughNow = availableQuantity >= requiredInStockUnit;
    }
  }

  if (status === "in_stock" && enoughNow) {
    return { ready: true, readyDate: today, reason: null };
  }

  const nextAvailableDate = availability.nextAvailableDate
    ? toUtcDay(availability.nextAvailableDate)
    : null;

  if (nextAvailableDate) {
    return {
      ready: true,
      readyDate: nextAvailableDate > today ? nextAvailableDate : today,
      reason: null,
    };
  }

  if (status === "in_stock" && !enoughNow) {
    return { ready: false, readyDate: null, reason: "INSUFFICIENT_STOCK" };
  }

  if (status === "incoming" || status === "out_of_stock") {
    return {
      ready: false,
      readyDate: null,
      reason: "AVAILABILITY_DATE_UNKNOWN",
    };
  }

  return { ready: false, readyDate: null, reason: "UNAVAILABLE" };
};

const makeDependency = (
  source,
  reference,
  readyResult,
  { requiredQuantity = null, requiredUnit = null } = {}
) => ({
  source,
  referenceId: reference?._id || null,
  name: reference?.name || source,
  code: reference?.code || "",
  requiredQuantity,
  requiredUnit,
  availabilityStatus: reference?.availability?.status || null,
  availableQuantity: reference?.availability?.availableQuantity ?? null,
  availabilityUnit: reference?.availability?.unit || (source === "container" ? "pc" : null),
  nextAvailableDate: reference?.availability?.nextAvailableDate || null,
  ready: readyResult.ready,
  readyDate: readyResult.readyDate,
  blockingReason: readyResult.reason,
});

const finalizeDeliveryEstimate = ({
  dependencies,
  leadTime,
  courierDays,
  today = toUtcDay(new Date()),
  includeDetails = false,
}) => {
  const blocked = dependencies.filter((item) => !item.ready);
  const normalizedLeadTime = normalizeProductionLeadTime(leadTime || {});
  const productionLeadDays =
    normalizedLeadTime.personalizationDays +
    normalizedLeadTime.assemblyDays +
    normalizedLeadTime.packingDays;

  if (blocked.length > 0) {
    const result = {
      status: "unavailable",
      canEstimate: false,
      materialsReadyDate: null,
      productionLeadDays,
      dispatchReadyDate: null,
      courierDays,
      expectedDeliveryDate: null,
    };

    if (includeDetails) {
      result.dependencies = dependencies;
      result.blockedDependencies = blocked;
    }

    return result;
  }

  const readyDates = dependencies
    .map((item) => item.readyDate && new Date(item.readyDate))
    .filter((date) => date && !Number.isNaN(date.getTime()));

  const materialsReadyDate = new Date(
    Math.max(today.getTime(), ...readyDates.map((date) => date.getTime()))
  );

  const dispatchReadyDate = addCalendarDays(materialsReadyDate, productionLeadDays);
  const expectedDeliveryDate =
    courierDays === null ? null : addCalendarDays(dispatchReadyDate, courierDays);

  const result = {
    status: materialsReadyDate > today ? "scheduled" : "ready",
    canEstimate: true,
    materialsReadyDate,
    productionLeadDays,
    dispatchReadyDate,
    courierDays,
    expectedDeliveryDate,
  };

  if (includeDetails) {
    result.dependencies = dependencies;
    result.blockedDependencies = [];
  }

  return result;
};

const calculateSkuDeliveryEstimate = async (
  sku,
  { courierDays = null, includeDetails = false } = {}
) => {
  const today = toUtcDay(new Date());
  const dependencies = [];

  const containerId = getReferenceId(sku.container);
  if (containerId) {
    const container = await Container.findById(containerId)
      .select("_id name code isActive availability")
      .lean();

    const ready = resolveDependencyReadyDate(container, today, {
      requiredQuantity: 1,
      requiredUnit: "pc",
      stockUnit: false,
    });

    dependencies.push(
      makeDependency("container", container, ready, {
        requiredQuantity: 1,
        requiredUnit: "pc",
      })
    );
  }

  const contentEntries = Array.isArray(sku.hamperContents)
    ? sku.hamperContents.filter((item) => !item.isOptional)
    : [];

  const materialEntries = Array.isArray(sku.internalMaterials)
    ? sku.internalMaterials
    : [];

  const decorationEntries = Array.isArray(sku.decorations)
    ? sku.decorations.filter((item) => !item.isOptional)
    : [];

  const componentIds = [
    ...new Set(
      [...contentEntries, ...materialEntries, ...decorationEntries]
        .map((item) => String(getReferenceId(item.component) || ""))
        .filter((id) => isValidId(id))
    ),
  ];

  const components = componentIds.length
    ? await Component.find({ _id: { $in: componentIds } })
        .select("_id name code isActive availability")
        .lean()
    : [];

  const componentMap = new Map(
    components.map((component) => [String(component._id), component])
  );

  for (const item of contentEntries) {
    const component = componentMap.get(String(getReferenceId(item.component)));
    const ready = resolveDependencyReadyDate(component, today, {
      requiredQuantity: item.quantity,
      requiredUnit: item.unit || "pc",
      stockUnit: true,
    });

    dependencies.push(
      makeDependency("hamper_content", component, ready, {
        requiredQuantity: item.quantity,
        requiredUnit: item.unit || "pc",
      })
    );
  }

  for (const item of materialEntries) {
    const component = componentMap.get(String(getReferenceId(item.component)));
    const ready = resolveDependencyReadyDate(component, today, {
      requiredQuantity: item.quantity,
      requiredUnit: item.unit || "pc",
      stockUnit: true,
    });

    dependencies.push(
      makeDependency("internal_material", component, ready, {
        requiredQuantity: item.quantity,
        requiredUnit: item.unit || "pc",
      })
    );
  }

  for (const item of decorationEntries) {
    const component = componentMap.get(String(getReferenceId(item.component)));
    const ready = resolveDependencyReadyDate(component, today, {
      requiredQuantity: item.quantity,
      requiredUnit: item.unit || "pc",
      stockUnit: true,
    });

    dependencies.push(
      makeDependency("decoration", component, ready, {
        requiredQuantity: item.quantity,
        requiredUnit: item.unit || "pc",
      })
    );
  }

  return finalizeDeliveryEstimate({
    dependencies,
    leadTime: sku.productionLeadTime,
    courierDays,
    today,
    includeDetails,
  });
};

/* =========================================================
   3D CUSTOM HAMPER CAPACITY ENGINE
========================================================= */

const getComponentPhysicalData = (component) => {
  const dimensions = component?.dimensions || {};
  const length = dimensionToCm(dimensions.length, dimensions.unit);
  const width = dimensionToCm(dimensions.width, dimensions.unit);
  const height = dimensionToCm(dimensions.height, dimensions.unit);
  const weight = weightToGrams(component?.weight?.value, component?.weight?.unit);

  if (
    ![length, width, height, weight].every(Number.isFinite) ||
    length <= 0 ||
    width <= 0 ||
    height <= 0 ||
    weight <= 0
  ) {
    return null;
  }

  return {
    length,
    width,
    height,
    weightGrams: weight,
    volumeCm3: length * width * height,
  };
};

const uniqueOrientations = ({ length, width, height }) => {
  const permutations = [
    [length, width, height],
    [length, height, width],
    [width, length, height],
    [width, height, length],
    [height, length, width],
    [height, width, length],
  ];

  const seen = new Set();
  const result = [];

  for (const [l, w, h] of permutations) {
    const key = `${l}|${w}|${h}`;
    if (seen.has(key)) continue;
    seen.add(key);
    result.push({ length: l, width: w, height: h });
  }

  return result;
};

const boxCanFitOne = (box, item) =>
  uniqueOrientations(item).some(
    (orientation) =>
      orientation.length <= box.length + 1e-9 &&
      orientation.width <= box.width + 1e-9 &&
      orientation.height <= box.height + 1e-9
  );

const pruneSpaces = (spaces) =>
  spaces.filter(
    (space) => space.length > 1e-9 && space.width > 1e-9 && space.height > 1e-9
  );

const packRectangles = (box, instances) => {
  const sorted = [...instances].sort((a, b) => b.volumeCm3 - a.volumeCm3);
  let spaces = [{ ...box }];
  const placements = [];

  for (const instance of sorted) {
    let best = null;

    for (let spaceIndex = 0; spaceIndex < spaces.length; spaceIndex += 1) {
      const space = spaces[spaceIndex];
      const spaceVolume = space.length * space.width * space.height;

      for (const orientation of uniqueOrientations(instance)) {
        if (
          orientation.length <= space.length + 1e-9 &&
          orientation.width <= space.width + 1e-9 &&
          orientation.height <= space.height + 1e-9
        ) {
          const itemVolume = orientation.length * orientation.width * orientation.height;
          const score = spaceVolume - itemVolume;

          if (!best || score < best.score) {
            best = { spaceIndex, space, orientation, score };
          }
        }
      }
    }

    if (!best) {
      return {
        fits: false,
        failedItem: instance,
        placements,
      };
    }

    const { space, orientation, spaceIndex } = best;
    spaces.splice(spaceIndex, 1);

    const { length: l, width: w, height: h } = orientation;

    spaces.push(
      {
        length: space.length - l,
        width: space.width,
        height: space.height,
      },
      {
        length: l,
        width: space.width - w,
        height: space.height,
      },
      {
        length: l,
        width: w,
        height: space.height - h,
      }
    );

    spaces = pruneSpaces(spaces);
    placements.push({ componentId: instance.componentId, orientation });
  }

  return { fits: true, placements };
};

const configurationReasonMessage = (reason) => {
  const map = {
    INVALID_CONTAINER_DATA:
      "Box true inner dimensions, usable volume or max content weight are missing",
    INVALID_COMPONENT_DATA: "Product physical dimensions or weight are missing",
    INVALID_SELECTION_DATA: "Hamper composition contains an invalid quantity",
    DIMENSION_NOT_FIT: "Product dimensions do not fit this box",
    MAX_ITEMS_EXCEEDED: "Box item-count capacity exceeded",
    USABLE_VOLUME_EXCEEDED: "Not enough usable box space",
    WEIGHT_EXCEEDED: "Selected products exceed the box weight capacity",
    PACKING_LAYOUT_NOT_FIT: "Products cannot be arranged inside the remaining box space",
    UNAVAILABLE: "Product is currently unavailable with no known restock date",
    PRICE_NOT_SET: "Selling price has not been configured for this item",
  };

  return map[reason] || "Configuration is not valid";
};

const evaluatePhysicalConfiguration = (
  container,
  selections = [],
  componentMap = new Map()
) => {
  /*
   * The same fit engine is used by live builder validation and Product Master
   * preview. Incomplete container data must become a normal REVIEW result, not
   * a server exception.
   */
  if (!container || !validPositiveDimensions(container.innerDimensions)) {
    return { valid: false, reason: "INVALID_CONTAINER_DATA" };
  }

  const inner = container.innerDimensions;
  const box = {
    length: dimensionToCm(inner.length, inner.unit),
    width: dimensionToCm(inner.width, inner.unit),
    height: dimensionToCm(inner.height, inner.unit),
  };

  if (
    ![box.length, box.width, box.height].every(
      (value) => Number.isFinite(value) && value > 0
    )
  ) {
    return { valid: false, reason: "INVALID_CONTAINER_DATA" };
  }

  const boxCapacity = calculateContainerCapacity(container);
  const maxWeightGrams = weightToGrams(
    container.maxContentWeight?.value,
    container.maxContentWeight?.unit
  );
  const maxItems = Number(container.maxItems || 0);

  if (
    !boxCapacity ||
    !Number.isFinite(Number(boxCapacity.usableVolumeCm3)) ||
    Number(boxCapacity.usableVolumeCm3) <= 0 ||
    !Number.isFinite(maxWeightGrams) ||
    maxWeightGrams <= 0
  ) {
    return { valid: false, reason: "INVALID_CONTAINER_DATA" };
  }

  const normalizedSelections = Array.isArray(selections) ? selections : [];

  if (!componentMap || typeof componentMap.get !== "function") {
    return { valid: false, reason: "INVALID_COMPONENT_DATA" };
  }

  const instances = [];
  let itemCount = 0;
  let usedVolumeCm3 = 0;
  let usedWeightGrams = 0;

  for (const selection of normalizedSelections) {
    const quantity = Number(selection?.quantity);

    if (!Number.isFinite(quantity) || quantity <= 0) {
      return {
        valid: false,
        reason: "INVALID_SELECTION_DATA",
        componentId: selection?.componentId || null,
      };
    }

    const component = componentMap.get(String(selection?.componentId || ""));
    const physical = getComponentPhysicalData(component);

    if (!physical) {
      return {
        valid: false,
        reason: "INVALID_COMPONENT_DATA",
        componentId: selection?.componentId || null,
      };
    }

    if (!boxCanFitOne(box, physical)) {
      return {
        valid: false,
        reason: "DIMENSION_NOT_FIT",
        componentId: selection?.componentId || null,
      };
    }

    itemCount += quantity;
    usedVolumeCm3 += physical.volumeCm3 * quantity;
    usedWeightGrams += physical.weightGrams * quantity;

    for (let i = 0; i < quantity; i += 1) {
      instances.push({
        componentId: selection?.componentId || null,
        ...physical,
      });
    }
  }

  if (maxItems > 0 && itemCount > maxItems) {
    return { valid: false, reason: "MAX_ITEMS_EXCEEDED" };
  }

  if (usedVolumeCm3 > boxCapacity.usableVolumeCm3 + 1e-9) {
    return { valid: false, reason: "USABLE_VOLUME_EXCEEDED" };
  }

  if (usedWeightGrams > maxWeightGrams + 1e-9) {
    return { valid: false, reason: "WEIGHT_EXCEEDED" };
  }

  const packing = packRectangles(box, instances);
  if (!packing.fits) {
    return {
      valid: false,
      reason: "PACKING_LAYOUT_NOT_FIT",
      componentId: packing.failedItem?.componentId || null,
    };
  }

  return {
    valid: true,
    reason: null,
    itemCount,
    capacity: {
      usedVolumeCm3: Number(usedVolumeCm3.toFixed(2)),
      usableVolumeCm3: boxCapacity.usableVolumeCm3,
      remainingVolumeCm3: Number(
        Math.max(0, boxCapacity.usableVolumeCm3 - usedVolumeCm3).toFixed(2)
      ),
      usedWeightGrams: Number(usedWeightGrams.toFixed(2)),
      maxWeightGrams: Number(maxWeightGrams.toFixed(2)),
      remainingWeightGrams: Number(
        Math.max(0, maxWeightGrams - usedWeightGrams).toFixed(2)
      ),
      itemCount,
      maxItems: maxItems || null,
    },
    packing,
  };
};

const normalizeConfigurationItems = (items = []) => {
  if (!Array.isArray(items)) {
    return { valid: false, message: "items must be an array" };
  }

  const merged = new Map();

  for (let index = 0; index < items.length; index += 1) {
    const rawId = items[index]?.componentId || items[index]?.component;
    const componentId = String(rawId || "");
    const quantity = Number(items[index]?.quantity ?? 1);

    if (!isValidId(componentId)) {
      return {
        valid: false,
        message: `Invalid component ID at item ${index + 1}`,
      };
    }

    if (!Number.isInteger(quantity) || quantity <= 0 || quantity > 100) {
      return {
        valid: false,
        message: `Configuration quantity must be a whole number between 1 and 100 at item ${index + 1}`,
      };
    }

    merged.set(componentId, (merged.get(componentId) || 0) + quantity);
  }

  return {
    valid: true,
    items: [...merged.entries()].map(([componentId, quantity]) => ({
      componentId,
      quantity,
    })),
  };
};

const calculateConfigurationPricing = (
  container,
  selections,
  componentMap,
  decorationSelections = []
) => {
  const missingPrices = [];

  const containerPricing = hasPrice(container?.sellingPrice)
    ? calculateCatalogPricing({
        baseSellingPrice: container.sellingPrice,
        taxPercent: container.taxPercent ?? 0,
        taxEnabled: container.taxEnabled !== false,
        discount: container.discount || {},
      })
    : null;

  if (!containerPricing) {
    missingPrices.push({
      type: "container",
      referenceId: container?._id || null,
      name: container?.name || "Container",
      code: container?.code || "",
    });
  }

  const buildLines = (source, role) =>
    source.map((selection) => {
      const component = componentMap.get(String(selection.componentId));
      const pricing = hasPrice(component?.sellingPrice)
        ? calculateCatalogPricing({
            baseSellingPrice: component.sellingPrice,
            taxPercent: component.taxPercent ?? 0,
            taxEnabled: component.taxEnabled !== false,
            discount: component.discount || {},
          })
        : null;

      if (!pricing) {
        missingPrices.push({
          type: role === "decoration" ? "decoration" : "component",
          referenceId: component?._id || selection.componentId,
          name: component?.name || "Component",
          code: component?.code || "",
        });
      }

      return {
        componentId: selection.componentId,
        name: component?.name || "",
        code: component?.code || "",
        hamperRole: role,
        quantity: selection.quantity,
        baseUnitPrice: pricing?.baseSellingPrice ?? null,
        discount: pricing?.discount || null,
        discountAmount: pricing?.discountAmount ?? null,
        taxableUnitPrice: pricing?.taxableValue ?? null,
        taxPercent: pricing?.taxPercent ?? null,
        taxAmount: pricing?.taxAmount ?? null,
        hsnSac: component?.hsnSac || "",
        unitPrice: pricing?.price ?? null,
        lineTotal:
          pricing === null ? null : money(pricing.price * selection.quantity),
      };
    });

  const itemLines = buildLines(selections, "content");
  const decorationLines = buildLines(decorationSelections, "decoration");

  const itemsTotal = itemLines.every((line) => line.lineTotal !== null)
    ? money(itemLines.reduce((total, line) => total + line.lineTotal, 0))
    : null;

  const decorationsTotal = decorationLines.every((line) => line.lineTotal !== null)
    ? money(decorationLines.reduce((total, line) => total + line.lineTotal, 0))
    : null;

  const total =
    containerPricing !== null &&
    itemsTotal !== null &&
    decorationsTotal !== null
      ? money(containerPricing.price + itemsTotal + decorationsTotal)
      : null;

  return {
    complete: missingPrices.length === 0,
    currency: "INR",
    containerBasePrice: containerPricing?.baseSellingPrice ?? null,
    containerDiscount: containerPricing?.discount || null,
    containerDiscountAmount: containerPricing?.discountAmount ?? null,
    containerTaxPercent: containerPricing?.taxPercent ?? null,
    containerTaxAmount: containerPricing?.taxAmount ?? null,
    containerHsnSac: container?.hsnSac || "",
    containerPrice: containerPricing?.price ?? null,
    itemsTotal,
    decorationsTotal,
    total,
    items: itemLines,
    decorations: decorationLines,
    missingPrices,
  };
};

const calculateCustomConfigurationEta = async (
  container,
  selections,
  componentMap,
  courierDays,
  decorationSelections = []
) => {
  const today = toUtcDay(new Date());
  const dependencies = [];

  const containerReady = resolveDependencyReadyDate(container, today, {
    requiredQuantity: 1,
    requiredUnit: "pc",
    stockUnit: false,
  });

  dependencies.push(
    makeDependency("container", container, containerReady, {
      requiredQuantity: 1,
      requiredUnit: "pc",
    })
  );

  for (const selection of selections) {
    const component = componentMap.get(String(selection.componentId));
    const ready = resolveDependencyReadyDate(component, today, {
      requiredQuantity: selection.quantity,
      requiredUnit: "pc",
      stockUnit: true,
    });

    dependencies.push(
      makeDependency("selected_component", component, ready, {
        requiredQuantity: selection.quantity,
        requiredUnit: "pc",
      })
    );
  }

  for (const selection of decorationSelections) {
    const component = componentMap.get(String(selection.componentId));
    const ready = resolveDependencyReadyDate(component, today, {
      requiredQuantity: selection.quantity,
      requiredUnit: "pc",
      stockUnit: true,
    });

    dependencies.push(
      makeDependency("decorative_component", component, ready, {
        requiredQuantity: selection.quantity,
        requiredUnit: "pc",
      })
    );
  }

  const packingMaterials = Array.isArray(container.packingMaterials)
    ? container.packingMaterials
    : [];

  if (packingMaterials.length > 0) {
    const ids = packingMaterials
      .map((item) => String(getReferenceId(item.component) || ""))
      .filter((id) => isValidId(id));

    const materials = await Component.find({ _id: { $in: ids } })
      .select("_id name code isActive availability")
      .lean();

    const materialMap = new Map(
      materials.map((component) => [String(component._id), component])
    );

    for (const item of packingMaterials) {
      const component = materialMap.get(String(getReferenceId(item.component)));
      const ready = resolveDependencyReadyDate(component, today, {
        requiredQuantity: item.quantity,
        requiredUnit: item.unit || "pc",
        stockUnit: true,
      });

      dependencies.push(
        makeDependency("packing_material", component, ready, {
          requiredQuantity: item.quantity,
          requiredUnit: item.unit || "pc",
        })
      );
    }
  }

  return finalizeDeliveryEstimate({
    dependencies,
    leadTime: container.productionLeadTime,
    courierDays,
    today,
    includeDetails: false,
  });
};

/* =========================================================
   PRODUCT MASTER EXCEL IMPORT HELPERS
========================================================= */

const PRODUCT_MASTER_SHEET = "Product Master";
const HAMPER_COMPOSITION_SHEET = "Hamper Composition";
const CONTAINER_SETUP_SHEET = "HAMPORIUM Container Setup";
const DECORATION_MASTER_SHEET = "Decoration Master";
const PROCUREMENT_HAMPER_MASTER_SHEET = "Hamper Master";
const PROCUREMENT_HAMPER_RECIPE_SHEET = "Hamper Recipe";

const PRODUCT_MASTER_SHEET_ALIASES = [
  PRODUCT_MASTER_SHEET,
  "02 Product Master",
  "Products",
  "Catalogue Master",
  "Catalog Master",
];

const HAMPER_MASTER_SHEET_ALIASES = [
  PROCUREMENT_HAMPER_MASTER_SHEET,
  "09 Hamper Master",
  "Curated Gift Master",
  "Hamper / Curated Gift Master",
];

const HAMPER_RECIPE_SHEET_ALIASES = [
  PROCUREMENT_HAMPER_RECIPE_SHEET,
  "10 Hamper Recipe",
  "Hamper BOM",
  "Ready Made Composition",
  "Ready-Made Composition",
  HAMPER_COMPOSITION_SHEET,
];

/*
 * Memory guardrails for large procurement workbooks. The real master contains
 * many operational sheets that the catalogue importer does not need. Parsing
 * all of them at once can expand a single-digit-MB XLSX into hundreds of MB of
 * JavaScript objects.
 */
const PRODUCT_MASTER_MAX_PARSED_ROWS = 5000;

const productMasterMemoryMb = () => {
  const usage = process.memoryUsage();
  return {
    rss: Math.round(usage.rss / 1024 / 1024),
    heapUsed: Math.round(usage.heapUsed / 1024 / 1024),
    external: Math.round(usage.external / 1024 / 1024),
  };
};

const logProductMasterMemory = (stage, filename = "") => {
  const memory = productMasterMemoryMb();
  console.info(
    `[ProductMaster] ${stage}${filename ? ` (${filename})` : ""} | ` +
      `rss=${memory.rss}MB heap=${memory.heapUsed}MB external=${memory.external}MB`
  );
};


/*
 * ZIP-DIRECT V7 WORKBOOK STRATEGY
 * --------------------------------
 * The live procurement workbook is a Google-Sheets-exported XLSX with 31
 * sheets and ~126 MB of uncompressed worksheet XML. Loading it with SheetJS or
 * iterating every worksheet with ExcelJS can either spike Render memory or keep
 * the HTTP request alive long enough for the edge connection to reset.
 *
 * V7 does not parse the original workbook with either library. It reads the
 * XLSX ZIP central directory directly with Node fs/zlib, opens only the tiny
 * workbook metadata + sharedStrings + catalogue sheets we actually need, drops
 * prefilled/formula-only rows, creates a tiny compact XLSX in memory, and then
 * reuses the existing importer against that compact workbook.
 *
 * No new npm package is required.
 */
const ZIP_LOCAL_FILE_SIGNATURE = 0x04034b50;
const ZIP_CENTRAL_FILE_SIGNATURE = 0x02014b50;
const ZIP_EOCD_SIGNATURE = 0x06054b50;
const ZIP_MAX_EOCD_SEARCH = 65557;
const PRODUCT_MASTER_ZIP_MAX_COLUMNS = 250;
const PRODUCT_MASTER_ZIP_MAX_ROWS = 5000;
const PRODUCT_MASTER_ZIP_EMPTY_STREAK_STOP = 250;

const xmlDecode = (value = "") =>
  String(value)
    .replace(/&#x([0-9a-f]+);/gi, (_, hex) =>
      String.fromCodePoint(Number.parseInt(hex, 16))
    )
    .replace(/&#(\d+);/g, (_, dec) =>
      String.fromCodePoint(Number.parseInt(dec, 10))
    )
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&");

const xmlAttribute = (attributes = "", name = "") => {
  const escaped = String(name).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const match = String(attributes).match(
    new RegExp(`(?:^|\\s)${escaped}="([^"]*)"`, "i")
  );
  return match ? xmlDecode(match[1]) : "";
};

const readExactRange = (fd, offset, length) => {
  const buffer = Buffer.allocUnsafe(length);
  let cursor = 0;

  while (cursor < length) {
    const bytesRead = readSync(fd, buffer, cursor, length - cursor, offset + cursor);
    if (!bytesRead) break;
    cursor += bytesRead;
  }

  if (cursor !== length) {
    const error = new Error("Unable to read the uploaded XLSX archive completely.");
    error.statusCode = 400;
    throw error;
  }

  return buffer;
};

const openXlsxZip = (filePath) => {
  const fd = openSync(filePath, "r");

  try {
    const stat = fstatSync(fd);
    const tailLength = Math.min(stat.size, ZIP_MAX_EOCD_SEARCH);
    const tail = readExactRange(fd, stat.size - tailLength, tailLength);

    let eocdOffsetInTail = -1;
    for (let index = tail.length - 22; index >= 0; index -= 1) {
      if (tail.readUInt32LE(index) === ZIP_EOCD_SIGNATURE) {
        eocdOffsetInTail = index;
        break;
      }
    }

    if (eocdOffsetInTail < 0) {
      const error = new Error("Uploaded file is not a valid XLSX ZIP archive.");
      error.statusCode = 400;
      throw error;
    }

    const totalEntries = tail.readUInt16LE(eocdOffsetInTail + 10);
    const centralSize = tail.readUInt32LE(eocdOffsetInTail + 12);
    const centralOffset = tail.readUInt32LE(eocdOffsetInTail + 16);

    const central = readExactRange(fd, centralOffset, centralSize);
    const entries = new Map();
    let cursor = 0;
    let parsedEntries = 0;

    while (
      cursor + 46 <= central.length &&
      parsedEntries < totalEntries &&
      central.readUInt32LE(cursor) === ZIP_CENTRAL_FILE_SIGNATURE
    ) {
      const compressionMethod = central.readUInt16LE(cursor + 10);
      const compressedSize = central.readUInt32LE(cursor + 20);
      const uncompressedSize = central.readUInt32LE(cursor + 24);
      const fileNameLength = central.readUInt16LE(cursor + 28);
      const extraLength = central.readUInt16LE(cursor + 30);
      const commentLength = central.readUInt16LE(cursor + 32);
      const localHeaderOffset = central.readUInt32LE(cursor + 42);
      const fileName = central
        .subarray(cursor + 46, cursor + 46 + fileNameLength)
        .toString("utf8")
        .replace(/^\/+/, "");

      entries.set(fileName, {
        fileName,
        compressionMethod,
        compressedSize,
        uncompressedSize,
        localHeaderOffset,
      });

      cursor += 46 + fileNameLength + extraLength + commentLength;
      parsedEntries += 1;
    }

    const readEntryBuffer = (entryName) => {
      const normalizedName = String(entryName || "").replace(/^\/+/, "");
      const entry = entries.get(normalizedName);
      if (!entry) return null;

      const localHeader = readExactRange(fd, entry.localHeaderOffset, 30);
      if (localHeader.readUInt32LE(0) !== ZIP_LOCAL_FILE_SIGNATURE) {
        const error = new Error(`Invalid XLSX ZIP entry: ${normalizedName}`);
        error.statusCode = 400;
        throw error;
      }

      const fileNameLength = localHeader.readUInt16LE(26);
      const extraLength = localHeader.readUInt16LE(28);
      const dataOffset = entry.localHeaderOffset + 30 + fileNameLength + extraLength;
      const compressed = readExactRange(fd, dataOffset, entry.compressedSize);

      if (entry.compressionMethod === 0) return compressed;
      if (entry.compressionMethod === 8) return inflateRawSync(compressed);

      const error = new Error(
        `Unsupported XLSX compression method ${entry.compressionMethod}.`
      );
      error.statusCode = 400;
      throw error;
    };

    return {
      entries,
      readText(entryName) {
        const buffer = readEntryBuffer(entryName);
        return buffer ? buffer.toString("utf8") : null;
      },
      close() {
        closeSync(fd);
      },
    };
  } catch (error) {
    closeSync(fd);
    throw error;
  }
};

const normalizeZipSheetName = (value = "") =>
  String(value || "")
    .trim()
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "")
    .replace(/^\d+/, "");

const normalizeZipHeader = (value = "") =>
  String(value || "")
    .trim()
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "");

const extractWorkbookSheetTargets = (workbookXml, relsXml) => {
  const relationships = new Map();
  const relationshipRegex = /<Relationship\b([^>]*)\/?\s*>/gi;
  let relationshipMatch;

  while ((relationshipMatch = relationshipRegex.exec(relsXml || ""))) {
    const attributes = relationshipMatch[1] || "";
    const id = xmlAttribute(attributes, "Id");
    const target = xmlAttribute(attributes, "Target");
    if (!id || !target) continue;

    let normalizedTarget = target.replace(/\\/g, "/").replace(/^\/+/, "");
    while (normalizedTarget.startsWith("../")) {
      normalizedTarget = normalizedTarget.slice(3);
    }
    if (!normalizedTarget.startsWith("xl/")) {
      normalizedTarget = `xl/${normalizedTarget}`;
    }

    relationships.set(id, normalizedTarget);
  }

  const sheets = [];
  const sheetRegex = /<sheet\b([^>]*)\/?\s*>/gi;
  let sheetMatch;

  while ((sheetMatch = sheetRegex.exec(workbookXml || ""))) {
    const attributes = sheetMatch[1] || "";
    const name = xmlAttribute(attributes, "name");
    const relationshipId = xmlAttribute(attributes, "r:id");
    const target = relationships.get(relationshipId);
    if (!name || !target) continue;
    sheets.push({ name, target });
  }

  return sheets;
};

const classifyZipSheet = (name = "") => {
  const normalized = normalizeZipSheetName(name);

  if (
    normalized === "productmaster" ||
    normalized === "products" ||
    normalized === "cataloguemaster" ||
    normalized === "catalogmaster"
  ) {
    return "product_master";
  }

  if (
    normalized === "hampermaster" ||
    normalized === "curatedgiftmaster" ||
    normalized === "hampercuratedgiftmaster"
  ) {
    return "hamper_master";
  }

  if (
    normalized === "hamperrecipe" ||
    normalized === "hamperbom" ||
    normalized === "readymadecomposition" ||
    normalized === "hampercomposition"
  ) {
    return "hamper_recipe";
  }

  if (
    normalized === "hamporiumcontainersetup" ||
    normalized === "containersetup" ||
    normalized === "boxsetup"
  ) {
    return "container_setup";
  }

  if (normalized === "decorationmaster" || normalized === "decorations") {
    return "decoration_master";
  }

  return null;
};

const canonicalZipSheetName = (role, originalName = "") => {
  if (role === "product_master") {
    return /^\s*\d+[a-z]?\s+product\s+master\s*$/i.test(originalName)
      ? originalName
      : PRODUCT_MASTER_SHEET;
  }
  if (role === "hamper_master") return PROCUREMENT_HAMPER_MASTER_SHEET;
  if (role === "hamper_recipe") {
    return normalizeZipSheetName(originalName) === "hampercomposition"
      ? HAMPER_COMPOSITION_SHEET
      : PROCUREMENT_HAMPER_RECIPE_SHEET;
  }
  if (role === "container_setup") return CONTAINER_SETUP_SHEET;
  if (role === "decoration_master") return DECORATION_MASTER_SHEET;
  return originalName || "Sheet";
};

const parseSharedStringsXml = (xml = "") => {
  if (!xml) return [];
  const strings = [];
  const sharedRegex = /<si\b[^>]*>([\s\S]*?)<\/si>/gi;
  let match;

  while ((match = sharedRegex.exec(xml))) {
    const body = match[1] || "";
    const pieces = [];
    const textRegex = /<t\b[^>]*>([\s\S]*?)<\/t>/gi;
    let textMatch;
    while ((textMatch = textRegex.exec(body))) {
      pieces.push(xmlDecode(textMatch[1] || ""));
    }
    strings.push(pieces.join(""));
  }

  return strings;
};

const columnIndexFromCellReference = (reference = "") => {
  const letters = String(reference).match(/^([A-Z]+)/i)?.[1]?.toUpperCase();
  if (!letters) return -1;

  let index = 0;
  for (const character of letters) {
    index = index * 26 + (character.charCodeAt(0) - 64);
  }
  return index - 1;
};

const getCellXmlValue = (attributes, body, sharedStrings) => {
  const type = xmlAttribute(attributes, "t").toLowerCase();

  if (type === "inlinestr") {
    const pieces = [];
    const textRegex = /<t\b[^>]*>([\s\S]*?)<\/t>/gi;
    let textMatch;
    while ((textMatch = textRegex.exec(body || ""))) {
      pieces.push(xmlDecode(textMatch[1] || ""));
    }
    return pieces.join("");
  }

  const valueMatch = String(body || "").match(/<v\b[^>]*>([\s\S]*?)<\/v>/i);
  const rawValue = valueMatch ? xmlDecode(valueMatch[1] || "") : "";

  if (type === "s") {
    const sharedIndex = Number(rawValue);
    return Number.isInteger(sharedIndex) ? sharedStrings[sharedIndex] ?? "" : "";
  }

  if (type === "str") return rawValue;
  if (type === "b") return rawValue === "1";
  if (type === "e") return null;
  if (rawValue === "") return null;

  const numeric = Number(rawValue);
  return Number.isFinite(numeric) ? numeric : rawValue;
};

const zipValuePresent = (value) =>
  value !== null && value !== undefined && String(value).trim() !== "";

const rowHeaderIndex = (values, aliases) => {
  const normalizedAliases = new Set(aliases.map(normalizeZipHeader));
  return values.findIndex((value) => normalizedAliases.has(normalizeZipHeader(value)));
};

const detectHeaderForZipRole = (role, values = []) => {
  const has = (aliases) => rowHeaderIndex(values, aliases) >= 0;

  if (role === "product_master") {
    return (
      has(["Product SKU (10 digits numeric — immutable)", "Product SKU", "SKU"]) &&
      has(["Product Name", "Name"]) &&
      has(["Product Type", "Record Type", "Category"])
    );
  }

  if (role === "hamper_master") {
    return has(["Hamper Code", "Hamper SKU", "Product SKU"]) && has(["Hamper Name", "Product Name", "Name"]);
  }

  if (role === "hamper_recipe") {
    return (
      has(["Hamper Code", "Hamper SKU", "Parent Hamper SKU", "Parent Product SKU", "Ready Made Hamper SKU"]) &&
      has(["Product SKU", "Item SKU", "Child SKU", "Component SKU", "Container SKU"])
    );
  }

  if (role === "container_setup") {
    return has(["Container SKU", "Product SKU", "SKU"]) && has(["Container Name", "Product Name", "Name"]);
  }

  if (role === "decoration_master") {
    return has(["Decoration SKU", "Product SKU", "SKU"]) && has(["Decoration Name", "Product Name", "Name"]);
  }

  return false;
};

const getZipRoleKeyColumns = (role, headerValues = []) => {
  if (role === "product_master") {
    return [
      rowHeaderIndex(headerValues, ["Product SKU (10 digits numeric — immutable)", "Product SKU", "SKU"]),
      rowHeaderIndex(headerValues, ["Product Name", "Name"]),
    ];
  }
  if (role === "hamper_master") {
    return [
      rowHeaderIndex(headerValues, ["Hamper Code", "Hamper SKU", "Product SKU"]),
      rowHeaderIndex(headerValues, ["Hamper Name", "Product Name", "Name"]),
    ];
  }
  if (role === "hamper_recipe") {
    return [
      rowHeaderIndex(headerValues, ["Hamper Code", "Hamper SKU", "Parent Hamper SKU", "Parent Product SKU", "Ready Made Hamper SKU"]),
      rowHeaderIndex(headerValues, ["Product SKU", "Item SKU", "Child SKU", "Component SKU", "Container SKU"]),
    ];
  }
  if (role === "container_setup") {
    return [
      rowHeaderIndex(headerValues, ["Container SKU", "Product SKU", "SKU"]),
      rowHeaderIndex(headerValues, ["Container Name", "Product Name", "Name"]),
    ];
  }
  if (role === "decoration_master") {
    return [
      rowHeaderIndex(headerValues, ["Decoration SKU", "Product SKU", "SKU"]),
      rowHeaderIndex(headerValues, ["Decoration Name", "Product Name", "Name"]),
    ];
  }
  return [-1, -1];
};

const parseCatalogueSheetXml = (xml, sharedStrings, role, sheetName) => {
  const scannedRows = new Map();
  const keptDataRows = [];
  let headerRowNumber = null;
  let headerValues = null;
  let keyColumns = [-1, -1];
  let seenData = false;
  let emptyStreak = 0;
  let sequentialRowNumber = 0;

  const rowRegex = /<row\b([^>]*)>([\s\S]*?)<\/row>/gi;
  let rowMatch;

  while ((rowMatch = rowRegex.exec(xml || ""))) {
    sequentialRowNumber += 1;
    const rowAttributes = rowMatch[1] || "";
    const rowNumber = Number(xmlAttribute(rowAttributes, "r")) || sequentialRowNumber;
    if (rowNumber > PRODUCT_MASTER_ZIP_MAX_ROWS) break;

    const values = [];
    const cellRegex = /<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/gi;
    let cellMatch;
    let sequentialColumn = 0;

    while ((cellMatch = cellRegex.exec(rowMatch[2] || ""))) {
      const cellAttributes = cellMatch[1] || "";
      const reference = xmlAttribute(cellAttributes, "r");
      let columnIndex = columnIndexFromCellReference(reference);
      if (columnIndex < 0) columnIndex = sequentialColumn;
      sequentialColumn = columnIndex + 1;
      if (columnIndex >= PRODUCT_MASTER_ZIP_MAX_COLUMNS) continue;
      values[columnIndex] = getCellXmlValue(
        cellAttributes,
        cellMatch[2] || "",
        sharedStrings
      );
    }

    while (values.length > 0 && !zipValuePresent(values[values.length - 1])) {
      values.pop();
    }

    if (rowNumber <= 40) scannedRows.set(rowNumber, values);

    if (!headerRowNumber && rowNumber <= 40 && detectHeaderForZipRole(role, values)) {
      headerRowNumber = rowNumber;
      headerValues = values;
      keyColumns = getZipRoleKeyColumns(role, values);
      continue;
    }

    if (!headerRowNumber || rowNumber <= headerRowNumber) continue;

    const hasKeyValue = keyColumns.some(
      (index) => index >= 0 && zipValuePresent(values[index])
    );

    if (hasKeyValue) {
      keptDataRows.push({ rowNumber, values });
      seenData = true;
      emptyStreak = 0;
    } else if (seenData) {
      emptyStreak += 1;
      if (emptyStreak >= PRODUCT_MASTER_ZIP_EMPTY_STREAK_STOP) break;
    }
  }

  if (!headerRowNumber || !headerValues) {
    const error = new Error(
      `Catalogue sheet "${sheetName}" was found, but its expected header row could not be detected.`
    );
    error.statusCode = 400;
    throw error;
  }

  const compactRows = [];
  for (let rowNumber = 1; rowNumber <= headerRowNumber; rowNumber += 1) {
    compactRows.push(scannedRows.get(rowNumber) || []);
  }
  for (const entry of keptDataRows) compactRows.push(entry.values);

  return {
    headerRowNumber,
    dataRows: keptDataRows.length,
    dataRowNumbers: keptDataRows.map((item) => item.rowNumber),
    compactRows,
  };
};

// V22: Preserve embedded XLSX hyperlink TARGETS in the tiny compact workbook.
// Visible cell text (e.g. "510005") is not an image URL; the real Drive
// folder address lives in xl/worksheets/_rels/sheetN.xml.rels.
// This parser only consults selected worksheets and does not inflate
// unrelated operational sheets from the huge procurement workbook.
const applyCompactWorksheetImageHyperlinks = (archive, sheet, sheetXml, parsed) => {
  const imageColumn = (parsed.compactRows[parsed.headerRowNumber - 1] || [])
    .findIndex((value) => ["imageasseturl", "imageurl"].includes(normalizeZipHeader(value)));
  if (imageColumn < 0 || !parsed.dataRowNumbers?.length) return 0;

  const slash = sheet.target.lastIndexOf("/");
  const sheetDir = sheet.target.slice(0, slash + 1);
  const sheetName = sheet.target.slice(slash + 1);
  const relations = archive.readText(`${sheetDir}_rels/${sheetName}.rels`);
  if (!relations) return 0;

  const targets = new Map();
  for (const match of relations.matchAll(/<Relationship\b([^>]*?)\/?\s*>/gi)) {
    const attrs = match[1] || "";
    if (!/\/hyperlink/i.test(xmlAttribute(attrs, "Type"))) continue;
    if (xmlAttribute(attrs, "TargetMode").toLowerCase() !== "external") continue;
    const url = xmlAttribute(attrs, "Target");
    if (!/^https:\/\/drive\.google\.com\//i.test(url)) continue;
    targets.set(xmlAttribute(attrs, "Id"), url);
  }
  if (!targets.size) return 0;

  const rowPositions = new Map(parsed.dataRowNumbers.map((rowNo, index) => [
    rowNo, parsed.headerRowNumber + index,
  ]));
  let updated = 0;
  for (const match of (sheetXml || "").matchAll(/<hyperlink\b([^>]*?)\/?\s*>/gi)) {
    const attrs = match[1] || "";
    const reference = xmlAttribute(attrs, "ref").replace(/\$/g, "");
    const cell = reference.match(/^([A-Z]+)(\d+)$/i);
    const url = targets.get(xmlAttribute(attrs, "r:id"));
    if (!cell || !url) continue;
    if (columnIndexFromCellReference(reference) !== imageColumn) continue;
    const destinationRow = rowPositions.get(Number(cell[2]));
    if (destinationRow === undefined) continue;
    const values = parsed.compactRows[destinationRow];
    if (!values) continue;
    const existing = String(values[imageColumn] || "").trim();
    // Plain direct image URL or Drive link entered as visible text wins.
    if (/^https?:\/\//i.test(existing)) continue;
    values[imageColumn] = url;
    updated += 1;
  }
  return updated;
};

const compactProductMasterFromZip = async (sourcePath, filename = "") => {
  logProductMasterMemory("zip-v7:start", filename);
  console.info("[ProductMaster] parser=zip-direct-v9-data-mapping");

  const archive = openXlsxZip(sourcePath);

  try {
    const workbookXml = archive.readText("xl/workbook.xml");
    const relsXml = archive.readText("xl/_rels/workbook.xml.rels");

    if (!workbookXml || !relsXml) {
      const error = new Error("Unable to read XLSX workbook metadata.");
      error.statusCode = 400;
      throw error;
    }

    const sheetTargets = extractWorkbookSheetTargets(workbookXml, relsXml);
    const selected = [];
    const seenRoles = new Set();

    for (const sheet of sheetTargets) {
      const role = classifyZipSheet(sheet.name);
      if (!role || seenRoles.has(role)) continue;
      selected.push({ ...sheet, role });
      seenRoles.add(role);
    }

    if (!selected.some((sheet) => sheet.role === "product_master")) {
      const names = sheetTargets.map((sheet) => sheet.name).join(", ");
      const error = new Error(
        `Unable to locate a Product Master sheet. Workbook sheets: ${names || "none"}.`
      );
      error.statusCode = 400;
      throw error;
    }

    const sharedStringsXml = archive.readText("xl/sharedStrings.xml") || "";
    const sharedStrings = parseSharedStringsXml(sharedStringsXml);
    const compactWorkbook = XLSX.utils.book_new();
    const selectedSheetNames = [];
    let totalDataRows = 0;

    for (const sheet of selected) {
      const sheetXml = archive.readText(sheet.target);
      if (!sheetXml) continue;

      const parsed = parseCatalogueSheetXml(
        sheetXml,
        sharedStrings,
        sheet.role,
        sheet.name
      );

      if (sheet.role === "product_master" && parsed.dataRows === 0) {
        const error = new Error(
          `Product Master sheet "${sheet.name}" was found, but no usable Product Name/SKU rows were read.`
        );
        error.statusCode = 400;
        throw error;
      }

      const hyperlinkCount = applyCompactWorksheetImageHyperlinks(
        archive, sheet, sheetXml, parsed
      );
      if (hyperlinkCount) console.info(
        `[ProductMaster] preserved ${hyperlinkCount} Excel image hyperlink target(s) from ${sheet.name}`
      );

      const outputName = canonicalZipSheetName(sheet.role, sheet.name);
      const worksheet = XLSX.utils.aoa_to_sheet(parsed.compactRows, {
        cellDates: false,
      });
      XLSX.utils.book_append_sheet(compactWorkbook, worksheet, outputName);
      selectedSheetNames.push(outputName);
      totalDataRows += parsed.dataRows;

      console.info(
        `[ProductMaster] zip-v7:sheet | role=${sheet.role} source="${sheet.name}" ` +
          `output="${outputName}" headerRow=${parsed.headerRowNumber} dataRows=${parsed.dataRows}`
      );

      parsed.compactRows.length = 0;
    }

    sharedStrings.length = 0;

    const compactBuffer = XLSX.write(compactWorkbook, {
      type: "buffer",
      bookType: "xlsx",
      compression: true,
    });

    releaseWorkbookSheets(compactWorkbook);

    console.info(
      `[ProductMaster] zip-v7:compact-ready (${filename || "workbook"}) | ` +
        `dataRows=${totalDataRows} sheets=${selectedSheetNames.join(", ")} ` +
        `sizeKB=${Math.round(compactBuffer.length / 1024)}`
    );
    logProductMasterMemory("zip-v7:compact-ready", filename);

    return { compactBuffer, selectedSheetNames };
  } finally {
    archive.close();
  }
};

const analyzeUploadedProductMaster = async (
  file,
  { replaceMode = true } = {}
) => {
  const source = getProductMasterUploadSource(file);

  if (!source) {
    const error = new Error("Product Master Excel file is required");
    error.statusCode = 400;
    throw error;
  }

  const filename = file?.originalname || "";
  const extension = String(filename).toLowerCase();

  if (
    typeof source === "string" &&
    (extension.endsWith(".xlsx") || extension.endsWith(".xlsm"))
  ) {
    const { compactBuffer, selectedSheetNames } =
      await compactProductMasterFromZip(source, filename);

    const analysis = await analyzeProductMasterBuffer(compactBuffer, filename, {
      replaceMode,
      preselectedSheetNames: selectedSheetNames,
    });

    logProductMasterMemory("zip-v7:complete", filename);
    return analysis;
  }

  return analyzeProductMasterBuffer(source, filename, { replaceMode });
};

const readWorkbookSource = (source, options = {}) => {
  if (Buffer.isBuffer(source)) {
    return XLSX.read(source, {
      type: "buffer",
      ...options,
    });
  }

  if (typeof source === "string" && source) {
    // SheetJS ESM builds do not reliably expose readFile(). Reading the compact
    // temp workbook ourselves works in every supported Node ESM configuration.
    // This file is intentionally small because the streaming pass has already
    // removed all unrelated procurement/dashboard sheets.
    const fileBuffer = readFileSync(source);
    return XLSX.read(fileBuffer, {
      type: "buffer",
      ...options,
    });
  }

  const error = new Error("Product Master Excel file is required");
  error.statusCode = 400;
  throw error;
};

const getProductMasterUploadSource = (file) => {
  if (file?.path) return file.path;
  if (file?.buffer) return file.buffer;
  return null;
};

const normalizeMasterHeader = (value = "") =>
  String(value)
    .trim()
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "");

const normalizeMasterRow = (row = {}) => {
  const normalized = {};

  for (const [key, value] of Object.entries(row)) {
    normalized[normalizeMasterHeader(key)] = value;
  }

  return normalized;
};

const getMasterValue = (row, aliases = []) => {
  for (const alias of aliases) {
    const key = normalizeMasterHeader(alias);
    if (Object.prototype.hasOwnProperty.call(row, key)) return row[key];
  }

  return null;
};

const masterText = (row, aliases = []) => {
  const value = getMasterValue(row, aliases);
  if (value === undefined || value === null) return "";
  return String(value).trim();
};

const parseMasterNumericValue = (raw, { percent = false } = {}) => {
  if (raw === undefined || raw === null || raw === "") return null;

  if (typeof raw === "number") {
    if (!Number.isFinite(raw)) return NaN;
    if (percent && raw > 0 && raw <= 1) return raw * 100;
    return raw;
  }

  const source = String(raw).trim();
  if (!source) return null;

  const hasPercentSuffix = source.endsWith("%");
  const cleaned = source
    .replace(/[₹$£€]/g, "")
    .replace(/,/g, "")
    .replace(/%$/, "")
    .trim();

  if (!cleaned) return null;

  const value = Number(cleaned);
  if (!Number.isFinite(value)) return NaN;

  if (hasPercentSuffix) return value;
  if (percent && value > 0 && value <= 1) return value * 100;
  return value;
};

const masterNumber = (row, aliases, label, errors) => {
  const raw = getMasterValue(row, aliases);
  const value = parseMasterNumericValue(raw);

  if (value === null) return null;
  if (!Number.isFinite(value)) {
    errors.push(`${label} must be numeric`);
    return null;
  }

  return value;
};

// Product Master unit-aware capacity parser.
// Procurement Excel may hold "4kg" or "4.5 kg" in the otherwise numeric
// "Max Safe Load kg" column. Previously these rows became ERROR, so even a
// valid Target Sell Price was never saved to the container catalogue.
// Only apply this parser to the capacity field: prices/tax/other numeric fields
// must continue using their existing strict validation rules.
const parseMasterWeightKg = (raw) => {
  if (raw === undefined || raw === null || raw === "") return null;
  if (typeof raw === "number") return Number.isFinite(raw) && raw >= 0 ? raw : NaN;

  const source = String(raw).replace(/\u00a0/g, " ").trim();
  if (!source) return null;

  const matched = source.match(
    /^([+]?(?:\d+(?:\.\d*)?|\.\d+))\s*(kg|kgs|kilograms?|g|grams?)?$/i
  );
  if (!matched) return NaN;

  const value = Number(matched[1]);
  if (!Number.isFinite(value)) return NaN;

  const unit = String(matched[2] || "kg").toLowerCase();
  return unit === "g" || unit === "gram" || unit === "grams"
    ? value / 1000
    : value;
};

const masterWeightKg = (row, aliases, label, errors) => {
  const raw = getMasterValue(row, aliases);
  const value = parseMasterWeightKg(raw);
  if (value === null) return null;
  if (!Number.isFinite(value)) {
    errors.push(`${label} must be a numeric weight in kg (example: 4, 4kg or 4.5 kg)`);
    return null;
  }
  return value;
};

const masterPercentNumber = (row, aliases, label, errors) => {
  const raw = getMasterValue(row, aliases);

  if (typeof raw === "string") {
    const compact = raw.trim();
    const matches = compact.match(/-?\d+(?:\.\d+)?\s*%/g) || [];
    if (matches.length > 1 || /\d\s*%?\s*\/\s*\d/.test(compact)) {
      // Procurement masters sometimes keep a conditional tax note such as
      // "5%/18%". Do not guess a rate. Import the row with tax unset and
      // surface a warning at row level instead of rejecting the product.
      return null;
    }
  }

  const value = parseMasterNumericValue(raw, { percent: true });

  if (value === null) return null;
  if (!Number.isFinite(value)) {
    errors.push(`${label} must be a valid percentage`);
    return null;
  }

  return value;
};

const masterPriorityNumber = (row, aliases = ["Product Priority"]) => {
  const raw = getMasterValue(row, aliases);
  if (raw === undefined || raw === null || raw === "") return null;

  const numeric = parseMasterNumericValue(raw);
  if (Number.isFinite(numeric)) return numeric;

  const value = String(raw).trim().toLowerCase();
  const map = {
    p0: 0,
    p1: 10,
    p2: 20,
    p3: 30,
    critical: 0,
    urgent: 5,
    high: 10,
    medium: 50,
    normal: 50,
    low: 90,
  };

  return Object.prototype.hasOwnProperty.call(map, value) ? map[value] : null;
};

const masterHamperUse = (row) => {
  const raw = getMasterValue(row, [
    "Hamper Use",
    "Hamper Use?",
    "Use in Hamper",
    "Custom Hamper Eligible?",
  ]);

  if (raw === undefined || raw === null || raw === "") return false;
  if (typeof raw === "boolean") return raw;
  if (typeof raw === "number") return raw !== 0;

  const value = String(raw).trim().toLowerCase();
  if (!value) return false;

  if ([
    "no",
    "n",
    "false",
    "0",
    "inactive",
    "none",
    "n/a",
    "na",
    "not applicable",
    "not for hamper",
    "do not use",
  ].includes(value)) {
    return false;
  }

  // The live procurement workbook stores usage labels such as
  // "All Purpose", "Festive Gifting" and "Kids Hamper" instead of Yes/No.
  // Any non-negative, non-empty usage label therefore means the item is
  // hamper-eligible; customer visibility is still gated by price + dimensions.
  return true;
};

const masterBoolean = (row, aliases, fallback = false) => {
  const raw = getMasterValue(row, aliases);
  if (raw === undefined || raw === null || raw === "") return fallback;

  if (typeof raw === "boolean") return raw;
  if (typeof raw === "number") return raw !== 0;

  const value = String(raw).trim().toLowerCase();

  if (["yes", "y", "true", "1", "active"].includes(value)) return true;
  if (["no", "n", "false", "0", "inactive"].includes(value)) return false;

  return fallback;
};

const masterDate = (row, aliases, label, errors) => {
  const raw = getMasterValue(row, aliases);
  if (raw === undefined || raw === null || raw === "") return null;

  if (raw instanceof Date && !Number.isNaN(raw.getTime())) return raw;

  if (typeof raw === "number") {
    const parsed = XLSX.SSF.parse_date_code(raw);
    if (parsed) {
      return new Date(
        Date.UTC(
          parsed.y,
          parsed.m - 1,
          parsed.d,
          parsed.H || 0,
          parsed.M || 0,
          Math.floor(parsed.S || 0)
        )
      );
    }
  }

  const date = new Date(raw);
  if (Number.isNaN(date.getTime())) {
    errors.push(`${label} is not a valid date`);
    return null;
  }

  return date;
};

const masterStatusActive = (row) => {
  const status = masterText(row, ["Status"]).toLowerCase();

  if (!status) return true;
  if (["inactive", "archived", "disabled", "discontinued", "draft", "hidden", "paused"].includes(status)) {
    return false;
  }

  return true;
};

const isMasterContainerRow = (row) => {
  const productType = masterText(row, ["Product Type"]).toLowerCase();
  const recordType = masterText(row, ["Record Type"]).toLowerCase();
  const category = masterText(row, ["Category"]).toLowerCase();
  const normalizedCategory = normalizeMasterHeader(category);

  // Native catalogue files use Product Type = "Container".
  if (productType.includes("container") || recordType.includes("container")) {
    return true;
  }

  // V22: Product Master rows 187/188 (8002024001 / 8002024002) are
  // physically gift BOXES, even though their Category is the personalized
  // product library. Product Type is more specific than merchandising category.
  // Do not use the name keyword alone: a non-box gift could mention "box".
  const normalizedType = normalizeMasterHeader(productType);
  if (["box", "boxes", "giftbox", "giftboxes", "rigidbox", "rigidboxes",
    "packagingbox", "packagingboxes"].includes(normalizedType)) {
    return true;
  }

  // The live procurement workbook classifies real boxes/baskets/trays under
  // Category = "Packaging Containers" while Product Type contains values
  // such as "Decorative baskets", "Hinged wooden boxes",
  // "Medium rigid boxes" and "MDF trays". Treat that category as the
  // authoritative container signal instead of importing those rows as generic
  // packaging components.
  if (
    normalizedCategory === "packagingcontainers" ||
    normalizedCategory.startsWith("packagingcontainer")
  ) {
    return true;
  }

  return false;
};

const getMasterRecordType = (row) => {
  const productType = masterText(row, ["Product Type"]).toLowerCase();
  const recordType = masterText(row, ["Record Type"]).toLowerCase();

  if (isMasterContainerRow(row)) {
    return "container";
  }

  if (
    (productType.includes("hamper") || recordType.includes("hamper")) &&
    !productType.includes("packaging material")
  ) {
    return "ready_made_hamper";
  }

  return "component";
};

const getMasterBuilderSection = (row) =>
  masterText(row, ["Builder Section", "Builder Area", "Custom Builder Section"])
    .trim()
    .toLowerCase();

// V19: Procurement workbook has reliable Category Code even when the optional
// Builder Section / Decoration Master columns are absent. Use these source
// taxonomy codes, not fragile product-name keyword guesses.
const getProcurementBuilderRole = (row) => {
  const code = masterText(row, ["Category Code (3 digits)", "Category Code"])
    .trim().replace(/\.0+$/, "");
  if (code === "102" || code === "103") return "decoration";
  if (code === "101") return "packaging";
  return null;
};

const isMasterDecorationRow = (row, decorationMasterEntry = null) => {
  const builderSection = getMasterBuilderSection(row);
  const decorationType =
    masterText(row, ["Decoration Type"]) || decorationMasterEntry?.decorationType || "";
  const selectable = masterBoolean(
    row,
    ["Decoration Selectable?", "Decoration Selectable"],
    decorationMasterEntry?.customerSelectable === true
  );

  return (
    getProcurementBuilderRole(row) === "decoration" ||
    builderSection.includes("decoration") ||
    Boolean(decorationType) ||
    selectable === true
  );
};

const getMasterComponentType = (row, { decoration = false } = {}) => {
  if (decoration) return "non_food";
  if (getProcurementBuilderRole(row) === "packaging") return "packaging";

  const productType = masterText(row, ["Product Type"]).toLowerCase();
  const category = masterText(row, ["Category"]).toLowerCase();
  const taxonomy = masterText(row, ["Taxonomy Base ID (Auto)", "Taxonomy Base ID"])
    .toLowerCase();

  if (
    productType.includes("packaging material") ||
    category === "packaging" ||
    category.includes("internal hamper construction") ||
    category.includes("packaging container")
  ) {
    return "packaging";
  }

  const foodText = `${category} ${productType}`;
  const foodHints = [
    "food",
    "chocolate",
    "confection",
    "cookie",
    "biscuit",
    "bakery",
    "coffee",
    "tea",
    "snack",
    "dry fruit",
    "nut",
    "gourmet",
    "beverage",
  ];

  if (
    category === "food" ||
    taxonomy.startsWith("food-") ||
    foodHints.some((hint) => foodText.includes(hint))
  ) {
    return "food";
  }

  return "non_food";
};

const setMasterField = (target, key, value) => {
  if (value === undefined || value === null || value === "") return;
  target[key] = value;
};

const normalizeCatalogImageUrl = (value) => {
  const raw = String(value || "").trim();
  if (!raw) return { url: "", warning: "" };

  try {
    const parsed = new URL(raw);
    if (!["http:", "https:"].includes(parsed.protocol)) {
      return {
        url: "",
        warning: "Image / Asset URL is not an http(s) URL, so it was skipped",
      };
    }

    const hostname = parsed.hostname.toLowerCase();
    const pathname = parsed.pathname.toLowerCase();

    if (
      hostname === "drive.google.com" &&
      (pathname.includes("/drive/folders/") || pathname.includes("/folders/"))
    ) {
      return {
        url: "",
        warning:
          "Image / Asset URL is a Google Drive folder link, not a direct image URL; image was skipped",
      };
    }

    return { url: raw, warning: "" };
  } catch {
    return {
      url: "",
      warning: "Image / Asset URL is invalid, so it was skipped",
    };
  }
};

const validPositiveDimensions = (dimensions) =>
  dimensions &&
  [dimensions.length, dimensions.width, dimensions.height].every(
    (value) => Number.isFinite(Number(value)) && Number(value) > 0
  );

const validPositiveWeight = (weight) =>
  weight &&
  Number.isFinite(Number(weight.value)) &&
  Number(weight.value) > 0 &&
  WEIGHT_UNITS.includes(weight.unit || "kg");

const normalizeExternalSkuKey = (value) => String(value || "").trim();
const normalizeCodeKey = (value) => String(value || "").trim().toUpperCase();

const buildMasterCommonFields = (row, errors) => {
  const externalSku = masterText(row, [
    "Product SKU (10 digits numeric — immutable)",
    "Product SKU",
    "SKU",
  ]);

  const name = masterText(row, ["Product Name", "Name"]);
  const brand = masterText(row, ["Brand Name", "Brand"]);
  const skuBarcode = masterText(row, [
    "SKU Barcode",
    "Barcode / GTIN (Editable)",
    "Barcode / GTIN",
  ]);
  const sizePack = masterText(row, [
    "Size/Pack",
    "Size Option (Required — immutable after SKU)",
    "Size Option",
  ]);
  const uom = masterText(row, ["UOM"]);
  const sourceProductType = masterText(row, ["Product Type"]);
  const taxonomyBaseId = masterText(row, [
    "Taxonomy Base ID (Auto)",
    "Taxonomy Base ID",
  ]);
  const categoryCode = masterText(row, [
    "Category Code (3 digits)",
    "Category Code",
  ]);
  const category = masterText(row, ["Category"]);
  const subcategory = masterText(row, ["Subcategory"]);
  const segment = masterText(row, ["Segment"]);
  const hsnSac = masterText(row, ["HSN/SAC"]);
  const imageUrl = masterText(row, ["Image / Asset URL", "Image URL"]);
  const internalNotes = masterText(row, ["Notes"]);
  const personalizationMethod = masterText(row, ["Personalization Method"]);
  const dietary = masterText(row, ["Dietary"]);

  const piecesPerUom = masterNumber(
    row,
    ["Pieces per UOM", "Case Pack Qty"],
    "Pieces per UOM / Case Pack Qty",
    errors
  );
  const productPriority = masterPriorityNumber(row, ["Product Priority"]);
  const mrp = masterNumber(row, ["Retail MRP"], "Retail MRP", errors);
  // The ONLY source of website sellingPrice is Excel Target Sell Price (AE).
  // Never take Retail MRP (AD) as a substitute. When Target Sell Price is
  // empty, omit sellingPrice from the update so an existing admin price stays.
  const sellingPrice = masterNumber(row, ["Target Sell Price"], "Target Sell Price", errors);
  const latestUnitCost = masterNumber(row, ["Latest Unit Cost"], "Latest Unit Cost", errors);
  const actualLandedCost = masterNumber(row, ["Actual Landed Cost"], "Actual Landed Cost", errors);
  const taxPercent = masterPercentNumber(row, ["Tax %"], "Tax %", errors);
  const minGrossMarginPercent = masterPercentNumber(
    row,
    ["Min Gross Margin %"],
    "Min Gross Margin %",
    errors
  );
  const moqQty = masterNumber(row, ["MOQ Qty"], "MOQ Qty", errors);
  const leadTimeDays = masterNumber(row, ["Lead Time Days"], "Lead Time Days", errors);
  const shelfLifeDays = masterNumber(row, ["Shelf Life Days"], "Shelf Life Days", errors);
  const expiryDate = masterDate(
    row,
    [
      "Expiry Date",
      "Best Before Date",
      "Batch Expiry Date",
      "Product Expiry Date",
      "Expiry / Best Before Date",
      "Use By Date",
    ],
    "Expiry Date",
    errors
  );
  const width = masterNumber(row, ["Product Width cm"], "Product Width cm", errors);
  const length = masterNumber(row, ["Product Length cm"], "Product Length cm", errors);
  const height = masterNumber(row, ["Product Height cm"], "Product Height cm", errors);
  const weightKg = masterNumber(
    row,
    ["Net Product Weight kg"],
    "Net Product Weight kg",
    errors
  );

  const sourceUpdatedAt = masterDate(
    row,
    ["Last Updated Date & Time", "Last Updated Date", "Updated At"],
    "Last Updated Date & Time",
    errors
  );

  return {
    externalSku,
    name,
    brand,
    skuBarcode,
    sizePack,
    uom,
    sourceProductType,
    taxonomyBaseId,
    categoryCode,
    category,
    subcategory,
    segment,
    hsnSac,
    imageUrl,
    internalNotes,
    personalizationMethod,
    dietary,
    piecesPerUom,
    productPriority,
    mrp,
    sellingPrice,
    latestUnitCost,
    actualLandedCost,
    taxPercent,
    minGrossMarginPercent,
    moqQty,
    leadTimeDays,
    shelfLifeDays,
    expiryDate,
    dimensions:
      [length, width, height].some((value) => value !== null)
        ? { length, width, height, unit: "cm" }
        : null,
    weight: weightKg === null ? null : { value: weightKg, unit: "kg" },
    fragile: masterBoolean(row, ["Fragile?"], false),
    expiryTracked: masterBoolean(row, ["Expiry Tracked?"], false),
    personalizable: masterBoolean(row, ["Personalizable?"], false),
    hamperUse: masterHamperUse(row),
    channels: {
      corporate: masterBoolean(row, ["Corporate?"], false),
      wedding: masterBoolean(row, ["Wedding?"], false),
      diwali: masterBoolean(row, ["Diwali?"], false),
      hamperOne: masterBoolean(row, ["HAMPER ONE?", "Hamper One?"], false),
    },
    isActive: masterStatusActive(row),
    sourceUpdatedAt,
  };
};

const normalizeWorkbookSheetName = (value = "") => {
  const source = String(value || "").trim();
  const withoutNumericPrefix = source.replace(/^\s*\d+[a-z]?\s*[-_.:]?\s*/i, "");
  return normalizeMasterHeader(withoutNumericPrefix);
};

const findWorkbookSheet = (workbook, names = []) => {
  const candidates = names
    .map((name) => ({
      exact: normalizeMasterHeader(name),
      flexible: normalizeWorkbookSheetName(name),
    }))
    .filter((item) => item.exact || item.flexible);

  return workbook.SheetNames.find((sheetName) => {
    const exact = normalizeMasterHeader(sheetName);
    const flexible = normalizeWorkbookSheetName(sheetName);

    return candidates.some(
      (candidate) =>
        exact === candidate.exact ||
        flexible === candidate.flexible ||
        flexible === candidate.exact
    );
  });
};

const rowContainsHeaderAlias = (values = [], aliases = []) => {
  const normalizedValues = new Set(
    values
      .map((value) => normalizeMasterHeader(value))
      .filter(Boolean)
  );

  return aliases.some((alias) => normalizedValues.has(normalizeMasterHeader(alias)));
};

const getWorksheetCellScalar = (worksheet, rowIndex, columnIndex) => {
  if (!worksheet) return null;

  const address = XLSX.utils.encode_cell({ r: rowIndex, c: columnIndex });
  const cell = worksheet[address];
  if (!cell) return null;

  // Prefer the raw cached value. This works for normal text/number cells and
  // for formula cells when the downloaded XLSX contains a cached result.
  if (cell.v !== undefined && cell.v !== null) return cell.v;

  // Defensive fallbacks for unusual workbook exports.
  if (cell.w !== undefined && cell.w !== null) return cell.w;
  if (cell.h !== undefined && cell.h !== null) return cell.h;

  return null;
};

const getWorksheetDecodedRange = (worksheet) => {
  const ref = worksheet?.["!ref"];
  if (!ref) return null;

  try {
    return XLSX.utils.decode_range(ref);
  } catch {
    return null;
  }
};

const detectWorksheetHeaderRow = (
  worksheet,
  requiredAliasGroups = [],
  { maxScanRows = 30 } = {}
) => {
  if (!worksheet) return null;

  const range = getWorksheetDecodedRange(worksheet);
  if (!range) return null;

  const firstRow = Math.max(0, range.s.r);
  const lastRow = Math.min(
    range.e.r,
    firstRow + Math.max(1, Number(maxScanRows) || 30) - 1
  );

  for (let rowIndex = firstRow; rowIndex <= lastRow; rowIndex += 1) {
    const normalizedValues = new Set();

    for (let columnIndex = range.s.c; columnIndex <= range.e.c; columnIndex += 1) {
      const value = getWorksheetCellScalar(worksheet, rowIndex, columnIndex);
      const normalized = normalizeMasterHeader(value);
      if (normalized) normalizedValues.add(normalized);
    }

    const matches = requiredAliasGroups.every((aliases) =>
      aliases.some((alias) =>
        normalizedValues.has(normalizeMasterHeader(alias))
      )
    );

    if (matches) return rowIndex + 1; // Excel row number (1-based)
  }

  return null;
};

const normalizeMasterRowInPlace = (row = {}) => {
  const entries = Object.entries(row);

  for (const [key] of entries) delete row[key];
  for (const [key, value] of entries) {
    row[normalizeMasterHeader(key)] = value;
  }

  return row;
};

/*
 * IMPORTANT: do not use XLSX.utils.sheet_to_json() for the live procurement
 * workbook. On the Render/SheetJS combination used by HAMPORIUM, header
 * detection could succeed while sheet_to_json returned zero usable rows for
 * the same sheet. Reading sparse worksheet cells directly is deterministic and
 * preserves the cached values already present in the downloaded .xlsx.
 */
const readWorksheetObjects = (
  worksheet,
  { requiredAliasGroups = [], maxScanRows = 30, includeRow = null } = {}
) => {
  if (!worksheet) return { headerRow: null, rows: [] };

  const headerRow = detectWorksheetHeaderRow(worksheet, requiredAliasGroups, {
    maxScanRows,
  });

  if (!headerRow) {
    return { headerRow: null, rows: [] };
  }

  const range = getWorksheetDecodedRange(worksheet);
  if (!range) return { headerRow, rows: [] };

  const headerRowIndex = headerRow - 1;
  const headers = new Map();

  for (let columnIndex = range.s.c; columnIndex <= range.e.c; columnIndex += 1) {
    const rawHeader = getWorksheetCellScalar(
      worksheet,
      headerRowIndex,
      columnIndex
    );
    const normalizedHeader = normalizeMasterHeader(rawHeader);
    if (normalizedHeader && !headers.has(columnIndex)) {
      headers.set(columnIndex, normalizedHeader);
    }
  }

  const rows = [];
  const lastRowIndex = Math.min(
    range.e.r,
    headerRowIndex + PRODUCT_MASTER_MAX_PARSED_ROWS
  );

  for (
    let rowIndex = headerRowIndex + 1;
    rowIndex <= lastRowIndex;
    rowIndex += 1
  ) {
    const row = {};
    let hasAnyValue = false;

    for (const [columnIndex, normalizedHeader] of headers.entries()) {
      const value = getWorksheetCellScalar(worksheet, rowIndex, columnIndex);

      if (value !== undefined && value !== null && String(value).trim() !== "") {
        hasAnyValue = true;
      }

      row[normalizedHeader] = value;
    }

    if (!hasAnyValue) continue;

    const rowNumber = rowIndex + 1;
    if (includeRow && !includeRow(row, rowNumber)) continue;
    rows.push({ row, rowNumber });
  }

  return { headerRow, rows };
};

const detectProductMasterWorkbookProfile = (workbook) => {
  const productSheetName = findWorkbookSheet(workbook, PRODUCT_MASTER_SHEET_ALIASES);
  const hamperMasterSheetName = findWorkbookSheet(workbook, HAMPER_MASTER_SHEET_ALIASES);
  const hamperRecipeSheetName = findWorkbookSheet(workbook, HAMPER_RECIPE_SHEET_ALIASES);
  const procurementRecipeSheetName = findWorkbookSheet(workbook, [
    PROCUREMENT_HAMPER_RECIPE_SHEET,
    "10 Hamper Recipe",
  ]);
  const numberedProductSheet = workbook.SheetNames.some((name) =>
    /^\s*\d+[a-z]?\s+product\s+master\s*$/i.test(String(name || ""))
  );

  const procurementMaster = Boolean(
    numberedProductSheet || hamperMasterSheetName || procurementRecipeSheetName
  );

  return {
    key: procurementMaster ? "procurement_master" : "catalog_import",
    label: procurementMaster
      ? "HAMPORIUM Procurement / Inventory Master"
      : "HAMPORIUM Catalogue Import",
    productSheetName,
    hamperMasterSheetName,
    hamperRecipeSheetName,
    allowPartialImport: procurementMaster,
    strictBuilderEligibility: !procurementMaster,
    requireReadyMadeContainer: !procurementMaster,
  };
};

const getProductMasterSheetSelection = (sheetCatalog, workbookProfile) => {
  const selected = new Set();
  const add = (sheetName) => {
    if (sheetName) selected.add(sheetName);
  };

  add(workbookProfile.productSheetName);
  add(workbookProfile.hamperMasterSheetName);
  add(workbookProfile.hamperRecipeSheetName);
  add(
    findWorkbookSheet(sheetCatalog, [
      CONTAINER_SETUP_SHEET,
      "Container Setup",
      "Box Setup",
    ])
  );
  add(
    findWorkbookSheet(sheetCatalog, [
      DECORATION_MASTER_SHEET,
      "Decorations",
    ])
  );

  return [...selected];
};

const releaseWorkbookSheets = (workbook) => {
  if (!workbook) return;

  if (workbook.Sheets) {
    for (const key of Object.keys(workbook.Sheets)) {
      delete workbook.Sheets[key];
    }
  }

  if (Array.isArray(workbook.SheetNames)) {
    workbook.SheetNames.length = 0;
  }
};

const parseContainerSetupSheet = (workbook) => {
  const sheetName = findWorkbookSheet(workbook, [
    CONTAINER_SETUP_SHEET,
    "Container Setup",
    "Box Setup",
  ]);

  if (!sheetName) {
    return { sheetName: null, bySku: new Map(), errors: [] };
  }

  const extracted = readWorksheetObjects(workbook.Sheets[sheetName], {
    requiredAliasGroups: [
      ["Container SKU", "Product SKU", "SKU"],
      ["Container Name", "Product Name", "Name"],
    ],
    includeRow: (row) =>
      Boolean(masterText(row, ["Container SKU", "Product SKU", "SKU"])) ||
      Boolean(masterText(row, ["Container Name", "Product Name", "Name"])),
  });

  const bySku = new Map();
  const errors = [];

  extracted.rows.forEach(({ row, rowNumber }) => {
    const sku = masterText(row, ["Container SKU", "Product SKU", "SKU"]);
    if (!sku) return;

    if (bySku.has(sku)) {
      errors.push(`${CONTAINER_SETUP_SHEET} row ${rowNumber} duplicates Container SKU ${sku}`);
      return;
    }

    const localErrors = [];
    const outerLength = masterNumber(row, ["Outer L cm", "Outer Length cm"], "Outer L cm", localErrors);
    const outerWidth = masterNumber(row, ["Outer W cm", "Outer Width cm"], "Outer W cm", localErrors);
    const outerHeight = masterNumber(row, ["Outer H cm", "Outer Height cm"], "Outer H cm", localErrors);
    const innerLength = masterNumber(row, ["True Inner L cm", "Inner L cm", "Inner Length cm"], "True Inner L cm", localErrors);
    const innerWidth = masterNumber(row, ["True Inner W cm", "Inner W cm", "Inner Width cm"], "True Inner W cm", localErrors);
    const innerHeight = masterNumber(row, ["True Inner H cm", "Inner H cm", "Inner Height cm"], "True Inner H cm", localErrors);
    const maxContentWeight = masterNumber(row, ["Max Content Weight kg", "Max Safe Load kg"], "Max Content Weight kg", localErrors);
    const usableVolumePercent = masterNumber(row, ["Usable Volume %"], "Usable Volume %", localErrors);
    const maxItems = masterNumber(row, ["Max Items", "Max Content Items"], "Max Items", localErrors);
    const defaultCourierDays = masterNumber(row, ["Default Courier Days", "Courier Days"], "Default Courier Days", localErrors);

    if (localErrors.length) {
      errors.push(...localErrors.map((message) => `${CONTAINER_SETUP_SHEET} row ${rowNumber}: ${message}`));
    }

    bySku.set(sku, {
      outerDimensions:
        [outerLength, outerWidth, outerHeight].every((value) => Number(value) > 0)
          ? { length: outerLength, width: outerWidth, height: outerHeight, unit: "cm" }
          : null,
      innerDimensions:
        [innerLength, innerWidth, innerHeight].every((value) => Number(value) > 0)
          ? { length: innerLength, width: innerWidth, height: innerHeight, unit: "cm" }
          : null,
      maxContentWeight:
        Number(maxContentWeight) > 0
          ? { value: maxContentWeight, unit: "kg" }
          : null,
      usableVolumePercent,
      maxItems,
      defaultCourierDays,
      customerSelectable: masterBoolean(
        row,
        ["Custom Builder Selectable", "Customer Selectable?", "Selectable?"],
        true
      ),
    });
  });

  return { sheetName, bySku, errors };
};

const parseDecorationMasterSheet = (workbook) => {
  const sheetName = findWorkbookSheet(workbook, [
    DECORATION_MASTER_SHEET,
    "Decorations",
  ]);

  if (!sheetName) {
    return { sheetName: null, bySku: new Map(), errors: [] };
  }

  const extracted = readWorksheetObjects(workbook.Sheets[sheetName], {
    requiredAliasGroups: [
      ["Decoration SKU", "Product SKU", "SKU"],
      ["Decoration Name", "Product Name", "Name"],
    ],
    includeRow: (row) =>
      Boolean(masterText(row, ["Decoration SKU", "Product SKU", "SKU"])) ||
      Boolean(masterText(row, ["Decoration Name", "Product Name", "Name"])),
  });

  const bySku = new Map();
  const errors = [];

  extracted.rows.forEach(({ row, rowNumber }) => {
    const sku = masterText(row, ["Decoration SKU", "Product SKU", "SKU"]);
    if (!sku) return;

    if (bySku.has(sku)) {
      errors.push(`${DECORATION_MASTER_SHEET} row ${rowNumber} duplicates Decoration SKU ${sku}`);
      return;
    }

    const priceErrors = [];
    const sellingPrice = masterNumber(row, ["Target Sell Price"], "Target Sell Price", priceErrors);
    const taxPercent = masterPercentNumber(row, ["Tax %"], "Tax %", priceErrors);
    if (priceErrors.length) {
      errors.push(...priceErrors.map((message) => `${DECORATION_MASTER_SHEET} row ${rowNumber}: ${message}`));
    }

    bySku.set(sku, {
      decorationType: masterText(row, ["Decoration Type"]),
      customerSelectable: masterBoolean(row, ["Customer Selectable?"], true),
      countsTowardBoxCapacity: masterBoolean(row, ["Counts Toward Box Capacity?"], false),
      sellingPrice,
      taxPercent,
      personalizable: masterBoolean(row, ["Personalizable?"], false),
      imageUrl: masterText(row, ["Image / Asset URL", "Image URL"]),
    });
  });

  return { sheetName, bySku, errors };
};

const buildComponentMasterPayload = (
  row,
  { decorationMasterEntry = null, strictBuilderEligibility = true } = {}
) => {
  const errors = [];
  const review = [];
  const warnings = [];
  const common = buildMasterCommonFields(row, errors);
  const rawTaxText = masterText(row, ["Tax %"]);
  if (/\d\s*%?\s*\/\s*\d/.test(rawTaxText)) {
    warnings.push(
      `Tax rate "${rawTaxText}" is conditional/ambiguous, so tax was left unset for review`
    );
  }
  const decoration = isMasterDecorationRow(row, decorationMasterEntry);
  const type = getMasterComponentType(row, { decoration });
  const hamperRole = decoration ? "decoration" : "content";
  if (getProcurementBuilderRole(row) === "decoration") {
    warnings.push("Recognized as a decorative finish from procurement Category Code 102/103");
  }
  if (getProcurementBuilderRole(row) === "packaging") {
    warnings.push("Recognized as internal packing material from procurement Category Code 101");
  }

  if (!common.externalSku) errors.push("Product SKU is required");
  if (!common.name) errors.push("Product Name is required");

  const payload = {
    name: common.name,
    code: common.externalSku.toUpperCase(),
    type,
    hamperRole,
    source: {
      type: "product_master",
      externalSku: common.externalSku,
    },
  };

  setMasterField(payload, "brand", common.brand);
  setMasterField(payload, "skuBarcode", common.skuBarcode);
  setMasterField(payload, "sizePack", common.sizePack);
  setMasterField(payload, "uom", common.uom);
  setMasterField(payload, "sourceProductType", common.sourceProductType);
  setMasterField(payload, "taxonomyBaseId", common.taxonomyBaseId);
  setMasterField(payload, "categoryCode", common.categoryCode);
  setMasterField(payload, "category", common.category);
  setMasterField(payload, "subcategory", common.subcategory);
  setMasterField(payload, "segment", common.segment);
  setMasterField(payload, "hsnSac", common.hsnSac);
  setMasterField(payload, "internalNotes", common.internalNotes);
  setMasterField(payload, "personalizationMethod", common.personalizationMethod);
  setMasterField(payload, "dietary", common.dietary);

  setMasterField(payload, "piecesPerUom", common.piecesPerUom);
  setMasterField(payload, "productPriority", common.productPriority);
  setMasterField(payload, "mrp", common.mrp);
  setMasterField(
    payload,
    "sellingPrice",
    decorationMasterEntry?.sellingPrice ?? common.sellingPrice
  );
  setMasterField(payload, "latestUnitCost", common.latestUnitCost);
  setMasterField(payload, "actualLandedCost", common.actualLandedCost);
  setMasterField(
    payload,
    "taxPercent",
    decorationMasterEntry?.taxPercent ?? common.taxPercent
  );
  payload.taxEnabled =
    payload.taxPercent !== null &&
    payload.taxPercent !== undefined &&
    Number(payload.taxPercent) > 0;
  payload.pricingSource = "product_master";
  payload.taxSource = "product_master";
  setMasterField(payload, "minGrossMarginPercent", common.minGrossMarginPercent);
  setMasterField(payload, "moqQty", common.moqQty);
  setMasterField(payload, "leadTimeDays", common.leadTimeDays);
  setMasterField(payload, "shelfLifeDays", common.shelfLifeDays);

  if (type !== "packaging" && !decoration && common.expiryDate) {
    payload.expiryDate = common.expiryDate;
  }

  if (common.dimensions) payload.dimensions = common.dimensions;
  if (common.weight) payload.weight = common.weight;

  payload.fragile = common.fragile;
  payload.expiryTracked = decoration ? false : common.expiryTracked;
  payload.personalizable =
    decorationMasterEntry?.personalizable ?? common.personalizable;
  payload.hamperUse = common.hamperUse;
  payload.channels = common.channels;
  payload.isActive = common.isActive;

  let requestedCustomerSelectable = false;

  if (decoration) {
    payload.decorationType =
      masterText(row, ["Decoration Type"]) ||
      decorationMasterEntry?.decorationType ||
      "Decoration";
    payload.countsTowardBoxCapacity = false;
    requestedCustomerSelectable =
      common.isActive &&
      masterBoolean(
        row,
        ["Decoration Selectable?", "Decoration Selectable"],
        decorationMasterEntry?.customerSelectable !== false
      );
  } else {
    payload.decorationType = "";
    payload.countsTowardBoxCapacity = masterBoolean(
      row,
      ["Counts Toward Box Capacity?"],
      type !== "packaging"
    );
    requestedCustomerSelectable =
      type !== "packaging" && common.hamperUse && common.isActive;
  }

  const imageCandidate = decorationMasterEntry?.imageUrl || common.imageUrl;
  const normalizedImage = normalizeCatalogImageUrl(imageCandidate);
  if (normalizedImage.warning) warnings.push(normalizedImage.warning);
  if (normalizedImage.url) {
    payload.images = [
      { url: normalizedImage.url, publicId: "", alt: common.name },
    ];
  }

  if (common.sourceUpdatedAt) payload.source.sourceUpdatedAt = common.sourceUpdatedAt;

  const builderMissing = [];
  if (requestedCustomerSelectable && hamperRole !== "decoration") {
    if (!validPositiveDimensions(common.dimensions)) {
      builderMissing.push("Product Length, Width and Height");
    }

    if (
      !common.weight ||
      !Number.isFinite(Number(common.weight.value)) ||
      Number(common.weight.value) <= 0
    ) {
      builderMissing.push("Net Product Weight");
    }

    if (!hasPrice(payload.sellingPrice)) {
      builderMissing.push("Target Sell Price");
    }
  }

  if (requestedCustomerSelectable && hamperRole === "decoration" && !hasPrice(payload.sellingPrice)) {
    builderMissing.push("Target Sell Price");
  }

  if (strictBuilderEligibility && builderMissing.length > 0) {
    review.push(
      `Customer-selectable item requires ${builderMissing.join(", ")}`
    );
    payload.customerSelectable = requestedCustomerSelectable;
  } else {
    payload.customerSelectable =
      requestedCustomerSelectable && builderMissing.length === 0;

    if (!strictBuilderEligibility && requestedCustomerSelectable && builderMissing.length > 0) {
      warnings.push(
        `Imported safely but hidden from the custom builder until ${builderMissing.join(", ")} ${
          builderMissing.length === 1 ? "is" : "are"
        } supplied`
      );
    }
  }

  return { payload, errors, review, warnings };
};

const buildContainerMasterPayload = (row, setupEntry = null, { allowIncompleteCapacity = false } = {}) => {
  const errors = [];
  const review = [];
  const warnings = [];
  const common = buildMasterCommonFields(row, errors);

  const maxSafeLoadKg = masterWeightKg(
    row,
    ["Max Safe Load kg (Container Only)", "Max Content Weight kg (Container Only)"],
    "Max Safe Load kg",
    errors
  );

  const innerWidth = masterNumber(
    row,
    ["True Inner Width cm (Container Only)", "True Inner W cm", "Inner Width cm"],
    "True Inner Width cm",
    errors
  );
  const innerLength = masterNumber(
    row,
    ["True Inner Length cm (Container Only)", "True Inner L cm", "Inner Length cm"],
    "True Inner Length cm",
    errors
  );
  const innerHeight = masterNumber(
    row,
    ["True Inner Height cm (Container Only)", "True Inner H cm", "Inner Height cm"],
    "True Inner Height cm",
    errors
  );
  const usableVolumePercent = masterNumber(
    row,
    ["Usable Volume % (Container Only)", "Usable Volume %"],
    "Usable Volume %",
    errors
  );
  const maxItems = masterNumber(
    row,
    ["Max Content Items (Container Only)", "Max Items"],
    "Max Content Items",
    errors
  );
  const defaultCourierDays = masterNumber(
    row,
    ["Default Courier Days", "Courier Days"],
    "Default Courier Days",
    errors
  );

  if (!common.externalSku) errors.push("Product SKU is required");
  if (!common.name) errors.push("Product Name is required");

  const payload = {
    name: common.name,
    code: common.externalSku.toUpperCase(),
    source: {
      type: "product_master",
      externalSku: common.externalSku,
    },
  };

  setMasterField(payload, "skuBarcode", common.skuBarcode);
  setMasterField(payload, "sourceProductType", common.sourceProductType);
  setMasterField(payload, "taxonomyBaseId", common.taxonomyBaseId);
  setMasterField(payload, "categoryCode", common.categoryCode);
  setMasterField(payload, "category", common.category);
  setMasterField(payload, "subcategory", common.subcategory);
  setMasterField(payload, "segment", common.segment);
  setMasterField(payload, "hsnSac", common.hsnSac);
  setMasterField(payload, "internalNotes", common.internalNotes);

  setMasterField(payload, "productPriority", common.productPriority);
  setMasterField(payload, "mrp", common.mrp);
  setMasterField(payload, "sellingPrice", common.sellingPrice);
  setMasterField(payload, "latestUnitCost", common.latestUnitCost);
  setMasterField(payload, "actualLandedCost", common.actualLandedCost);
  setMasterField(payload, "taxPercent", common.taxPercent);
  payload.taxEnabled = common.taxPercent !== null && Number(common.taxPercent) > 0;
  payload.pricingSource = "product_master";
  payload.taxSource = "product_master";
  setMasterField(payload, "minGrossMarginPercent", common.minGrossMarginPercent);
  setMasterField(payload, "leadTimeDays", common.leadTimeDays);

  const outerDimensions = validPositiveDimensions(common.dimensions)
    ? common.dimensions
    : setupEntry?.outerDimensions;
  const rowInnerDimensions =
    [innerLength, innerWidth, innerHeight].every((value) => Number(value) > 0)
      ? {
          length: innerLength,
          width: innerWidth,
          height: innerHeight,
          unit: "cm",
        }
      : null;

  const finalInnerDimensions = rowInnerDimensions || setupEntry?.innerDimensions || null;
  const finalMaxContentWeight =
    Number(maxSafeLoadKg) > 0
      ? { value: maxSafeLoadKg, unit: "kg" }
      : setupEntry?.maxContentWeight || null;

  if (validPositiveDimensions(outerDimensions)) {
    payload.outerDimensions = outerDimensions;
  }
  if (validPositiveDimensions(finalInnerDimensions)) {
    payload.innerDimensions = finalInnerDimensions;
  }
  if (validPositiveWeight(finalMaxContentWeight)) {
    payload.maxContentWeight = finalMaxContentWeight;
  }

  const finalUsableVolumePercent =
    usableVolumePercent ?? setupEntry?.usableVolumePercent ?? 85;
  const finalMaxItems = maxItems ?? setupEntry?.maxItems ?? 0;
  const finalCourierDays =
    defaultCourierDays ?? setupEntry?.defaultCourierDays ?? null;

  payload.usableVolumePercent = Number(finalUsableVolumePercent);
  payload.maxItems = Number(finalMaxItems);
  payload.defaultCourierDays =
    finalCourierDays === null || finalCourierDays === ""
      ? null
      : Number(finalCourierDays);

  payload.hamperUse = common.hamperUse;
  payload.channels = common.channels;
  payload.isActive = common.isActive;

  const requestedCustomerSelectable =
    common.isActive &&
    common.hamperUse !== false &&
    (setupEntry?.customerSelectable ?? true);

  // A box without a sell price must never leak into the public custom-builder
  // as a zero-price container. Physical/capacity gaps remain REVIEW items and
  // can be completed separately, but price comes from the source catalogue.
  payload.customerSelectable =
    requestedCustomerSelectable && hasPrice(common.sellingPrice);

  if (requestedCustomerSelectable && !hasPrice(common.sellingPrice)) {
    warnings.push(
      "Container was recognized correctly but is hidden from the custom builder until Target Sell Price is supplied"
    );
  }

  const normalizedImage = normalizeCatalogImageUrl(common.imageUrl);
  if (normalizedImage.warning) warnings.push(normalizedImage.warning);
  if (normalizedImage.url) {
    payload.images = [
      { url: normalizedImage.url, publicId: "", alt: common.name },
    ];
  }

  if (common.sourceUpdatedAt) payload.source.sourceUpdatedAt = common.sourceUpdatedAt;

  const addCapacityIssue = (message) => {
    if (allowIncompleteCapacity) {
      warnings.push(message);
      payload.customerSelectable = false;
    } else {
      review.push(message);
    }
  };

  // Outer dimensions are still required even for procurement-only containers
  // because they identify a real physical box record. Inner capacity fields are
  // allowed to remain incomplete for procurement imports, but such containers
  // are forced non-selectable so Custom Hamper can never use unsafe dimensions.
  if (!payload.outerDimensions) {
    review.push("Container requires Product Length, Width and Height for outer dimensions");
  }
  if (!payload.innerDimensions) {
    addCapacityIssue(
      "Container requires true inner Length, Width and Height before it can be used in Custom Hamper"
    );
  }
  if (!payload.maxContentWeight || Number(payload.maxContentWeight.value) <= 0) {
    addCapacityIssue(
      "Container requires Max Content Weight / Max Safe Load kg before it can be used in Custom Hamper"
    );
  }
  if (
    !Number.isFinite(Number(payload.usableVolumePercent)) ||
    Number(payload.usableVolumePercent) < 1 ||
    Number(payload.usableVolumePercent) > 100
  ) {
    addCapacityIssue("Container requires Usable Volume % between 1 and 100");
  }
  if (!Number.isInteger(Number(payload.maxItems)) || Number(payload.maxItems) < 0) {
    addCapacityIssue("Container Max Content Items must be a non-negative whole number");
  }

  if (
    payload.outerDimensions &&
    payload.innerDimensions &&
    validPositiveDimensions(payload.outerDimensions) &&
    validPositiveDimensions(payload.innerDimensions)
  ) {
    const validationError = validateContainerPayload({
      ...payload,
      availability: { status: "in_stock" },
      productionLeadTime: {
        personalizationDays: 0,
        assemblyDays: 0,
        packingDays: 0,
      },
    });
    if (validationError) review.push(validationError);
  }

  return { payload, errors, review, warnings };
};

const comparableDateValue = (value) => {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toISOString();
};

const comparableImportValue = (value) => {
  if (value instanceof Date) return value.toISOString();

  if (Array.isArray(value)) {
    return value.map((item) => comparableImportValue(item));
  }

  if (value && typeof value === "object") {
    const result = {};

    for (const key of Object.keys(value).sort()) {
      if (key === "_id" || key === "lastSyncedAt") continue;
      const nextValue = value[key];
      if (nextValue === undefined) continue;

      if (key.toLowerCase().includes("date") || key.endsWith("At")) {
        result[key] = comparableDateValue(nextValue);
      } else {
        result[key] = comparableImportValue(nextValue);
      }
    }

    return result;
  }

  return value;
};

const valuesMatchIncoming = (current, incoming) => {
  if (incoming instanceof Date) {
    return comparableDateValue(current) === incoming.toISOString();
  }

  if (Array.isArray(incoming)) {
    if (!Array.isArray(current) || current.length !== incoming.length) return false;
    return incoming.every((item, index) => valuesMatchIncoming(current[index], item));
  }

  if (incoming && typeof incoming === "object") {
    if (!current || typeof current !== "object") return false;

    return Object.entries(incoming).every(([key, value]) => {
      if (key === "lastSyncedAt" || value === undefined) return true;
      return valuesMatchIncoming(current[key], value);
    });
  }

  if (typeof incoming === "number") {
    return Number(current) === incoming;
  }

  if (typeof incoming === "boolean") {
    return Boolean(current) === incoming;
  }

  if (incoming === null) return current === null || current === undefined;

  return String(current ?? "") === String(incoming ?? "");
};

const collectChangedFields = (current, incoming, prefix = "") => {
  const changes = [];

  for (const [key, value] of Object.entries(incoming || {})) {
    if (key === "lastSyncedAt" || value === undefined) continue;

    const path = prefix ? `${prefix}.${key}` : key;
    const currentValue = current?.[key];

    if (
      value &&
      typeof value === "object" &&
      !Array.isArray(value) &&
      !(value instanceof Date)
    ) {
      changes.push(...collectChangedFields(currentValue || {}, value, path));
      continue;
    }

    if (!valuesMatchIncoming(currentValue, value)) changes.push(path);
  }

  return changes;
};

const parseHamperCompositionSheet = (workbook, procurementRoleBySku = new Map()) => {
  const sheetName = findWorkbookSheet(workbook, HAMPER_RECIPE_SHEET_ALIASES);

  if (!sheetName) {
    return {
      sheetName: null,
      headerRow: null,
      byHamperSku: new Map(),
      errors: [],
    };
  }

  const extracted = readWorksheetObjects(workbook.Sheets[sheetName], {
    requiredAliasGroups: [
      [
        "Hamper SKU",
        "Parent Hamper SKU",
        "Parent Product SKU",
        "Ready Made Hamper SKU",
        "Hamper Code",
      ],
      [
        "Item SKU",
        "Child SKU",
        "Component SKU",
        "Container SKU",
        "Product SKU",
      ],
    ],
    includeRow: (row) =>
      Boolean(
        masterText(row, [
          "Hamper SKU",
          "Parent Hamper SKU",
          "Parent Product SKU",
          "Ready Made Hamper SKU",
          "Hamper Code",
        ])
      ) ||
      Boolean(
        masterText(row, [
          "Item SKU",
          "Child SKU",
          "Component SKU",
          "Container SKU",
          "Product SKU",
        ])
      ),
  });

  const byHamperSku = new Map();
  const errors = [];

  extracted.rows.forEach(({ row, rowNumber }) => {
    const hamperSku = masterText(row, [
      "Hamper SKU",
      "Parent Hamper SKU",
      "Parent Product SKU",
      "Ready Made Hamper SKU",
      "Hamper Code",
    ]);
    const childSku = masterText(row, [
      "Item SKU",
      "Child SKU",
      "Component SKU",
      "Container SKU",
      "Product SKU",
    ]);
    const roleRaw = masterText(row, [
      "Role",
      "Item Role",
      "Type",
      "Component Type",
    ]).toLowerCase();
    const builderSection = masterText(row, ["Builder Section"]).toLowerCase();

    let role = "content";
    if (roleRaw.includes("container") || roleRaw === "box") role = "container";
    else if (roleRaw.includes("decoration") || builderSection.includes("decoration")) {
      role = "decoration";
    } else if (roleRaw.includes("pack") || roleRaw.includes("material")) {
      role = "packaging";
    }

    // V19: Some supplier recipes label ribbons/florals as "Product".
    // Reconcile against the Product Master category for the very same SKU.
    // Ambiguous category items retain their original recipe role.
    const procurementRole = procurementRoleBySku.get(String(childSku));
    if (procurementRole === "decoration" && role !== "container") {
      role = "decoration";
    } else if (procurementRole === "packaging" && role !== "container") {
      role = "packaging";
    }

    const quantityRaw = getMasterValue(row, ["Quantity", "Qty"]);
    const quantity = quantityRaw === null || quantityRaw === "" ? 1 : Number(quantityRaw);
    const sortOrderRaw = getMasterValue(row, [
      "Sort Order",
      "Sequence",
      "Assembly Sequence",
      "Line No",
    ]);
    const sortOrder =
      sortOrderRaw === null || sortOrderRaw === "" ? rowNumber : Number(sortOrderRaw);

    if (!hamperSku || !childSku) {
      errors.push(`${sheetName} row ${rowNumber} requires Hamper SKU/Code and Item/Product SKU`);
      return;
    }

    if (!Number.isFinite(quantity) || quantity <= 0) {
      errors.push(`${sheetName} row ${rowNumber} has invalid quantity`);
      return;
    }

    if (!Number.isFinite(sortOrder)) {
      errors.push(`${sheetName} row ${rowNumber} has invalid sort order`);
      return;
    }

    const mandatoryRaw = getMasterValue(row, ["Mandatory?"]);
    const isOptional =
      mandatoryRaw !== null && mandatoryRaw !== undefined && mandatoryRaw !== ""
        ? !masterBoolean(row, ["Mandatory?"], true)
        : masterBoolean(row, ["Optional?", "Is Optional"], false);

    const entry = {
      rowNumber,
      hamperSku,
      childSku,
      role,
      quantity,
      unit: masterText(row, ["Unit", "UOM"]) || "pc",
      displayName: masterText(row, [
        "Display Name",
        "Item Name",
        "Product Name",
      ]),
      sortOrder,
      isOptional,
      specification: masterText(row, ["Specification"]),
      notes: masterText(row, ["Notes"]),
      countsTowardBoxCapacity: masterBoolean(
        row,
        ["Counts Toward Box Capacity?"],
        role === "content"
      ),
    };

    if (!byHamperSku.has(hamperSku)) byHamperSku.set(hamperSku, []);
    byHamperSku.get(hamperSku).push(entry);
  });

  return {
    sheetName,
    headerRow: extracted.headerRow,
    byHamperSku,
    errors,
  };
};

const parseProcurementHamperMasterSheet = (workbook) => {
  const sheetName = findWorkbookSheet(workbook, HAMPER_MASTER_SHEET_ALIASES);

  if (!sheetName) {
    return { sheetName: null, headerRow: null, rows: [], errors: [] };
  }

  const extracted = readWorksheetObjects(workbook.Sheets[sheetName], {
    requiredAliasGroups: [
      ["Hamper Code", "Hamper SKU", "Product SKU"],
      ["Hamper Name", "Product Name", "Name"],
    ],
    includeRow: (row) =>
      Boolean(masterText(row, ["Hamper Code", "Hamper SKU", "Product SKU"])) ||
      Boolean(masterText(row, ["Hamper Name", "Product Name", "Name"])),
  });

  const rows = [];
  const errors = [];

  extracted.rows.forEach(({ row, rowNumber }) => {
    const hamperCode = masterText(row, ["Hamper Code", "Hamper SKU", "Product SKU"]);
    const hamperName = masterText(row, ["Hamper Name", "Product Name", "Name"]);

    if (!hamperCode && !hamperName) return;

    if (!hamperCode) {
      errors.push(`${sheetName} row ${rowNumber} requires Hamper Code`);
      return;
    }

    const vertical = masterText(row, ["Vertical", "Website Category", "Category"]);
    const occasion = masterText(row, ["Occasion"]);
    const recipient = masterText(row, ["Recipient / Segment", "Recipient", "Segment"]);
    const theme = masterText(row, ["Theme"]);
    const salesNotes = masterText(row, ["Sales Notes"]);
    const opsNotes = masterText(row, ["Ops Notes", "Notes"]);
    const recipeVersion = masterText(row, ["Recipe Version"]);
    const status = masterText(row, ["Status"]) || "Draft";
    const imageUrl = masterText(row, ["Image / Asset URL", "Image URL"]);

    const synthetic = normalizeMasterRow({
      "Product SKU": hamperCode,
      "Product Name": hamperName,
      "Product Type": "Ready Made Hamper",
      "Record Type": "Ready Made Hamper",
      "Website Category": vertical || occasion || "Hampers",
      Category: vertical || occasion || "Hampers",
      Subcategory: theme || occasion,
      Segment: recipient,
      "Size / Pack": recipeVersion || "Standard",
      Status: status,
      "Product Priority": masterText(row, ["Priority"]),
      "Target Sell Price": getMasterValue(row, ["Target Sell Price"]),
      "Retail MRP": getMasterValue(row, ["MRP / List Price", "Retail MRP"]),
      "Min Gross Margin %": getMasterValue(row, ["Minimum Margin %", "Min Gross Margin %"]),
      "Lead Time Days": getMasterValue(row, ["Lead Time Days"]),
      "Product Length cm": getMasterValue(row, ["Shipping Length cm"]),
      "Product Width cm": getMasterValue(row, ["Shipping Width cm"]),
      "Product Height cm": getMasterValue(row, ["Shipping Height cm"]),
      "Net Product Weight kg": getMasterValue(row, ["Hamper Gross Weight kg"]),
      "Image / Asset URL": imageUrl,
      Notes: [salesNotes, opsNotes].filter(Boolean).join(" | "),
      "Corporate?": /corporate/i.test(`${vertical} ${occasion} ${recipient}`) ? "Yes" : "No",
      "Wedding?": /wedding/i.test(`${vertical} ${occasion} ${recipient}`) ? "Yes" : "No",
      "Diwali?": /diwali/i.test(`${vertical} ${occasion} ${theme}`) ? "Yes" : "No",
      "HAMPER ONE?": /hamper one/i.test(`${vertical} ${occasion} ${theme}`) ? "Yes" : "No",
      // In the live procurement workbook this is the selected gift box / basket
      // for the hamper. Preserve it separately from internal recipe packaging.
      "Container SKU": getMasterValue(row, ["Packaging SKU", "Container SKU", "Box SKU"]),
      "Last Updated Date & Time": getMasterValue(row, ["Last Updated", "Updated At"]),
    });

    rows.push({ row: synthetic, rowNumber });
  });

  return { sheetName, headerRow: extracted.headerRow, rows, errors };
};

const addLookupRecord = (map, record) => {
  if (!record) return;
  const externalSku = normalizeExternalSkuKey(record?.source?.externalSku);
  const code = normalizeCodeKey(record?.code);
  if (externalSku) map.set(externalSku, record);
  if (code) map.set(code, record);
};

const getLookupRecord = (map, sku) => {
  if (!map) return null;
  return map.get(normalizeExternalSkuKey(sku)) || map.get(normalizeCodeKey(sku)) || null;
};

const createEmptyCatalogContext = () => ({
  componentsBySku: new Map(),
  containersBySku: new Map(),
  skusBySku: new Map(),
  readyProductsBySku: new Map(),
  productsById: new Map(),
  categoriesBySlug: new Map(),
  categoriesByName: new Map(),
});

const buildExistingCatalogContext = async ({ allSkus = [], categoryNames = [] } = {}) => {
  const normalizedSkus = [...new Set(allSkus.map(normalizeExternalSkuKey).filter(Boolean))];
  const upperCodes = normalizedSkus.map(normalizeCodeKey);

  const componentQuery = normalizedSkus.length
    ? {
        $or: [
          { "source.externalSku": { $in: normalizedSkus } },
          { code: { $in: upperCodes } },
        ],
      }
    : { _id: null };
  const containerQuery = componentQuery;
  const skuQuery = componentQuery;

  const [components, containers, skus, categories] = await Promise.all([
    Component.find(componentQuery).lean(),
    Container.find(containerQuery).lean(),
    SKU.find(skuQuery).lean(),
    Category.find({}).lean(),
  ]);

  const productIds = [...new Set(skus.map((sku) => String(sku.product || "")).filter(isValidId))];
  const products = productIds.length
    ? await Product.find({ _id: { $in: productIds } }).lean()
    : [];

  const productsById = new Map(products.map((product) => [String(product._id), product]));
  const componentsBySku = new Map();
  const containersBySku = new Map();
  const skusBySku = new Map();
  const readyProductsBySku = new Map();

  for (const component of components) addLookupRecord(componentsBySku, component);
  for (const container of containers) addLookupRecord(containersBySku, container);
  for (const sku of skus) {
    addLookupRecord(skusBySku, sku);
    const product = productsById.get(String(sku.product));
    const externalSku = normalizeExternalSkuKey(sku?.source?.externalSku || sku.code);
    if (product && externalSku) readyProductsBySku.set(externalSku, product);
    if (product && sku.code) readyProductsBySku.set(normalizeCodeKey(sku.code), product);
  }

  const categoriesBySlug = new Map();
  const categoriesByName = new Map();
  for (const category of categories) {
    categoriesBySlug.set(String(category.slug || "").toLowerCase(), category);
    categoriesByName.set(String(category.name || "").trim().toLowerCase(), category);
  }

  for (const name of categoryNames) {
    const key = String(name || "").trim().toLowerCase();
    if (!key) continue;
    const slug = createSlug(name);
    if (!categoriesByName.has(key) && categoriesBySlug.has(slug)) {
      categoriesByName.set(key, categoriesBySlug.get(slug));
    }
  }

  return {
    componentsBySku,
    containersBySku,
    skusBySku,
    readyProductsBySku,
    productsById,
    categoriesBySlug,
    categoriesByName,
  };
};

const resolveReadyMadeCategoryFromContext = (name, context) => {
  const normalizedName = String(name || "").trim();
  if (!normalizedName) return null;

  return (
    context.categoriesByName.get(normalizedName.toLowerCase()) ||
    context.categoriesBySlug.get(createSlug(normalizedName)) ||
    null
  );
};

const buildReadyMadeMasterPayload = async (
  row,
  compositionEntries = [],
  context,
  { requireContainer = true } = {}
) => {
  const errors = [];
  const review = [];
  const warnings = [];
  const common = buildMasterCommonFields(row, errors);
  const categoryName = masterText(row, [
    "Website Category",
    "Ready Made Category",
    "Ready-Made Category",
    "Category",
  ]);
  const shortDescription = masterText(row, [
    "Short Description",
    "Product Short Description",
  ]);
  const description = masterText(row, [
    "Description",
    "Product Description",
    "Notes",
  ]);
  const courierDays = masterNumber(
    row,
    ["Default Courier Days", "Courier Days"],
    "Default Courier Days",
    errors
  );
  const featured = masterBoolean(row, ["Featured?", "Is Featured"], false);
  const normalizedImage = normalizeCatalogImageUrl(common.imageUrl);
  if (normalizedImage.warning) warnings.push(normalizedImage.warning);

  const explicitContainerSku = masterText(row, [
    "Container SKU",
    "Packaging SKU",
    "Box SKU",
  ]);

  // Procurement recipes often label the gift box as generic "Packaging".
  // Once Product Master classification tells us that SKU is a real Container,
  // promote only that referenced line to container. Internal filler/wrap/etc.
  // remains packaging. Hamper Master.Packaging SKU is also authoritative for
  // the selected box even when the recipe omits a duplicate box line.
  const effectiveCompositionEntries = compositionEntries.map((entry) => {
    if (
      getLookupRecord(context.sourceContainersBySku, entry.childSku) &&
      ["packaging", "container"].includes(entry.role)
    ) {
      return { ...entry, role: "container" };
    }
    return entry;
  });

  if (explicitContainerSku) {
    let matched = false;
    for (let index = 0; index < effectiveCompositionEntries.length; index += 1) {
      if (
        normalizeExternalSkuKey(effectiveCompositionEntries[index].childSku) ===
        normalizeExternalSkuKey(explicitContainerSku)
      ) {
        effectiveCompositionEntries[index] = {
          ...effectiveCompositionEntries[index],
          role: "container",
        };
        matched = true;
      }
    }

    if (!matched) {
      effectiveCompositionEntries.unshift({
        rowNumber: null,
        hamperSku: common.externalSku,
        childSku: explicitContainerSku,
        role: "container",
        quantity: 1,
        unit: "pc",
        displayName: "",
        sortOrder: 0,
        isOptional: false,
        specification: "",
        notes: "Container selected in Hamper Master",
        countsTowardBoxCapacity: false,
      });
    }
  }

  if (!common.externalSku) errors.push("Product SKU is required");
  if (!common.name) errors.push("Product Name is required");
  if (!categoryName) errors.push("Website Category / Category is required for ready-made hampers");
  // V20: blank supplier selling price means an incomplete DRAFT, not a corrupt
  // workbook. Keep the row, SKU and composition in the Admin Archive. Never
  // invent price from MRP/COGS. Customer visibility is disabled until ready.
  if (common.sellingPrice === null) {
    review.push("Target Sell Price missing — saved as inactive Admin Draft");
  }

  const containerEntries = effectiveCompositionEntries.filter(
    (entry) => entry.role === "container"
  );
  const contentEntries = effectiveCompositionEntries.filter(
    (entry) => entry.role === "content"
  );
  const materialEntries = effectiveCompositionEntries.filter(
    (entry) => entry.role === "packaging"
  );
  const decorationEntries = effectiveCompositionEntries.filter(
    (entry) => entry.role === "decoration"
  );

  if (effectiveCompositionEntries.length === 0) {
    review.push("No hamper recipe/composition rows were found for this ready-made hamper SKU");
  }

  if (requireContainer && containerEntries.length !== 1) {
    review.push("Ready-made hamper requires exactly one container in the composition");
  } else if (!requireContainer && containerEntries.length === 0) {
    warnings.push(
      "No dedicated HAMPORIUM container is linked yet; the ready-made hamper will use its recipe packaging and can be completed later"
    );
  } else if (containerEntries.length > 1) {
    review.push("Ready-made hamper cannot have more than one container");
  }

  if (contentEntries.length === 0) {
    review.push("Ready-made hamper requires at least one customer-facing content item");
  }

  const container =
    containerEntries.length === 1
      ? getLookupRecord(context.sourceContainersBySku, containerEntries[0].childSku)
      : null;

  const addReadyMadeContainerIssue = (message) => {
    if (requireContainer) review.push(message);
    else warnings.push(message);
  };

  if (containerEntries.length === 1 && !container) {
    addReadyMadeContainerIssue(
      `Container SKU ${containerEntries[0].childSku} is not present in this Product Master or HAMPORIUM`
    );
  } else if (container && container.isActive === false) {
    review.push(`Container ${container.name} is inactive`);
  } else if (container && !validPositiveDimensions(container.innerDimensions)) {
    addReadyMadeContainerIssue(
      `Container ${container.name} still needs true inner dimensions for Custom Hamper; ready-made listing can continue`
    );
  } else if (container && !validPositiveWeight(container.maxContentWeight)) {
    addReadyMadeContainerIssue(
      `Container ${container.name} still needs Max Content Weight / Max Safe Load for Custom Hamper; ready-made listing can continue`
    );
  } else if (
    container &&
    (!Number.isFinite(Number(container.usableVolumePercent)) ||
      Number(container.usableVolumePercent) < 1 ||
      Number(container.usableVolumePercent) > 100)
  ) {
    addReadyMadeContainerIssue(
      `Container ${container.name} still needs Usable Volume % between 1 and 100 for Custom Hamper; ready-made listing can continue`
    );
  }

  const hamperContents = [];
  const internalMaterials = [];
  const decorations = [];
  const physicalComponentMap = new Map();

  for (const entry of contentEntries) {
    const component = getLookupRecord(context.sourceComponentsBySku, entry.childSku);

    if (!component) {
      review.push(`Content SKU ${entry.childSku} is not present in this Product Master or HAMPORIUM`);
      continue;
    }

    if (component.isActive === false) {
      review.push(`${component.name} is inactive`);
      continue;
    }

    if (component.type === "packaging") {
      review.push(`${component.name} is packaging and cannot be customer-facing hamper content`);
      continue;
    }

    if ((component.hamperRole || "content") === "decoration") {
      review.push(`${component.name} is a decoration and cannot be stored as hamper content`);
      continue;
    }

    physicalComponentMap.set(entry.childSku, component);
    hamperContents.push({
      component: entry.childSku,
      quantity: entry.quantity,
      unit: entry.unit || "pc",
      displayName: entry.displayName || component.name,
      sortOrder: entry.sortOrder,
      isOptional: entry.isOptional,
    });
  }

  for (const entry of materialEntries) {
    const component = getLookupRecord(context.sourceComponentsBySku, entry.childSku);

    if (!component) {
      review.push(`Packaging SKU ${entry.childSku} is not present in this Product Master or HAMPORIUM`);
      continue;
    }

    if (component.isActive === false || component.type !== "packaging") {
      review.push(`${component.name} must be an active packaging component`);
      continue;
    }

    internalMaterials.push({
      component: entry.childSku,
      quantity: entry.quantity,
      unit: entry.unit || "pc",
      specification: entry.specification || "",
      notes: entry.notes || "",
    });
  }

  for (const entry of decorationEntries) {
    const component = getLookupRecord(context.sourceComponentsBySku, entry.childSku);

    if (!component) {
      review.push(`Decoration SKU ${entry.childSku} is not present in this Product Master or HAMPORIUM`);
      continue;
    }

    if (component.isActive === false || (component.hamperRole || "content") !== "decoration") {
      review.push(`${component.name} must be an active decoration component`);
      continue;
    }

    decorations.push({
      component: entry.childSku,
      quantity: entry.quantity,
      unit: entry.unit || "pc",
      displayName: entry.displayName || component.name,
      sortOrder: entry.sortOrder,
      isOptional: entry.isOptional,
    });
  }

  if (
    container &&
    validPositiveDimensions(container.innerDimensions) &&
    validPositiveWeight(container.maxContentWeight) &&
    Number.isFinite(Number(container.usableVolumePercent)) &&
    Number(container.usableVolumePercent) >= 1 &&
    Number(container.usableVolumePercent) <= 100 &&
    hamperContents.length === contentEntries.length &&
    hamperContents.length > 0
  ) {
    const selections = hamperContents
      .filter((item) => !item.isOptional)
      .map((item) => ({
        componentId: String(item.component),
        quantity: Number(item.quantity),
      }));

    const physical = evaluatePhysicalConfiguration(
      container,
      selections,
      physicalComponentMap
    );
    if (!physical.valid) {
      review.push(
        `Fixed hamper composition does not pass the common fit engine: ${configurationReasonMessage(physical.reason)}`
      );
    }
  }

  const category = resolveReadyMadeCategoryFromContext(categoryName, context.existingContext);
  const source = {
    type: "product_master",
    externalSku: common.externalSku,
  };
  if (common.sourceUpdatedAt) source.sourceUpdatedAt = common.sourceUpdatedAt;

  const productPayload = {
    name: common.name,
    shortDescription: shortDescription || description.slice(0, 500),
    description,
    brand: common.brand || "HAMPORIUM",
    images: normalizedImage.url
      ? [{ url: normalizedImage.url, publicId: "", alt: common.name }]
      : [],
    tags: normalizeTags([
      "ready-made-hamper",
      common.channels.wedding ? "wedding" : "",
      common.channels.corporate ? "corporate" : "",
      common.channels.diwali ? "diwali" : "",
      common.channels.hamperOne ? "hamper-one" : "",
      common.segment,
      common.subcategory,
    ]),
    status: common.isActive ? PRODUCT_STATUS.ACTIVE : PRODUCT_STATUS.DRAFT,
    isFeatured: featured,
    source,
  };

  const readyMadePricing = calculateCatalogPricing({
    baseSellingPrice: common.sellingPrice === null ? 0 : Number(common.sellingPrice),
    taxPercent: common.taxPercent ?? 0,
    taxEnabled: common.taxPercent !== null && Number(common.taxPercent) > 0,
    discount: { enabled: false, type: "percentage", value: 0 },
  });

  const skuPayload = {
    code: common.externalSku.toUpperCase(),
    skuBarcode: common.skuBarcode || "",
    name: common.sizePack || "Standard",
    optionValues: common.sizePack ? { size: common.sizePack } : {},
    baseSellingPrice: readyMadePricing.baseSellingPrice,
    mrp: common.mrp === null ? null : Number(common.mrp),
    taxEnabled: readyMadePricing.taxEnabled,
    taxPercent: readyMadePricing.taxPercent,
    hsnSac: common.hsnSac || "",
    discount: readyMadePricing.discount,
    pricingSource: "product_master",
    taxSource: "product_master",
    price: readyMadePricing.price,
    compareAtPrice:
      common.mrp !== null && Number(common.mrp) > Number(readyMadePricing.price)
        ? Number(common.mrp)
        : null,
    images: normalizedImage.url
      ? [{ url: normalizedImage.url, publicId: "", alt: common.name }]
      : [],
    container: container ? containerEntries[0]?.childSku || null : null,
    hamperContents,
    internalMaterials,
    decorations,
    packagedDimensions: validPositiveDimensions(common.dimensions)
      ? common.dimensions
      : { length: null, width: null, height: null, unit: "cm" },
    packagedWeight:
      common.weight && Number(common.weight.value) > 0
        ? common.weight
        : { value: null, unit: "kg" },
    productionLeadTime: {
      personalizationDays: common.personalizable ? 1 : 0,
      assemblyDays: Math.max(0, Number(common.leadTimeDays || 0)),
      packingDays: 0,
    },
    defaultCourierDays:
      courierDays === null ? container?.defaultCourierDays ?? null : courierDays,
    isActive: common.isActive,
    sortOrder: Number(common.productPriority || 0),
    source,
  };

  return {
    productPayload,
    skuPayload,
    categoryName,
    categoryId: category?._id || null,
    errors,
    review,
    warnings,
    compositionSummary: {
      containerSku: containerEntries[0]?.childSku || null,
      contentLines: contentEntries.length,
      totalUnits: contentEntries.reduce(
        (sum, entry) => sum + Number(entry.quantity || 0),
        0
      ),
      packagingLines: materialEntries.length,
      decorationLines: decorationEntries.length,
    },
  };
};

const calculateReadyMadeHamperMetrics = (sku) => {
  const contents = Array.isArray(sku?.hamperContents) ? sku.hamperContents : [];
  let contentWeightGrams = 0;
  let contentWeightComplete = true;
  let totalUnits = 0;

  for (const item of contents) {
    if (item.isOptional) continue;
    const quantity = Number(item.quantity || 0);
    totalUnits += quantity;
    const component =
      item.component && typeof item.component === "object" ? item.component : null;
    const grams = component
      ? weightToGrams(component.weight?.value, component.weight?.unit)
      : null;

    if (!Number.isFinite(grams)) contentWeightComplete = false;
    else contentWeightGrams += grams * quantity;
  }

  const packagedWeight = validPositiveWeight(sku?.packagedWeight)
    ? sku.packagedWeight
    : null;
  const packagedDimensions = validPositiveDimensions(sku?.packagedDimensions)
    ? sku.packagedDimensions
    : validPositiveDimensions(sku?.container?.outerDimensions)
      ? sku.container.outerDimensions
      : null;

  return {
    uniqueProductCount: contents.filter((item) => !item.isOptional).length,
    totalUnits: Number(totalUnits.toFixed(3)),
    contentWeight: contentWeightComplete
      ? { value: Number((contentWeightGrams / 1000).toFixed(3)), unit: "kg" }
      : null,
    hamperWeight: packagedWeight,
    hamperWeightSource: packagedWeight ? "product_master" : "not_available",
    dimensions: packagedDimensions,
    dimensionsSource: validPositiveDimensions(sku?.packagedDimensions)
      ? "product_master"
      : packagedDimensions
        ? "container_outer"
        : "not_available",
  };
};

const analyzeProductMasterBuffer = async (
  source,
  filename = "",
  { replaceMode = true, preselectedSheetNames = null } = {}
) => {
  logProductMasterMemory("analyze:start", filename);
  console.info("[ProductMaster] parser=recovery-v10-partial-containers");

  let sheetCatalog = null;
  let workbookProfile = null;
  let selectedSheetNames = [];

  /*
   * A streamed XLSX/XLSM upload has already been compacted to catalogue-only
   * sheets. In that path we can skip the old sheet-name pass and parse the
   * compact workbook exactly once. Legacy Buffer/.xls uploads still use the
   * two-pass path below.
   */
  if (Array.isArray(preselectedSheetNames) && preselectedSheetNames.length > 0) {
    selectedSheetNames = [...new Set(preselectedSheetNames.filter(Boolean))];
    sheetCatalog = { SheetNames: [...selectedSheetNames], Sheets: {} };
    workbookProfile = detectProductMasterWorkbookProfile(sheetCatalog);
  } else {
    sheetCatalog = readWorkbookSource(source, {
      bookSheets: true,
      bookProps: false,
      bookVBA: false,
    });

    workbookProfile = detectProductMasterWorkbookProfile(sheetCatalog);
    selectedSheetNames = getProductMasterSheetSelection(
      sheetCatalog,
      workbookProfile
    );
  }

  console.info(
    `[ProductMaster] selective:sheets (${filename || "workbook"}) | ` +
      (selectedSheetNames.length ? selectedSheetNames.join(", ") : "none")
  );

  const sheetName = workbookProfile.productSheetName;

  if (!sheetName) {
    releaseWorkbookSheets(sheetCatalog);
    sheetCatalog = null;

    const error = new Error(
      `Workbook must contain a Product Master sheet. Supported examples: "Product Master" and "02 Product Master".`
    );
    error.statusCode = 400;
    throw error;
  }

  if (!selectedSheetNames.includes(sheetName)) {
    selectedSheetNames.unshift(sheetName);
  }

  let parsedWorkbook = readWorkbookSource(source, {
    sheets: selectedSheetNames,
    sheetRows: PRODUCT_MASTER_MAX_PARSED_ROWS,
    cellDates: false,
    cellFormula: false,
    cellHTML: false,
    cellText: false,
    cellStyles: false,
    sheetStubs: false,
    bookDeps: false,
    bookFiles: false,
    bookVBA: false,
    /*
     * Keep SheetJS's normal sparse worksheet representation here. Some xlsx
     * versions used by Node/Render do not round-trip sheet_to_json reliably
     * with dense worksheets, which can yield a detected header but zero data
     * rows. The compact workbook is already small, so sparse mode is safe.
     */
    dense: false,
  });

  let workbook = {
    ...parsedWorkbook,
    SheetNames: selectedSheetNames.filter(
      (name) => parsedWorkbook.Sheets?.[name]
    ),
    Sheets: parsedWorkbook.Sheets || {},
  };

  releaseWorkbookSheets(sheetCatalog);
  sheetCatalog = null;
  parsedWorkbook = null;

  if (!workbook.Sheets?.[sheetName]) {
    releaseWorkbookSheets(workbook);
    workbook = null;

    const error = new Error(
      `Unable to read the Product Master sheet "${sheetName}".`
    );
    error.statusCode = 400;
    throw error;
  }

  const productSheet = readWorksheetObjects(workbook.Sheets[sheetName], {
    requiredAliasGroups: [
      ["Product SKU (10 digits numeric — immutable)", "Product SKU", "SKU"],
      ["Product Name", "Name"],
    ],
    maxScanRows: 40,
    includeRow: (row) => {
      const sku = masterText(row, [
        "Product SKU (10 digits numeric — immutable)",
        "Product SKU",
        "SKU",
      ]);
      const name = masterText(row, ["Product Name", "Name"]);
      const usableSku = sku && !String(sku).trim().startsWith("=");
      return Boolean(name || usableSku);
    },
  });

  if (!productSheet.headerRow) {
    releaseWorkbookSheets(workbook);
    workbook = null;

    const error = new Error(
      `Unable to find the Product Master header row in "${sheetName}". The sheet must contain Product SKU and Product Name columns.`
    );
    error.statusCode = 400;
    throw error;
  }

  console.info(
    `[ProductMaster] parsed-product-sheet (${sheetName}) | ` +
      `ref=${workbook.Sheets[sheetName]?.["!ref"] || "unknown"} ` +
      `headerRow=${productSheet.headerRow} dataRows=${productSheet.rows.length}`
  );

  if (productSheet.rows.length > 0) {
    const samples = productSheet.rows.slice(0, 3).map(({ row, rowNumber }) => ({
      rowNumber,
      sku: masterText(row, [
        "Product SKU (10 digits numeric — immutable)",
        "Product SKU",
        "SKU",
      ]),
      name: masterText(row, ["Product Name", "Name"]),
    }));
    console.info(
      `[ProductMaster] parsed-product-samples (${sheetName}) | ${JSON.stringify(samples)}`
    );
  }

  if (productSheet.rows.length === 0) {
    releaseWorkbookSheets(workbook);
    workbook = null;

    const error = new Error(
      `Product Master sheet "${sheetName}" was found and its header was detected at row ${productSheet.headerRow}, but the backend could not read any Product Name/SKU data rows. Parser: direct-cell-v4.`
    );
    error.statusCode = 400;
    throw error;
  }

  const procurementRoleBySku = new Map();
  for (const { row } of productSheet.rows) {
    if (getMasterRecordType(row) !== "component") continue;
    const sku = masterText(row, [
      "Product SKU (10 digits numeric — immutable)", "Product SKU", "SKU",
    ]);
    const role = getProcurementBuilderRole(row);
    if (sku && role) procurementRoleBySku.set(String(sku), role);
  }
  const composition = parseHamperCompositionSheet(workbook, procurementRoleBySku);
  const containerSetup = parseContainerSetupSheet(workbook);
  const decorationMaster = parseDecorationMasterSheet(workbook);
  const procurementHampers =
    workbookProfile.key === "procurement_master"
      ? parseProcurementHamperMasterSheet(workbook)
      : { sheetName: null, headerRow: null, rows: [], errors: [] };

  // Everything needed from the worksheets has now been converted to compact
  // row/maps. Drop the large SheetJS cell structures before DB comparison and
  // payload construction.
  releaseWorkbookSheets(workbook);
  workbook = null;
  logProductMasterMemory("analyze:sheets-released", filename);

  const skuCounts = new Map();
  const rowMeta = [];
  const allSkus = new Set();
  const categoryNames = new Set();

  const addMeta = ({
    row,
    rowNumber,
    sourceSheetName,
    recordType = null,
  }) => {
    const externalSku = masterText(row, [
      "Product SKU (10 digits numeric — immutable)",
      "Product SKU",
      "SKU",
    ]);
    const resolvedRecordType = recordType || getMasterRecordType(row);
    const name = masterText(row, ["Product Name", "Name"]);
    const rowKey = `${sourceSheetName}:${rowNumber}`;

    if (externalSku) {
      skuCounts.set(externalSku, (skuCounts.get(externalSku) || 0) + 1);
      allSkus.add(externalSku);
    }

    if (resolvedRecordType === "ready_made_hamper") {
      const categoryName = masterText(row, [
        "Website Category",
        "Ready Made Category",
        "Ready-Made Category",
        "Category",
      ]);
      if (categoryName) categoryNames.add(categoryName);
    }

    rowMeta.push({
      row,
      rowNumber,
      rowKey,
      sourceSheetName,
      recordType: resolvedRecordType,
      externalSku,
      name,
    });
  };

  for (const entry of productSheet.rows) {
    addMeta({
      row: entry.row,
      rowNumber: entry.rowNumber,
      sourceSheetName: sheetName,
    });
  }

  for (const entry of procurementHampers.rows) {
    addMeta({
      row: entry.row,
      rowNumber: entry.rowNumber,
      sourceSheetName: procurementHampers.sheetName,
      recordType: "ready_made_hamper",
    });
  }

  for (const entries of composition.byHamperSku.values()) {
    for (const entry of entries) allSkus.add(entry.childSku);
  }

  const existingContext = replaceMode
    ? createEmptyCatalogContext()
    : await buildExistingCatalogContext({
        allSkus: [...allSkus],
        categoryNames: [...categoryNames],
      });

  const builtBaseByKey = new Map();
  const workbookComponentsBySku = new Map();
  const workbookContainersBySku = new Map();

  for (const meta of rowMeta) {
    if (meta.recordType === "ready_made_hamper") continue;

    const built =
      meta.recordType === "container"
        ? buildContainerMasterPayload(
            meta.row,
            containerSetup.bySku.get(meta.externalSku) || null,
            { allowIncompleteCapacity: workbookProfile.allowPartialImport }
          )
        : buildComponentMasterPayload(meta.row, {
            decorationMasterEntry:
              decorationMaster.bySku.get(meta.externalSku) || null,
            strictBuilderEligibility: workbookProfile.strictBuilderEligibility,
          });

    builtBaseByKey.set(meta.rowKey, built);

    if (meta.externalSku && built.errors.length === 0) {
      if (meta.recordType === "container") {
        addLookupRecord(workbookContainersBySku, built.payload);
      } else {
        addLookupRecord(workbookComponentsBySku, built.payload);
      }
    }
  }

  const sourceComponentsBySku = new Map(existingContext.componentsBySku);
  const sourceContainersBySku = new Map(existingContext.containersBySku);
  for (const [key, value] of workbookComponentsBySku.entries()) {
    sourceComponentsBySku.set(key, value);
  }
  for (const [key, value] of workbookContainersBySku.entries()) {
    sourceContainersBySku.set(key, value);
  }

  const context = {
    existingContext,
    sourceComponentsBySku,
    sourceContainersBySku,
  };

  const results = [];
  const rowIssueBlocksImport = !workbookProfile.allowPartialImport;

  for (const meta of rowMeta) {
    const {
      row,
      rowNumber,
      rowKey,
      sourceSheetName,
      recordType,
      externalSku,
      name,
    } = meta;

    if (recordType === "ready_made_hamper") {
      const built = await buildReadyMadeMasterPayload(
        row,
        composition.byHamperSku.get(externalSku) || [],
        context,
        { requireContainer: workbookProfile.requireReadyMadeContainer }
      );

      if (externalSku && skuCounts.get(externalSku) > 1) {
        built.errors.push("Duplicate Product SKU exists more than once in this workbook");
      }

      const componentConflict = getLookupRecord(
        existingContext.componentsBySku,
        externalSku
      );
      const containerConflict = getLookupRecord(
        existingContext.containersBySku,
        externalSku
      );
      const manualCrossConflict = [componentConflict, containerConflict].find(
        (record) => record && record?.source?.type !== "product_master"
      );

      if (manualCrossConflict) {
        built.review.push(
          `Product SKU is already owned by a manual ${componentConflict ? "component" : "container"} record`
        );
      }
      const archiveOnlyManualConflict = Boolean(manualCrossConflict);

      if (built.errors.length > 0) {
        results.push({
          rowNumber,
          rowKey,
          sourceSheetName,
          externalSku,
          name,
          recordType,
          action: "ERROR",
          reason: built.errors.join("; "),
          warnings: built.warnings || [],
          blocking: rowIssueBlocksImport,
          changedFields: [],
          compositionSummary: built.compositionSummary,
        });
        continue;
      }

      const existingSku = getLookupRecord(existingContext.skusBySku, externalSku);
      const existingProduct = existingSku
        ? existingContext.productsById.get(String(existingSku.product)) || null
        : getLookupRecord(existingContext.readyProductsBySku, externalSku);

      if (
        (existingSku && existingSku?.source?.type !== "product_master") ||
        (existingProduct && existingProduct?.source?.type !== "product_master")
      ) {
        built.review.push(
          "Ready-made hamper SKU is already owned by a manual catalogue record"
        );
      }

      if (built.review.length > 0) {
        results.push({
          rowNumber,
          rowKey,
          sourceSheetName,
          externalSku,
          name,
          recordType,
          action: "REVIEW",
          reason: [...new Set(built.review)].join("; "),
          warnings: built.warnings || [],
          blocking: rowIssueBlocksImport,
          changedFields: [],
          compositionSummary: built.compositionSummary,
          _payload: {
            product: built.productPayload,
            sku: built.skuPayload,
            categoryName: built.categoryName,
            categoryId: built.categoryId,
          },
          // Never create/overwrite a ready-made SKU that is manually owned.
          _archiveOnly: archiveOnlyManualConflict ||
            (existingSku && existingSku?.source?.type !== "product_master") ||
            (existingProduct && existingProduct?.source?.type !== "product_master"),
        });
        continue;
      }

      const action = !existingProduct || !existingSku ? "CREATE" : "UPDATE";
      const changedFields = [];
      if (existingProduct) {
        changedFields.push(
          ...collectChangedFields(existingProduct, {
            ...built.productPayload,
            category: built.categoryId || existingProduct.category,
          }).map((field) => `product.${field}`)
        );
      }
      if (existingSku) {
        changedFields.push(
          ...collectChangedFields(existingSku, {
            ...built.skuPayload,
            container: undefined,
            hamperContents: undefined,
            internalMaterials: undefined,
            decorations: undefined,
          }).map((field) => `sku.${field}`)
        );
        changedFields.push("sku.composition");
      }

      results.push({
        rowNumber,
        rowKey,
        sourceSheetName,
        externalSku,
        name,
        recordType,
        action,
        reason:
          action === "CREATE"
            ? built.categoryId
              ? "New ready-made hamper Product + SKU"
              : `New ready-made hamper Product + SKU; website category "${built.categoryName}" will be created`
            : replaceMode
              ? "Existing Product Master ready-made hamper will be replaced by this workbook"
              : "Existing ready-made hamper has Product Master / composition changes",
        warnings: built.warnings || [],
        blocking: false,
        changedFields,
        compositionSummary: built.compositionSummary,
        _payload: {
          product: built.productPayload,
          sku: built.skuPayload,
          categoryName: built.categoryName,
          categoryId: built.categoryId,
        },
        _existingProductId: existingProduct?._id || null,
        _existingSkuId: existingSku?._id || null,
      });
      continue;
    }

    const built = builtBaseByKey.get(rowKey);

    if (!built) {
      results.push({
        rowNumber,
        rowKey,
        sourceSheetName,
        externalSku,
        name,
        recordType,
        action: "ERROR",
        reason: "Unable to build this Product Master row",
        warnings: [],
        blocking: rowIssueBlocksImport,
        changedFields: [],
      });
      continue;
    }

    if (externalSku && skuCounts.get(externalSku) > 1) {
      built.errors.push("Duplicate Product SKU exists more than once in this workbook");
    }

    if (built.errors.length > 0) {
      results.push({
        rowNumber,
        rowKey,
        sourceSheetName,
        externalSku,
        name,
        recordType,
        action: "ERROR",
        reason: built.errors.join("; "),
        warnings: built.warnings || [],
        blocking: rowIssueBlocksImport,
        changedFields: [],
      });
      continue;
    }

    const ownMap =
      recordType === "container"
        ? existingContext.containersBySku
        : existingContext.componentsBySku;
    const otherMap =
      recordType === "container"
        ? existingContext.componentsBySku
        : existingContext.containersBySku;
    const existing = getLookupRecord(ownMap, externalSku);
    const conflicting = getLookupRecord(otherMap, externalSku);
    built.payload = preserveManualPriceWhenTargetBlank(built.payload, existing);

    const reviewMessages = [...(built.review || [])];

    if (conflicting && conflicting?.source?.type !== "product_master") {
      reviewMessages.push(
        `Product SKU already exists as a manual ${recordType === "container" ? "component" : "container"}: ${conflicting.name}`
      );
    }

    if (existing && existing?.source?.type !== "product_master") {
      reviewMessages.push(
        "Product SKU is already owned by a manual catalogue record and will not be overwritten"
      );
    }

    if (reviewMessages.length > 0) {
      results.push({
        rowNumber,
        rowKey,
        sourceSheetName,
        externalSku,
        name,
        recordType,
        action: "REVIEW",
        reason: [...new Set(reviewMessages)].join("; "),
        warnings: built.warnings || [],
        blocking: rowIssueBlocksImport,
        changedFields: existing ? collectChangedFields(existing, built.payload) : [],
        _payload: built.payload,
        _existingId: existing?._id || null,
      });
      continue;
    }

    if (!existing) {
      results.push({
        rowNumber,
        rowKey,
        sourceSheetName,
        externalSku,
        name,
        recordType,
        action: "CREATE",
        reason:
          built.warnings?.length > 0
            ? "New Product Master record; imported with safe visibility limits"
            : "New Product Master record",
        warnings: built.warnings || [],
        blocking: false,
        changedFields: [],
        _payload: built.payload,
        _existingId: null,
      });
      continue;
    }

    const changedFields = collectChangedFields(existing, built.payload);

    results.push({
      rowNumber,
      rowKey,
      sourceSheetName,
      externalSku,
      name,
      recordType,
      action: replaceMode ? "UPDATE" : changedFields.length > 0 ? "UPDATE" : "SKIP",
      reason: replaceMode
        ? "Existing Product Master record will be replaced by this workbook"
        : changedFields.length > 0
          ? "Existing record has Product Master changes"
          : "No Product Master changes detected",
      warnings: built.warnings || [],
      blocking: false,
      changedFields,
      _payload: built.payload,
      _existingId: existing._id,
    });
  }

  const allSheetErrors = [
    ...composition.errors,
    ...containerSetup.errors,
    ...decorationMaster.errors,
    ...procurementHampers.errors,
  ];

  const summary = {
    totalRows: results.length,
    create: 0,
    update: 0,
    skip: 0,
    review: 0,
    error: allSheetErrors.length,
    importable: 0,
    nonBlockingIssues: workbookProfile.allowPartialImport
      ? allSheetErrors.length
      : 0,
    components: { create: 0, update: 0, skip: 0, review: 0, error: 0 },
    containers: { create: 0, update: 0, skip: 0, review: 0, error: 0 },
    readyMadeHampers: { create: 0, update: 0, skip: 0, review: 0, error: 0 },
  };

  for (const result of results) {
    const key = result.action.toLowerCase();
    if (Object.prototype.hasOwnProperty.call(summary, key)) summary[key] += 1;
    if (["CREATE", "UPDATE"].includes(result.action)) summary.importable += 1;
    if (
      workbookProfile.allowPartialImport &&
      ["ERROR", "REVIEW"].includes(result.action) &&
      result.blocking === false
    ) {
      summary.nonBlockingIssues += 1;
    }

    const group =
      result.recordType === "container"
        ? summary.containers
        : result.recordType === "ready_made_hamper"
          ? summary.readyMadeHampers
          : summary.components;

    if (Object.prototype.hasOwnProperty.call(group, key)) group[key] += 1;
  }

  logProductMasterMemory("analyze:complete", filename);

  return {
    filename,
    parserVersion: "zip-direct-v20-ready-made-draft-upsert",
    sheetName,
    productHeaderRow: productSheet.headerRow,
    workbookProfile,
    allowPartialImport: workbookProfile.allowPartialImport,
    hamperMasterSheetName: procurementHampers.sheetName,
    hamperMasterHeaderRow: procurementHampers.headerRow,
    compositionSheetName: composition.sheetName,
    compositionHeaderRow: composition.headerRow,
    containerSetupSheetName: containerSetup.sheetName,
    decorationSheetName: decorationMaster.sheetName,
    compositionErrors: allSheetErrors,
    summary,
    results,
    sourceRows: rowMeta.map(({ row, rowKey }) => ({ rowKey, row })),
    replaceMode,
  };
};

const buildContainerReviewData = (result) => {
  if (
    result?.recordType !== "container" ||
    result?.action !== "REVIEW" ||
    !result?._payload
  ) {
    return null;
  }

  const payload = result._payload;

  return {
    outerDimensions: payload.outerDimensions || null,
    innerDimensions: payload.innerDimensions || null,
    maxContentWeight: payload.maxContentWeight || null,
    hasSourceOuterDimensions: validPositiveDimensions(payload.outerDimensions),
    hasSourceInnerDimensions: validPositiveDimensions(payload.innerDimensions),
    hasSourceMaxContentWeight: validPositiveWeight(payload.maxContentWeight),
    material: payload.material || "",
    usableVolumePercent: payload.usableVolumePercent ?? 85,
    maxItems: payload.maxItems ?? 0,
    productionLeadTime: {
      personalizationDays: 0,
      assemblyDays: 0,
      packingDays: 0,
    },
    defaultCourierDays: payload.defaultCourierDays ?? null,
    availability: {
      status: "in_stock",
      availableQuantity: null,
      nextAvailableDate: null,
    },
    customerSelectable: payload.customerSelectable !== false,
    sortOrder: 0,
    sellingPrice: payload.sellingPrice ?? null,
    mrp: payload.mrp ?? null,
    category: payload.category || "",
    subcategory: payload.subcategory || "",
    sourceProductType: payload.sourceProductType || "",
  };
};

const publicImportResult = (result) => ({
  rowNumber: result.rowNumber,
  rowKey: result.rowKey || `${result.sourceSheetName || "Product Master"}:${result.rowNumber}`,
  sourceSheetName: result.sourceSheetName || null,
  externalSku: result.externalSku,
  name: result.name,
  recordType: result.recordType,
  action: result.action,
  reason: result.reason,
  warnings: result.warnings || [],
  blocking: result.blocking !== false,
  changedFields: result.changedFields || [],
  compositionSummary: result.compositionSummary || null,
  reviewData: buildContainerReviewData(result),
  priceAudit: result.recordType === "container" || result.recordType === "component"
    ? {
        targetSellPrice: result._payload?.sellingPrice ?? null,
        mrp: result._payload?.mrp ?? null,
        priceSource: "Target Sell Price",
        // Null is genuinely blank in the source; existing DB value is retained.
        blankTargetPreservesExisting: result._payload?.sellingPrice == null,
      }
    : null,
});

const parseContainerReviewCompletion = (raw) => {
  if (!raw) return {};

  if (typeof raw === "object") return raw;

  try {
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    const error = new Error("Invalid container completion data");
    error.statusCode = 400;
    throw error;
  }
};

// V12: NEVER delete products/SKUs/components/containers on Excel import.
// Existing orders/cart references and manually managed items must survive.
const retireMissingImportedRows = async (ids) => {
  const selectors = [
    [Component, ids.components, { isActive: false, customerSelectable: false }],
    [Container, ids.containers, { isActive: false, customerSelectable: false }],
    [Product, ids.products, { status: PRODUCT_STATUS.DRAFT }],
    [SKU, ids.skus, { isActive: false }],
  ];
  for (const [Model, keep, fields] of selectors) {
    await Model.updateMany(
      { "source.type": "product_master", _id: { $nin: keep } },
      { $set: fields }
    );
  }
};

// V16: keep an existing price entered by an admin when Excel Target Sell
// Price is blank. A nonblank Target Sell Price always overwrites the old price.
// This NEVER derives a selling price from Retail MRP.
const preserveManualPriceWhenTargetBlank = (payload, existing) => {
  const next = { ...payload };
  if (
    !Object.prototype.hasOwnProperty.call(next, "sellingPrice") &&
    Number(existing?.sellingPrice) > 0
  ) {
    // Otherwise a blank Excel cell would disable an already configured box.
    delete next.customerSelectable;
  }
  return next;
};

const preserveGalleryOnSpreadsheetUpdate = (payload) => {
  const next = { ...payload };
  // A folder link is not a display URL; don't clear existing Cloudinary images.
  if (!Array.isArray(next.images) || next.images.length === 0) delete next.images;
  return next;
};

const upsertImportedBaseRow = async (Model, payload, externalSku) => {
  const code = String(payload.code || "").trim().toUpperCase();
  const canonicalSku = String(externalSku || "").trim();
  const manualConflict = await Model.findOne({
    code,
    "source.type": { $ne: "product_master" },
  }).select("_id").lean();
  if (manualConflict) {
    throw new Error(`SKU ${code} belongs to a manual record; archived instead of overwriting it`);
  }

  // Older imports sometimes recorded the code but not the normalized source
  // SKU. Reuse that SAME document to avoid duplicate boxes and stale prices.
  const existing = await Model.findOne({
    "source.type": "product_master",
    $or: [
      { "source.externalSku": canonicalSku },
      { code },
    ],
  }).select("_id sellingPrice customerSelectable").lean();

  const safePayload = preserveGalleryOnSpreadsheetUpdate(
    preserveManualPriceWhenTargetBlank(payload, existing)
  );

  // V22: Spreadsheet supply data must not flip an existing LIVE item OFF,
  // nor silently revive a box the admin explicitly disabled. Publication is
  // an admin decision, separate from upstream Excel Status/Hamper Use flags.
  if (existing) {
    delete safePayload.isActive;
    delete safePayload.customerSelectable;
    delete safePayload.hamperUse;
    delete safePayload.channels;
  }

  const filter = existing
    ? { _id: existing._id }
    : { "source.type": "product_master", "source.externalSku": canonicalSku };

  return Model.findOneAndUpdate(
    filter,
    { $set: safePayload },
    { upsert: !existing, new: true, runValidators: true, setDefaultsOnInsert: true }
  );
};

const archiveProductMasterSourceRows = async ({ analysis, results, importedAt, catalogRefs }) => {
  const byKey = new Map(results.map((result) => [result.rowKey, result]));
  const sourceByKey = new Map((analysis.sourceRows || []).map((item) => [item.rowKey, item.row]));
  const operations = analysis.results.map((row) => {
    const result = byKey.get(row.rowKey) || publicImportResult(row);
    const imported = ["CREATED", "UPDATED", "SKIP", "UNCHANGED"].includes(result.action);
    const ref = catalogRefs.get(row.rowKey);
    // Key by source SKU rather than sheet row position: moving rows in Excel
    // must never overwrite a DIFFERENT product's archived original data.
    const archiveKey = row.externalSku
      ? `${row.sourceSheetName}:${row.recordType}:${row.externalSku}`
      : `${row.rowKey}:missing-sku:${importedAt.getTime()}`;
    return {
      updateOne: {
        filter: { rowKey: archiveKey },
        update: { $set: {
          rowKey: archiveKey,
          sourceSheetName: row.sourceSheetName || "",
          rowNumber: row.rowNumber,
          externalSku: String(row.externalSku || ""),
          name: String(row.name || ""),
          recordType: String(row.recordType || ""),
          sourceFilename: analysis.filename || "",
          rawExcelData: sourceByKey.get(row.rowKey) || {},
          status: imported ? "imported" : result.action === "ERROR" ? "import_error" : "needs_attention",
          reasons: imported ? (result.warnings || []) : [result.reason || "Incomplete Excel row"],
          catalogModel: ref?.model || "",
          catalogId: ref?.id || null,
          lastImportedAt: importedAt,
        } },
        upsert: true,
      }
    };
  });
  if (operations.length) await ProductMasterArchive.bulkWrite(operations, { ordered: false });
  // Stale row snapshots remain archived for traceability, and never render publicly.
};

const buildImportedBaseLookup = async (importedAt) => {
  const [components, containers] = await Promise.all([
    Component.find({ "source.type": "product_master", "source.lastSyncedAt": importedAt }).lean(),
    Container.find({ "source.type": "product_master", "source.lastSyncedAt": importedAt }).lean(),
  ]);

  const componentsBySku = new Map();
  const containersBySku = new Map();
  for (const component of components) addLookupRecord(componentsBySku, component);
  for (const container of containers) addLookupRecord(containersBySku, container);

  return { componentsBySku, containersBySku };
};

const resolveReadyMadeReferences = (
  skuPayload,
  baseLookup,
  { allowMissingContainer = false, allowMissingItems = false } = {}
) => {
  const resolved = {
    ...skuPayload,
    hamperContents: [],
    internalMaterials: [],
    decorations: [],
  };

  if (skuPayload.container) {
    const container = getLookupRecord(baseLookup.containersBySku, skuPayload.container);
    if (!container) {
      if (allowMissingContainer) {
        resolved.container = null;
      } else {
        throw new Error(`Container SKU ${skuPayload.container} was not imported`);
      }
    } else {
      resolved.container = container._id;
    }
  } else {
    resolved.container = null;
  }

  const expiryDates = [];

  for (const item of skuPayload.hamperContents || []) {
    const component = getLookupRecord(baseLookup.componentsBySku, item.component);
    if (!component) {
      if (allowMissingItems) continue; // Incomplete Admin Draft; never public.
      throw new Error(`Content SKU ${item.component} was not imported`);
    }
    if (component.type === "packaging" || (component.hamperRole || "content") === "decoration") {
      if (allowMissingItems) continue;
      throw new Error(`${component.name} is not valid ready-made hamper content`);
    }

    resolved.hamperContents.push({
      ...item,
      component: component._id,
    });

    if (!item.isOptional && component.type === "food" && component.expiryDate) {
      const date = new Date(component.expiryDate);
      if (!Number.isNaN(date.getTime())) expiryDates.push(date);
    }
  }

  for (const item of skuPayload.internalMaterials || []) {
    const component = getLookupRecord(baseLookup.componentsBySku, item.component);
    if (!component) {
      if (allowMissingItems) continue;
      throw new Error(`Packaging SKU ${item.component} was not imported`);
    }
    if (component.type !== "packaging") {
      if (allowMissingItems) continue;
      throw new Error(`${component.name} is not an internal packaging component`);
    }

    resolved.internalMaterials.push({
      ...item,
      component: component._id,
    });
  }

  for (const item of skuPayload.decorations || []) {
    const component = getLookupRecord(baseLookup.componentsBySku, item.component);
    if (!component) {
      if (allowMissingItems) continue;
      throw new Error(`Decoration SKU ${item.component} was not imported`);
    }
    if ((component.hamperRole || "content") !== "decoration") {
      if (allowMissingItems) continue;
      throw new Error(`${component.name} is not a decoration component`);
    }

    resolved.decorations.push({
      ...item,
      component: component._id,
    });
  }

  resolved.earliestExpiryDate = expiryDates.length
    ? new Date(Math.min(...expiryDates.map((date) => date.getTime())))
    : null;

  return resolved;
};

const ensureImportedCategory = async (categoryName, importedAt) => {
  const normalizedName = String(categoryName || "").trim();
  if (!normalizedName) throw new Error("Ready-made hamper category is required");

  const slug = createSlug(normalizedName);
  let category = await Category.findOne({
    $or: [
      { slug },
      { name: { $regex: `^${escapeRegex(normalizedName)}$`, $options: "i" } },
    ],
  });

  if (category) return category;

  category = await Category.create({
    name: normalizedName,
    slug: await ensureUniqueSlug(Category, normalizedName),
    description: "",
    image: "",
    imagePublicId: "",
    isActive: true,
    sortOrder: 0,
    source: {
      type: "product_master",
      externalSku: `category:${slug}`,
      lastSyncedAt: importedAt,
    },
  });

  return category;
};

const cleanupOrphanedProductMasterCategories = async () => {
  const usedCategoryIds = (await Product.distinct("category"))
    .map((value) => String(value || ""))
    .filter(isValidId);

  const filter = { "source.type": "product_master" };
  if (usedCategoryIds.length > 0) {
    filter._id = { $nin: usedCategoryIds };
  }

  const result = await Category.deleteMany(filter);
  return result.deletedCount || 0;
};

/* =========================================================
   ADMIN PRODUCT MASTER IMPORT
========================================================= */

export const previewProductMasterImport = asyncHandler(async (req, res) => {
  const uploadSource = getProductMasterUploadSource(req.file);

  if (!uploadSource) {
    return res.status(400).json({
      success: false,
      message: "Product Master Excel file is required",
    });
  }

  const analysis = await analyzeUploadedProductMaster(req.file, {
    replaceMode: false,
  });

  res.status(200).json({
    success: true,
    message: analysis.allowPartialImport
      ? "Workbook analyzed. Valid records will upsert without deleting existing data; incomplete rows are preserved in Admin Archive."
      : "Workbook analyzed. Valid rows will upsert and incomplete rows will be preserved in Admin Archive; nothing will be deleted.",
    importMode: "archive_upsert",
    replacementStrategy: "non_destructive_upsert_with_archive",
    workbookProfile: analysis.workbookProfile,
    allowPartialImport: analysis.allowPartialImport,
    filename: analysis.filename,
    sheetName: analysis.sheetName,
    productHeaderRow: analysis.productHeaderRow,
    hamperMasterSheetName: analysis.hamperMasterSheetName,
    hamperMasterHeaderRow: analysis.hamperMasterHeaderRow,
    compositionSheetName: analysis.compositionSheetName,
    compositionHeaderRow: analysis.compositionHeaderRow,
    containerSetupSheetName: analysis.containerSetupSheetName,
    decorationSheetName: analysis.decorationSheetName,
    compositionErrors: analysis.compositionErrors,
    summary: analysis.summary,
    results: analysis.results.map(publicImportResult),
  });
});

export const completeProductMasterContainerReview = asyncHandler(
  async (req, res) => {
    const uploadSource = getProductMasterUploadSource(req.file);

    if (!uploadSource) {
      return res.status(400).json({
        success: false,
        message: "Product Master Excel file is required",
      });
    }

    const externalSku = String(req.body.externalSku || "").trim();

    if (!externalSku) {
      return res.status(400).json({
        success: false,
        message: "Product SKU is required for container review completion",
      });
    }

    const completion = parseContainerReviewCompletion(req.body.completion);

    const analysis = await analyzeUploadedProductMaster(req.file, {
      replaceMode: true,
    });

    const item = analysis.results.find(
      (result) =>
        result.recordType === "container" &&
        String(result.externalSku || "") === externalSku
    );

    if (!item) {
      return res.status(404).json({
        success: false,
        message: "Container row was not found in the selected Product Master file",
      });
    }

    if (item.action === "ERROR") {
      return res.status(400).json({
        success: false,
        message: item.reason || "This Product Master row contains errors",
      });
    }

    if (!item._payload) {
      return res.status(409).json({
        success: false,
        message:
          item.reason ||
          "This review row cannot be completed automatically. Resolve the conflict first.",
      });
    }

    const sourcePayload = item._payload;

    let container = item._existingId
      ? await Container.findById(item._existingId)
      : await Container.findOne({
          $or: [
            { "source.externalSku": externalSku },
            { code: externalSku.toUpperCase() },
          ],
        });

    const existingPlain = container ? container.toObject() : {};

    const outerDimensions =
      sourcePayload.outerDimensions ||
      completion.outerDimensions ||
      existingPlain.outerDimensions;

    const innerDimensions =
      sourcePayload.innerDimensions ||
      completion.innerDimensions ||
      existingPlain.innerDimensions;

    const maxContentWeight =
      sourcePayload.maxContentWeight ||
      completion.maxContentWeight ||
      existingPlain.maxContentWeight;

    if (!validPositiveDimensions(outerDimensions)) {
      return res.status(400).json({
        success: false,
        message: "Valid outer Length, Width and Height are required",
      });
    }

    if (!validPositiveDimensions(innerDimensions)) {
      return res.status(400).json({
        success: false,
        message: "Valid true inner Length, Width and Height are required",
      });
    }

    if (!validPositiveWeight(maxContentWeight)) {
      return res.status(400).json({
        success: false,
        message: "Maximum content weight is required",
      });
    }

    const currentLeadTime = toPlainObject(existingPlain.productionLeadTime);
    const requestedLeadTime =
      completion.productionLeadTime &&
      typeof completion.productionLeadTime === "object"
        ? completion.productionLeadTime
        : {};

    const productionLeadTime = {
      personalizationDays:
        requestedLeadTime.personalizationDays ??
        currentLeadTime.personalizationDays ??
        0,
      assemblyDays:
        requestedLeadTime.assemblyDays ?? currentLeadTime.assemblyDays ?? 0,
      packingDays:
        requestedLeadTime.packingDays ?? currentLeadTime.packingDays ?? 0,
    };

    const leadTimeError = validateProductionLeadTime(productionLeadTime);
    if (leadTimeError) {
      return res.status(400).json({ success: false, message: leadTimeError });
    }

    const currentAvailability = toPlainObject(existingPlain.availability);
    const requestedAvailability =
      completion.availability && typeof completion.availability === "object"
        ? completion.availability
        : {};

    const availability = {
      ...currentAvailability,
      ...requestedAvailability,
      status:
        requestedAvailability.status || currentAvailability.status || "in_stock",
    };

    const availabilityError = validateAvailabilityPayload(availability, {
      stockUnit: false,
      label: "container availability",
    });

    if (availabilityError) {
      return res.status(400).json({ success: false, message: availabilityError });
    }

    const usableVolumePercent =
      sourcePayload.usableVolumePercent ??
      (completion.usableVolumePercent !== undefined &&
      completion.usableVolumePercent !== null &&
      completion.usableVolumePercent !== ""
        ? Number(completion.usableVolumePercent)
        : Number(existingPlain.usableVolumePercent ?? 85));

    const maxItems =
      sourcePayload.maxItems ??
      (completion.maxItems !== undefined &&
      completion.maxItems !== null &&
      completion.maxItems !== ""
        ? Number(completion.maxItems)
        : Number(existingPlain.maxItems ?? 0));

    const requestedCourierDays =
      sourcePayload.defaultCourierDays ??
      (completion.defaultCourierDays !== undefined
        ? completion.defaultCourierDays
        : existingPlain.defaultCourierDays);

    const courier = parseCourierDays(requestedCourierDays, null);
    if (!courier.valid) {
      return res.status(400).json({ success: false, message: courier.message });
    }

    let customerSelectable =
      sourcePayload.customerSelectable !== undefined
        ? Boolean(sourcePayload.customerSelectable)
        : completion.customerSelectable !== undefined
          ? parseBoolean(completion.customerSelectable)
          : existingPlain.customerSelectable;

    if (
      completion.customerSelectable !== undefined &&
      customerSelectable === undefined
    ) {
      return res.status(400).json({
        success: false,
        message: "customerSelectable must be true or false",
      });
    }

    if (customerSelectable === undefined) {
      customerSelectable =
        sourcePayload.hamperUse !== false && sourcePayload.isActive !== false;
    }

    if (sourcePayload.hamperUse === false || sourcePayload.isActive === false) {
      customerSelectable = false;
    }

    const packingMaterialsInput =
      completion.packingMaterials !== undefined
        ? completion.packingMaterials
        : existingPlain.packingMaterials || [];

    const materialsResult = await validateAndNormalizeMaterialItems(
      packingMaterialsInput,
      {
        fieldName: "packingMaterials",
        activeOnly: true,
      }
    );

    if (!materialsResult.valid) {
      return res.status(400).json({
        success: false,
        message: materialsResult.message,
      });
    }

    const importedAt = new Date();

    const payload = {
      ...sourcePayload,
      material:
        completion.material !== undefined
          ? String(completion.material || "").trim()
          : existingPlain.material || "",
      outerDimensions: normalizeContainerDimensions(outerDimensions),
      innerDimensions: normalizeContainerDimensions(innerDimensions),
      maxContentWeight: normalizeWeightCapacity(maxContentWeight),
      usableVolumePercent,
      maxItems,
      packingMaterials: materialsResult.items,
      productionLeadTime: normalizeProductionLeadTime(productionLeadTime),
      defaultCourierDays: courier.value,
      availability: normalizeAvailability(availability, { stockUnit: false }),
      customerSelectable,
      sortOrder:
        completion.sortOrder !== undefined
          ? Number(completion.sortOrder) || 0
          : Number(existingPlain.sortOrder || 0),
      source: {
        ...(sourcePayload.source || {}),
        type: "product_master",
        externalSku,
        lastSyncedAt: importedAt,
      },
    };

    if (completion.internalNotes !== undefined) {
      payload.internalNotes = String(completion.internalNotes || "");
    } else if (
      sourcePayload.internalNotes === undefined &&
      existingPlain.internalNotes !== undefined
    ) {
      payload.internalNotes = existingPlain.internalNotes;
    }

    const validationError = validateContainerPayload({
      ...payload,
      outerDimensions: payload.outerDimensions,
      innerDimensions: payload.innerDimensions,
      maxContentWeight: payload.maxContentWeight,
      usableVolumePercent: payload.usableVolumePercent,
      maxItems: payload.maxItems,
      availability: payload.availability,
      productionLeadTime: payload.productionLeadTime,
      defaultCourierDays: payload.defaultCourierDays,
      hamperUse: payload.hamperUse,
    });

    if (validationError) {
      return res.status(400).json({ success: false, message: validationError });
    }

    let created = false;

    if (!container) {
      container = await Container.create(payload);
      created = true;
    } else {
      container.set(payload);
      await container.save();
    }

    const plain = container.toObject();

    res.status(created ? 201 : 200).json({
      success: true,
      message: created
        ? "Container review completed and container imported"
        : "Container review completed and container updated",
      container: {
        ...plain,
        capacity: calculateContainerCapacity(plain),
      },
    });
  }
);

export const confirmProductMasterImport = asyncHandler(async (req, res) => {
  const uploadSource = getProductMasterUploadSource(req.file);

  if (!uploadSource) {
    return res.status(400).json({
      success: false,
      message: "Product Master Excel file is required",
    });
  }

  const confirmStartedAt = Date.now();
  console.info(`[ProductMaster] confirm:start file=${req.file?.originalname || "unknown"} bytes=${req.file?.size || 0}`);
  const preflight = await analyzeUploadedProductMaster(req.file, {
    replaceMode: false,
  });
  console.info(`[ProductMaster] confirm:analyzed rows=${preflight.results.length} elapsedMs=${Date.now() - confirmStartedAt}`);

  // Incomplete/invalid rows will be archived with their original Excel fields,
  // not discarded and not offered to the customer.
  const importableRows = preflight.results.filter((item) =>
    ["CREATE", "UPDATE", "SKIP"].includes(item.action)
  );
  const importableBaseRows = importableRows.filter(
    (item) => item.recordType !== "ready_made_hamper"
  );

  if (importableRows.length === 0 || importableBaseRows.length === 0) {
    return res.status(409).json({
      success: false,
      message:
        "Import was not started because no valid base Product Master rows were found. Existing catalogue data is unchanged.",
      importMode: "replace_product_master",
      workbookProfile: preflight.workbookProfile,
      allowPartialImport: preflight.allowPartialImport,
      filename: preflight.filename,
      sheetName: preflight.sheetName,
      compositionErrors: preflight.compositionErrors,
      summary: preflight.summary,
      results: preflight.results.map(publicImportResult),
    });
  }

  /*
   * IMPORTANT: reuse the already parsed workbook rather than parsing it
   * again. V16 preflight checks the EXISTING DB and updates by immutable SKU.
   * No collection is cleared; empty Excel fields do not erase saved prices.
   */
  const analysis = preflight;
  // No hard replacement, no deleteMany, no source workbook modification.
  const removed = { products: 0, skus: 0, components: 0, containers: 0, categories: 0 };

  const importedAt = new Date();
  const kept = { products: [], skus: [], components: [], containers: [] };
  const catalogRefs = new Map();
  const resultByKey = new Map();
  const summary = {
    totalRows: analysis.summary.totalRows,
    created: 0,
    updated: 0,
    skipped: 0,
    review: 0,
    errors: 0,
    removed,
  };

  // V21: bounded concurrent MongoDB writes. Previous implementation awaited
  // 2-3 round trips for every base SKU sequentially. A supplier workbook can
  // have 180+ SKUs, causing HTTP proxy timeouts / ECONNRESET on Render.
  // Concurrency is deliberately small so memory/DB connection pool stay safe.
  const baseRows = analysis.results.filter(
    (item) => item.recordType !== "ready_made_hamper"
  );
  const baseConcurrency = Math.max(
    1,
    Math.min(6, Number(process.env.PRODUCT_MASTER_IMPORT_CONCURRENCY) || 5)
  );
  let nextBaseIndex = 0;
  const baseStartedAt = Date.now();
  console.info(`[ProductMaster] confirm:base-start rows=${baseRows.length} concurrency=${baseConcurrency}`);

  const importBaseRow = async (item) => {
    if (!["CREATE", "UPDATE", "SKIP"].includes(item.action)) {
      resultByKey.set(item.rowKey, publicImportResult(item));
      return;
    }
    try {
      const Model = item.recordType === "container" ? Container : Component;
      const payload = {
        ...item._payload,
        source: {
          ...(item._payload?.source || {}),
          type: "product_master",
          externalSku: item.externalSku,
          lastSyncedAt: importedAt,
        },
      };
      const old = await Model.findOne({
        "source.type": "product_master",
        $or: [
          { "source.externalSku": item.externalSku },
          { code: String(payload.code || "").toUpperCase() },
        ],
      }).select("_id").lean();
      const saved = await upsertImportedBaseRow(Model, payload, item.externalSku);
      if (item.recordType === "container") {
        // When correcting historical misclassification, carry the existing
        // Cloudinary gallery over to the newly-recognized box. Do not erase
        // the old source record or overwrite a gallery already on the box.
        if (!Array.isArray(saved.images) || saved.images.length === 0) {
          const previousWrongType = await Component.findOne({
            "source.type": "product_master",
            $or: [
              { "source.externalSku": item.externalSku },
              { code: String(payload.code || "").toUpperCase() },
            ],
          }).select("images").lean();
          if (Array.isArray(previousWrongType?.images) && previousWrongType.images.length) {
            await Container.updateOne({ _id: saved._id, "source.type": "product_master" },
              { $set: { images: previousWrongType.images } });
          }
        }
        // Retain old source record for audit/references, but stop showing an
        // incorrectly imported box among customer gift components. Never
        // touch manually owned components with a coincidentally matching code.
        await Component.updateMany({
          "source.type": "product_master",
          $or: [
            { "source.externalSku": item.externalSku },
            { code: String(payload.code || "").toUpperCase() },
          ],
        }, { $set: { isActive: false, customerSelectable: false, hamperUse: false } });
      }
      kept[item.recordType === "container" ? "containers" : "components"].push(saved._id);
      catalogRefs.set(item.rowKey, {
        model: item.recordType === "container" ? "Container" : "Component",
        id: saved._id,
      });
      resultByKey.set(item.rowKey, {
        ...publicImportResult(item),
        action: old ? (item.action === "SKIP" ? "UNCHANGED" : "UPDATED") : "CREATED",
      });
    } catch (error) {
      console.error(`[ProductMaster] base row failed SKU=${item.externalSku}:`, error?.message);
      resultByKey.set(item.rowKey, {
        ...publicImportResult(item),
        action: "ERROR",
        blocking: false,
        reason: error.message || "Unable to import this row",
      });
    }
  };

  const baseWorker = async () => {
    while (nextBaseIndex < baseRows.length) {
      const index = nextBaseIndex++;
      await importBaseRow(baseRows[index]);
      if ((index + 1) % 25 === 0 || index + 1 === baseRows.length) {
        console.info(
          `[ProductMaster] confirm:base-progress ${index + 1}/${baseRows.length} elapsedMs=${Date.now() - baseStartedAt}`
        );
      }
    }
  };
  await Promise.all(
    Array.from({ length: Math.min(baseConcurrency, baseRows.length) }, () => baseWorker())
  );
  console.info(`[ProductMaster] confirm:base-done elapsedMs=${Date.now() - baseStartedAt}`);

  const runtimeBaseErrors = [...resultByKey.values()].filter(
    (item) =>
      item.recordType !== "ready_made_hamper" &&
      item.action === "ERROR"
  );

  const baseLookup = await buildImportedBaseLookup(importedAt);

  let draftHampersSaved = 0;
  for (const item of analysis.results) {
    if (item.recordType !== "ready_made_hamper") continue;

    const saveAsDraft = analysis.allowPartialImport &&
      item.action === "REVIEW" && Boolean(item._payload) &&
      !item._archiveOnly;
    const saveAsComplete = ["CREATE", "UPDATE", "SKIP"].includes(item.action);

    if (!saveAsDraft && !saveAsComplete) {
      resultByKey.set(item.rowKey, publicImportResult(item));
      continue;
    }

    if (!analysis.allowPartialImport && runtimeBaseErrors.length > 0) {
      resultByKey.set(item.rowKey, {
        ...publicImportResult(item),
        action: "ERROR",
        reason:
          "Ready-made hamper was not imported because one or more base component/container rows failed",
      });
      continue;
    }

    try {
      const category = await ensureImportedCategory(
        item._payload.categoryName,
        importedAt
      );

      const productPayload = {
        ...item._payload.product,
        category: category._id,
        // Incomplete hamper is retained in MongoDB but cannot reach customers.
        ...(saveAsDraft ? { status: PRODUCT_STATUS.DRAFT } : {}),
        source: {
          ...(item._payload.product.source || {}),
          type: "product_master",
          externalSku: item.externalSku,
          lastSyncedAt: importedAt,
        },
      };

      const skuPayload = resolveReadyMadeReferences(
        {
          ...item._payload.sku,
          ...(saveAsDraft ? { isActive: false } : {}),
          source: {
            ...(item._payload.sku.source || {}),
            type: "product_master",
            externalSku: item.externalSku,
            lastSyncedAt: importedAt,
          },
        },
        baseLookup,
        {
          allowMissingContainer: analysis.allowPartialImport,
          allowMissingItems: saveAsDraft,
        }
      );

      const oldSku = await SKU.findOne({
        "source.type": "product_master", "source.externalSku": item.externalSku,
      }).select("_id product").lean();
      const oldProduct = oldSku?.product
        ? await Product.findById(oldSku.product).select("_id source").lean()
        : await Product.findOne({
            "source.type": "product_master", "source.externalSku": item.externalSku,
          }).select("_id").lean();
      if (oldProduct && oldProduct.source?.type !== "product_master") {
        throw new Error("Existing product is manually owned; archived without overwrite");
      }
      // V22: Even an incomplete supplier row never overrides Admin's
      // published/draft choice for an EXISTING ready-made hamper.
      if (oldProduct) delete productPayload.status;
      if (oldSku) delete skuPayload.isActive;
      const oldManualSku = await SKU.findOne({
        code: skuPayload.code, "source.type": { $ne: "product_master" },
      }).select("_id").lean();
      if (oldManualSku) throw new Error("Manual SKU conflict; archived without overwrite");

      if (saveAsDraft && oldSku) {
        // Blank supplier cells do not erase a previously saved manual price.
        const previousSku = await SKU.findById(oldSku._id).lean();
        if (previousSku) {
          const originalPrice = item._payload?.sku?.baseSellingPrice;
          if (!(Number(originalPrice) > 0) && Number(previousSku.baseSellingPrice) > 0) {
            skuPayload.baseSellingPrice = previousSku.baseSellingPrice;
            skuPayload.price = previousSku.price;
            skuPayload.compareAtPrice = previousSku.compareAtPrice ?? null;
            skuPayload.pricingSource = previousSku.pricingSource || skuPayload.pricingSource;
          }
          // If supplier omits recipe/box in an incomplete row, keep historical
          // composition links instead of wiping the admin's previous setup.
          for (const key of ["hamperContents", "internalMaterials", "decorations"]) {
            if (!(skuPayload[key] || []).length && (previousSku[key] || []).length) {
              delete skuPayload[key];
            }
          }
          if (!skuPayload.container && previousSku.container) {
            delete skuPayload.container;
          }
        }
      }

      let product;
      let productCreated = false;
      if (oldProduct) {
        product = await Product.findByIdAndUpdate(oldProduct._id,
          { $set: preserveGalleryOnSpreadsheetUpdate(productPayload) },
          { new: true, runValidators: true });
      } else {
        product = await Product.create({
          ...productPayload,
          slug: await ensureUniqueSlug(Product, productPayload.name),
        });
        productCreated = true;
      }

      let sku;
      try {
        sku = await SKU.findOneAndUpdate(
          { "source.type": "product_master", "source.externalSku": item.externalSku },
          { $set: { ...preserveGalleryOnSpreadsheetUpdate(skuPayload), product: product._id } },
          { new: true, upsert: true, runValidators: true, setDefaultsOnInsert: true }
        );
      } catch (error) {
        if (productCreated) await Product.findByIdAndDelete(product._id);
        throw error;
      }

      await syncProductPriceRange(product._id);
      kept.products.push(product._id);
      kept.skus.push(sku._id);
      catalogRefs.set(item.rowKey, { model: "Product", id: product._id });

      if (saveAsDraft) draftHampersSaved += 1;
      resultByKey.set(item.rowKey, {
        ...publicImportResult(item),
        // REVIEW stays REVIEW so Admin Archive retains exact missing fields;
        // database product + SKU IDs have nevertheless been saved as DRAFT.
        action: saveAsDraft
          ? "REVIEW"
          : oldProduct ? (item.action === "SKIP" ? "UNCHANGED" : "UPDATED") : "CREATED",
        ...(saveAsDraft ? {
          reason: `${item.reason}; saved as inactive MongoDB Product + SKU (Admin-only)`,
        } : {}),
      });
    } catch (error) {
      resultByKey.set(item.rowKey, {
        ...publicImportResult(item),
        action: "ERROR",
        blocking: false,
        reason: error.message || "Unable to import ready-made hamper",
      });
    }
  }

  const results = analysis.results.map(
    (item) => resultByKey.get(item.rowKey) || publicImportResult(item)
  );

  // Archived snapshot of EACH workbook row includes all original Excel columns.
  // Persist first: if it fails, do not retire formerly visible records.
  console.info(`[ProductMaster] confirm:archive-start rows=${results.length} elapsedMs=${Date.now() - confirmStartedAt}`);
  await archiveProductMasterSourceRows({ analysis, results, importedAt, catalogRefs });
  console.info(`[ProductMaster] confirm:archive-done elapsedMs=${Date.now() - confirmStartedAt}`);
  // Never bulk-retire products omitted from a later supplier workbook.
  // Such rows remain in MongoDB for admin/history; publication is managed
  // separately. The previous retireMissingImportedRows call could also
  // deactivate unchanged SKIP entries during an ordinary re-import.


  for (const item of results) {
    if (item.action === "CREATED") summary.created += 1;
    else if (item.action === "UPDATED") summary.updated += 1;
    else if (item.action === "SKIP" || item.action === "UNCHANGED") summary.skipped += 1;
    else if (item.action === "REVIEW") summary.review += 1;
    else if (item.action === "ERROR") summary.errors += 1;
  }

  const [databaseProducts, databaseSkus, databaseComponents, databaseContainers] =
    await Promise.all([
      Product.countDocuments({}),
      SKU.countDocuments({}),
      Component.countDocuments({}),
      Container.countDocuments({}),
    ]);

  // Never delete Product Master categories during a non-destructive import.
  const cleanedCategories = 0;

  const databaseState = {
    products: databaseProducts,
    skus: databaseSkus,
    components: databaseComponents,
    containers: databaseContainers,
    cleanedCategories,
  };

  const importedCount = summary.created + summary.updated;
  const partialIssues = summary.review + summary.errors + analysis.compositionErrors.length;
  summary.archivedDraftHampers = draftHampersSaved;
  const success = analysis.allowPartialImport
    ? importedCount > 0
    : summary.errors === 0 && summary.review === 0;

  console.info(`[ProductMaster] confirm:complete elapsedMs=${Date.now() - confirmStartedAt} created=${summary.created} updated=${summary.updated} errors=${summary.errors}`);
  res.status(200).json({
    success: true,
    message: `Saved ${importedCount} new/updated complete rows and ${draftHampersSaved} inactive draft hamper(s); ${summary.skipped} unchanged. ${partialIssues} issue(s) retained in Admin Archive. Missing prices are never guessed and incomplete hampers are hidden from customers.`,
    importMode: "archive_upsert",
    replacementStrategy: "non_destructive_upsert_with_archive",
    workbookProfile: analysis.workbookProfile,
    allowPartialImport: analysis.allowPartialImport,
    databaseState,
    filename: analysis.filename,
    sheetName: analysis.sheetName,
    productHeaderRow: analysis.productHeaderRow,
    hamperMasterSheetName: analysis.hamperMasterSheetName,
    compositionSheetName: analysis.compositionSheetName,
    containerSetupSheetName: analysis.containerSetupSheetName,
    decorationSheetName: analysis.decorationSheetName,
    compositionErrors: analysis.compositionErrors,
    summary,
    results,
  });
});


/* =========================================================
   PUBLIC COMPONENTS / CONTAINERS
========================================================= */

const isBuilderCatalogRequest = (value) =>
  ["1", "true", "yes", "builder"].includes(
    String(value || "").trim().toLowerCase()
  );

const hasPositiveBuilderDimensions = (dimensions) =>
  Boolean(
    dimensions &&
      Number(dimensions.length) > 0 &&
      Number(dimensions.width) > 0 &&
      Number(dimensions.height) > 0
  );

const hasPositiveBuilderWeight = (weight) =>
  Boolean(weight && Number(weight.value) > 0);

const buildComponentBuilderStatus = (component, { channel = "" } = {}) => {
  const reasons = [];
  const isDecoration = (component.hamperRole || "content") === "decoration";

  if (component.isActive === false) {
    reasons.push("Inactive in catalogue");
  }

  if (!isDecoration && component.hamperUse === false) {
    reasons.push("Not enabled for custom hampers");
  }

  if (component.customerSelectable === false) {
    reasons.push("Not enabled for customer selection");
  }

  if (!(Number(component.sellingPrice) > 0)) {
    reasons.push("Selling price missing");
  }

  if (!isDecoration && !hasPositiveBuilderDimensions(component.dimensions)) {
    reasons.push("Product dimensions incomplete");
  }

  if (!isDecoration && !hasPositiveBuilderWeight(component.weight)) {
    reasons.push("Product weight missing");
  }

  if (channel && component.channels?.[channel] !== true) {
    reasons.push(`Not enabled for ${channel} channel`);
  }

  return {
    visible: true,
    selectable: reasons.length === 0,
    reasons: [...new Set(reasons)],
  };
};

const buildContainerBuilderStatus = (container, { channel = "" } = {}) => {
  const reasons = [];

  if (container.isActive === false) {
    reasons.push("Inactive in catalogue");
  }

  if (container.hamperUse === false) {
    reasons.push("Not enabled for custom hampers");
  }

  if (container.customerSelectable === false) {
    reasons.push("Not enabled for customer selection");
  }

  if (!(Number(container.sellingPrice) > 0)) {
    reasons.push("Selling price missing");
  }

  if (!hasPositiveBuilderDimensions(container.innerDimensions)) {
    reasons.push("True inner dimensions missing");
  }

  if (!hasPositiveBuilderWeight(container.maxContentWeight)) {
    reasons.push("Maximum content weight missing");
  }

  const usableVolumePercent = Number(container.usableVolumePercent);
  if (
    !Number.isFinite(usableVolumePercent) ||
    usableVolumePercent < 1 ||
    usableVolumePercent > 100
  ) {
    reasons.push("Usable volume percent missing or invalid");
  }

  if (channel && container.channels?.[channel] !== true) {
    reasons.push(`Not enabled for ${channel} channel`);
  }

  return {
    visible: true,
    selectable: reasons.length === 0,
    reasons: [...new Set(reasons)],
  };
};


/* =========================================================
   CUSTOM HAMPER SOCIAL PROOF / RECOMMENDATIONS
   ---------------------------------------------------------
   Source of truth: successful paid custom-hamper orders.
   - Cart activity is intentionally NOT counted as a sale.
   - Fully refunded and cancelled orders are excluded.
   - Container popularity is attached only to builderCatalog responses.
   - Product recommendations are attached only when the caller supplies
     recommendForContainer=<containerId>.
   - No fake labels are emitted when order history does not support them.
========================================================= */

const CUSTOM_HAMPER_RECOMMENDATION_RECENT_DAYS = 90;

const getCustomHamperRecommendationSince = () => {
  const date = new Date();
  date.setUTCDate(
    date.getUTCDate() - CUSTOM_HAMPER_RECOMMENDATION_RECENT_DAYS
  );
  return date;
};

const customHamperSalesMatch = () => ({
  paymentStatus: {
    $in: [
      ORDER_PAYMENT_STATUS.PAID,
      ORDER_PAYMENT_STATUS.PARTIALLY_REFUNDED,
    ],
  },
  status: { $ne: ORDER_STATUS.CANCELLED },
  "items.itemType": "custom_hamper",
});

const addContainerPopularityRanks = (rows = []) => {
  const sorted = [...rows].sort((left, right) => {
    const soldDiff = Number(right.soldCount || 0) - Number(left.soldCount || 0);
    if (soldDiff !== 0) return soldDiff;

    const recentDiff =
      Number(right.recentSoldCount || 0) - Number(left.recentSoldCount || 0);
    if (recentDiff !== 0) return recentDiff;

    return Number(right.orderCount || 0) - Number(left.orderCount || 0);
  });

  const map = new Map();

  sorted.forEach((row, index) => {
    const soldCount = Number(row.soldCount || 0);
    if (soldCount <= 0 || !row._id) return;

    const rank = index + 1;
    const badge = rank === 1 ? "most_loved" : rank <= 3 ? "popular" : "";
    const label = rank === 1 ? "Most loved" : rank <= 3 ? "Popular" : "";

    map.set(String(row._id), {
      soldCount,
      orderCount: Number(row.orderCount || 0),
      recentSoldCount: Number(row.recentSoldCount || 0),
      rank,
      badge,
      label,
      windowDays: CUSTOM_HAMPER_RECOMMENDATION_RECENT_DAYS,
    });
  });

  return map;
};

const loadCustomHamperContainerPopularity = async () => {
  const recentSince = getCustomHamperRecommendationSince();

  const rows = await Order.aggregate([
    { $match: customHamperSalesMatch() },
    { $unwind: "$items" },
    {
      $match: {
        "items.itemType": "custom_hamper",
        "items.customHamper.container": { $ne: null },
      },
    },
    {
      $group: {
        _id: "$items.customHamper.container",
        soldCount: {
          $sum: { $ifNull: ["$items.quantity", 1] },
        },
        recentSoldCount: {
          $sum: {
            $cond: [
              {
                $gte: [
                  { $ifNull: ["$paidAt", "$createdAt"] },
                  recentSince,
                ],
              },
              { $ifNull: ["$items.quantity", 1] },
              0,
            ],
          },
        },
        orderIds: { $addToSet: "$_id" },
      },
    },
    {
      $project: {
        soldCount: 1,
        recentSoldCount: 1,
        orderCount: { $size: "$orderIds" },
      },
    },
  ]);

  return addContainerPopularityRanks(rows);
};

const buildComponentRecommendationMap = ({
  containerRows = [],
  overallRows = [],
} = {}) => {
  const overallSorted = [...overallRows].sort((left, right) => {
    const pickedDiff =
      Number(right.pickedCount || 0) - Number(left.pickedCount || 0);
    if (pickedDiff !== 0) return pickedDiff;

    return (
      Number(right.recentPickedCount || 0) -
      Number(left.recentPickedCount || 0)
    );
  });

  const overallMap = new Map();
  overallSorted.forEach((row, index) => {
    if (!row?._id || Number(row.pickedCount || 0) <= 0) return;

    overallMap.set(String(row._id), {
      pickedCount: Number(row.pickedCount || 0),
      recentPickedCount: Number(row.recentPickedCount || 0),
      orderCount: Number(row.orderCount || 0),
      rank: index + 1,
    });
  });

  const containerSorted = [...containerRows].sort((left, right) => {
    const pickedDiff =
      Number(right.pickedCount || 0) - Number(left.pickedCount || 0);
    if (pickedDiff !== 0) return pickedDiff;

    const recentDiff =
      Number(right.recentPickedCount || 0) -
      Number(left.recentPickedCount || 0);
    if (recentDiff !== 0) return recentDiff;

    return Number(right.orderCount || 0) - Number(left.orderCount || 0);
  });

  const containerMap = new Map();
  containerSorted.forEach((row, index) => {
    if (!row?._id || Number(row.pickedCount || 0) <= 0) return;

    containerMap.set(String(row._id), {
      pickedCount: Number(row.pickedCount || 0),
      recentPickedCount: Number(row.recentPickedCount || 0),
      orderCount: Number(row.orderCount || 0),
      rank: index + 1,
    });
  });

  const ids = new Set([...overallMap.keys(), ...containerMap.keys()]);
  const result = new Map();

  for (const componentId of ids) {
    const box = containerMap.get(componentId) || null;
    const overall = overallMap.get(componentId) || null;

    if (box) {
      const badge =
        box.rank === 1
          ? "most_picked"
          : box.rank <= 3
            ? "popular_with_box"
            : "";

      result.set(componentId, {
        source: "container",
        score:
          box.pickedCount * 1000 +
          box.recentPickedCount * 100 +
          Number(overall?.pickedCount || 0),
        rank: box.rank,
        badge,
        label:
          box.rank === 1
            ? "Most picked with this box"
            : box.rank <= 3
              ? "Popular with this box"
              : "",
        pickedCount: box.pickedCount,
        recentPickedCount: box.recentPickedCount,
        orderCount: box.orderCount,
        overallPickedCount: Number(overall?.pickedCount || 0),
        windowDays: CUSTOM_HAMPER_RECOMMENDATION_RECENT_DAYS,
      });
      continue;
    }

    if (overall) {
      result.set(componentId, {
        source: "overall",
        score: overall.pickedCount,
        rank: overall.rank,
        badge: overall.rank <= 3 ? "popular_gift" : "",
        label: overall.rank <= 3 ? "Popular gift" : "",
        pickedCount: 0,
        recentPickedCount: 0,
        orderCount: 0,
        overallPickedCount: overall.pickedCount,
        windowDays: CUSTOM_HAMPER_RECOMMENDATION_RECENT_DAYS,
      });
    }
  }

  return result;
};

const componentPopularityPipeline = ({ containerObjectId = null } = {}) => {
  const recentSince = getCustomHamperRecommendationSince();

  const customHamperMatch = {
    "items.itemType": "custom_hamper",
    "items.customHamper.container": { $ne: null },
  };

  if (containerObjectId) {
    customHamperMatch["items.customHamper.container"] = containerObjectId;
  }

  return [
    { $match: customHamperSalesMatch() },
    { $unwind: "$items" },
    { $match: customHamperMatch },
    { $unwind: "$items.customHamper.components" },
    {
      $match: {
        "items.customHamper.components.component": { $ne: null },
      },
    },
    {
      $group: {
        _id: "$items.customHamper.components.component",
        pickedCount: {
          $sum: {
            $multiply: [
              { $ifNull: ["$items.quantity", 1] },
              {
                $ifNull: [
                  "$items.customHamper.components.quantity",
                  1,
                ],
              },
            ],
          },
        },
        recentPickedCount: {
          $sum: {
            $cond: [
              {
                $gte: [
                  { $ifNull: ["$paidAt", "$createdAt"] },
                  recentSince,
                ],
              },
              {
                $multiply: [
                  { $ifNull: ["$items.quantity", 1] },
                  {
                    $ifNull: [
                      "$items.customHamper.components.quantity",
                      1,
                    ],
                  },
                ],
              },
              0,
            ],
          },
        },
        orderIds: { $addToSet: "$_id" },
      },
    },
    {
      $project: {
        pickedCount: 1,
        recentPickedCount: 1,
        orderCount: { $size: "$orderIds" },
      },
    },
  ];
};

const loadCustomHamperComponentRecommendations = async (containerId) => {
  if (!isValidId(containerId)) return new Map();

  const containerObjectId = new mongoose.Types.ObjectId(String(containerId));

  const [containerRows, overallRows] = await Promise.all([
    Order.aggregate(componentPopularityPipeline({ containerObjectId })),
    Order.aggregate(componentPopularityPipeline()),
  ]);

  return buildComponentRecommendationMap({ containerRows, overallRows });
};

export const getComponents = asyncHandler(async (req, res) => {
  disableCatalogCaching(res);

  const {
    search,
    type,
    category,
    subcategory,
    segment,
    channel,
    hamperRole,
    builderCatalog,
    recommendForContainer,
  } = req.query;

  const includeBuilderCatalogue = isBuilderCatalogRequest(builderCatalog);

  if (recommendForContainer && !isValidId(recommendForContainer)) {
    return res.status(400).json({
      success: false,
      message: "Invalid recommendForContainer ID",
    });
  }

  const filter = buildComponentPublicFilter();
  // builderCatalog=1 no longer bypasses publication readiness. The Admin
  // Archive API is the only way to inspect incomplete imported records.
  filter.$and = [{ $or: [
    { hamperRole: "decoration" },
    {
      hamperRole: { $in: ["content", null] },
      hamperUse: { $ne: false },
      "dimensions.length": { $gt: 0 },
      "dimensions.width": { $gt: 0 },
      "dimensions.height": { $gt: 0 },
      "weight.value": { $gt: 0 },
    },
  ] }];

  if (type) {
    if (!PUBLIC_COMPONENT_TYPES.includes(type)) {
      return res.status(400).json({
        success: false,
        message: "Invalid public component type",
      });
    }

    filter.type = type;
  }

  if (hamperRole) {
    if (!HAMPER_ROLES.includes(hamperRole)) {
      return res.status(400).json({
        success: false,
        message: "Invalid hamper role",
      });
    }

    if (hamperRole === "decoration") {
      filter.hamperRole = "decoration";
    } else {
      const contentRoleFilter = {
        $or: [
          { hamperRole: "content" },
          { hamperRole: { $exists: false } },
          { hamperRole: null },
        ],
      };

      filter.hamperUse = { $ne: false };
      filter.$and.push(contentRoleFilter);
    }
  } else {
    filter.$and.push({
      $or: [
        { hamperRole: "decoration" },
        { hamperUse: { $ne: false }, $or: [
          { hamperRole: "content" },
          { hamperRole: { $exists: false } },
          { hamperRole: null },
        ] },
      ],
    });
  }

  // In builder catalogue mode we do not hide rows merely because a channel
  // flag is missing. The row is returned with a builderStatus reason instead.
  if (channel) {
    if (!CHANNEL_KEYS.includes(channel)) {
      return res.status(400).json({
        success: false,
        message: "Invalid channel",
      });
    }

    filter[`channels.${channel}`] = true;
  }

  if (category?.trim()) filter.category = category.trim();
  if (subcategory?.trim()) filter.subcategory = subcategory.trim();
  if (segment?.trim()) filter.segment = segment.trim();

  if (search?.trim()) {
    const safeSearch = escapeRegex(search.trim());

    filter.$or = [
      { name: { $regex: safeSearch, $options: "i" } },
      { code: { $regex: safeSearch, $options: "i" } },
      { brand: { $regex: safeSearch, $options: "i" } },
      { category: { $regex: safeSearch, $options: "i" } },
      { subcategory: { $regex: safeSearch, $options: "i" } },
      { segment: { $regex: safeSearch, $options: "i" } },
      { decorationType: { $regex: safeSearch, $options: "i" } },
    ];
  }

  const components = await Component.find(filter)
    .select(
      "name code type hamperRole decorationType countsTowardBoxCapacity brand description images skuBarcode sizePack uom piecesPerUom sourceProductType taxonomyBaseId categoryCode category subcategory segment productPriority mrp sellingPrice taxEnabled taxPercent hsnSac discount dimensions weight fragile dietary expiryTracked shelfLifeDays expiryDate personalizable personalizationMethod hamperUse channels availability.status availability.availableQuantity availability.unit availability.nextAvailableDate customerSelectable isActive source.type source.externalSku"
    )
    .sort({ productPriority: 1, name: 1 })
    .lean();

  const recommendationMap = recommendForContainer
    ? await loadCustomHamperComponentRecommendations(recommendForContainer)
    : new Map();

  const publicComponents = components.map((component) => {
    const hasSellingPrice = Number(component.sellingPrice) > 0;
    const pricing = hasSellingPrice
      ? calculateCatalogPricing({
          baseSellingPrice: component.sellingPrice,
          taxPercent: component.taxPercent ?? 0,
          taxEnabled: component.taxEnabled !== false,
          discount: component.discount || {},
        })
      : null;

    return {
      ...component,
      baseSellingPrice: pricing?.baseSellingPrice ?? null,
      sellingPrice: pricing?.price ?? null,
      discountAmount: pricing?.discountAmount ?? 0,
      taxablePrice: pricing?.taxableValue ?? null,
      taxAmount: pricing?.taxAmount ?? 0,
      taxIncluded: true,
      ...(recommendForContainer
        ? {
            recommendation:
              recommendationMap.get(String(component._id)) || null,
          }
        : {}),
      ...(includeBuilderCatalogue
        ? {
            builderStatus: buildComponentBuilderStatus(component, {
              channel,
            }),
          }
        : {}),
    };
  });

  return res.status(200).json({
    success: true,
    count: publicComponents.length,
    builderCatalog: includeBuilderCatalogue,
    components: publicComponents,
  });
});

export const getContainers = asyncHandler(async (req, res) => {
  disableCatalogCaching(res);

  const {
    search,
    category,
    subcategory,
    segment,
    channel,
    builderCatalog,
  } = req.query;

  const includeBuilderCatalogue = isBuilderCatalogRequest(builderCatalog);

  const filter = buildContainerPublicFilter();

  if (channel) {
    if (!CHANNEL_KEYS.includes(channel)) {
      return res.status(400).json({ success: false, message: "Invalid channel" });
    }

    filter[`channels.${channel}`] = true;
  }

  if (category?.trim()) filter.category = category.trim();
  if (subcategory?.trim()) filter.subcategory = subcategory.trim();
  if (segment?.trim()) filter.segment = segment.trim();

  if (search?.trim()) {
    const safeSearch = escapeRegex(search.trim());
    filter.$or = [
      { name: { $regex: safeSearch, $options: "i" } },
      { code: { $regex: safeSearch, $options: "i" } },
      { material: { $regex: safeSearch, $options: "i" } },
      { sourceProductType: { $regex: safeSearch, $options: "i" } },
      { category: { $regex: safeSearch, $options: "i" } },
      { subcategory: { $regex: safeSearch, $options: "i" } },
    ];
  }

  const containers = await Container.find(filter)
    .select(
      "name code material description images skuBarcode sourceProductType taxonomyBaseId categoryCode category subcategory segment productPriority mrp sellingPrice taxEnabled taxPercent hsnSac discount outerDimensions innerDimensions maxContentWeight usableVolumePercent maxItems productionLeadTime defaultCourierDays hamperUse channels availability.status availability.nextAvailableDate sortOrder customerSelectable isActive source.type source.externalSku"
    )
    .sort({ sortOrder: 1, productPriority: 1, name: 1 })
    .lean();

  const containerPopularityMap = includeBuilderCatalogue
    ? await loadCustomHamperContainerPopularity()
    : new Map();

  const result = containers.map((container) => {
    const hasSellingPrice = Number(container.sellingPrice) > 0;
    const pricing = hasSellingPrice
      ? calculateCatalogPricing({
          baseSellingPrice: container.sellingPrice,
          taxPercent: container.taxPercent ?? 0,
          taxEnabled: container.taxEnabled !== false,
          discount: container.discount || {},
        })
      : null;

    return {
      ...container,
      baseSellingPrice: pricing?.baseSellingPrice ?? null,
      sellingPrice: pricing?.price ?? null,
      discountAmount: pricing?.discountAmount ?? 0,
      taxablePrice: pricing?.taxableValue ?? null,
      taxAmount: pricing?.taxAmount ?? 0,
      taxIncluded: true,
      capacity: calculateContainerCapacity(container),
      ...(includeBuilderCatalogue
        ? {
            popularity:
              containerPopularityMap.get(String(container._id)) || null,
          }
        : {}),
      ...(includeBuilderCatalogue
        ? {
            builderStatus: buildContainerBuilderStatus(container, {
              channel,
            }),
          }
        : {}),
    };
  });

  return res.status(200).json({
    success: true,
    builderCatalog: includeBuilderCatalogue,
    count: result.length,
    containers: result,
  });
});

/* =========================================================
   PUBLIC CONFIGURATION VALIDATION
========================================================= */

export const validateConfiguration = asyncHandler(async (req, res) => {
  const {
    containerId,
    items = [],
    decorations = [],
    candidateIds,
    courierDays,
    channel,
  } = req.body;

  if (!isValidId(containerId)) {
    return res.status(400).json({
      success: false,
      message: "Valid containerId is required",
    });
  }

  if (channel && !CHANNEL_KEYS.includes(channel)) {
    return res.status(400).json({ success: false, message: "Invalid channel" });
  }

  const containerFilter = {
    _id: containerId,
    ...buildContainerPublicFilter(),
  };

  if (channel) containerFilter[`channels.${channel}`] = true;

  const container = await Container.findOne(containerFilter)
    .select("-internalNotes -latestUnitCost -actualLandedCost")
    .lean();

  if (!container) {
    return res.status(404).json({
      success: false,
      message: "Selectable container not found",
    });
  }

  if (containerArchiveReasons(container).length > 0) {
    return res.status(409).json({ success: false, message: "Selected box is incomplete; finish its Admin Archive requirements" });
  }

  const normalizedItems = normalizeConfigurationItems(items);
  if (!normalizedItems.valid) {
    return res.status(400).json({
      success: false,
      message: normalizedItems.message,
    });
  }

  const normalizedDecorations = normalizeConfigurationItems(decorations);
  if (!normalizedDecorations.valid) {
    return res.status(400).json({
      success: false,
      message: normalizedDecorations.message.replace(
        /Configuration quantity/g,
        "Decoration quantity"
      ),
    });
  }

  const selectedIds = normalizedItems.items.map((item) => item.componentId);
  const decorationIds = normalizedDecorations.items.map(
    (item) => item.componentId
  );

  const requestedCandidateIds = Array.isArray(candidateIds)
    ? [...new Set(candidateIds.map(String).filter((id) => isValidId(id)))]
    : null;

  const allIds = [
    ...new Set([
      ...selectedIds,
      ...decorationIds,
      ...(requestedCandidateIds || []),
    ]),
  ];

  const componentFilter = buildComponentPublicFilter();

  if (channel) componentFilter[`channels.${channel}`] = true;
  if (allIds.length > 0) componentFilter._id = { $in: allIds };

  const baseComponents = await Component.find(componentFilter)
    .select(
      "_id name code type hamperRole decorationType countsTowardBoxCapacity brand images category subcategory segment mrp sellingPrice taxEnabled taxPercent hsnSac discount dimensions weight fragile dietary expiryTracked shelfLifeDays expiryDate personalizable personalizationMethod channels availability isActive customerSelectable hamperUse"
    )
    .lean();

  const componentMap = new Map(
    baseComponents
      .filter((component) => componentArchiveReasons(component).length === 0)
      .map((component) => [String(component._id), component])
  );

  for (const selectedId of selectedIds) {
    const component = componentMap.get(String(selectedId));

    if (
      !component ||
      component.hamperUse === false ||
      (component.hamperRole || "content") === "decoration"
    ) {
      return res.status(400).json({
        success: false,
        message:
          "One or more selected hamper contents are inactive, unavailable for this channel, unavailable for custom hampers, decorative-only, or do not exist",
      });
    }
  }

  for (const decorationId of decorationIds) {
    const component = componentMap.get(String(decorationId));

    if (!component || (component.hamperRole || "content") !== "decoration") {
      return res.status(400).json({
        success: false,
        message:
          "One or more selected decorative materials are inactive, unavailable for this channel, not configured as decorative material, or do not exist",
      });
    }
  }

  const physical = evaluatePhysicalConfiguration(
    container,
    normalizedItems.items,
    componentMap
  );

  const courier = parseCourierDays(courierDays, container.defaultCourierDays);
  if (!courier.valid) {
    return res.status(400).json({ success: false, message: courier.message });
  }

  const deliveryEstimate = await calculateCustomConfigurationEta(
    container,
    normalizedItems.items,
    componentMap,
    courier.value,
    normalizedDecorations.items
  );

  const pricing = calculateConfigurationPricing(
    container,
    normalizedItems.items,
    componentMap,
    normalizedDecorations.items
  );

  let candidates = [];

  if (Array.isArray(candidateIds)) {
    candidates = requestedCandidateIds.map((candidateId) => {
      const component = componentMap.get(String(candidateId));

      if (
        !component ||
        (component.hamperRole || "content") === "decoration"
      ) {
        return {
          componentId: candidateId,
          selectable: false,
          reason: "UNAVAILABLE",
          message: configurationReasonMessage("UNAVAILABLE"),
          maxAdditionalQuantity: 0,
        };
      }

      if (!hasPrice(component.sellingPrice)) {
        return {
          componentId: candidateId,
          name: component.name,
          code: component.code,
          selectable: false,
          reason: "PRICE_NOT_SET",
          message: configurationReasonMessage("PRICE_NOT_SET"),
          maxAdditionalQuantity: 0,
        };
      }

      const baseQuantity =
        normalizedItems.items.find(
          (item) => String(item.componentId) === String(candidateId)
        )?.quantity || 0;

      const maxSearch = 100;
      let maxAdditionalQuantity = 0;
      let firstFailure = null;

      for (let additional = 1; additional <= maxSearch; additional += 1) {
        const totalCandidateQuantity = baseQuantity + additional;
        const candidateReady = resolveDependencyReadyDate(
          component,
          toUtcDay(new Date()),
          {
            requiredQuantity: totalCandidateQuantity,
            requiredUnit: "pc",
            stockUnit: true,
          }
        );

        if (!candidateReady.ready) {
          firstFailure = { reason: "UNAVAILABLE" };
          break;
        }

        const nextSelections = normalizedItems.items.filter(
          (item) => String(item.componentId) !== String(candidateId)
        );

        nextSelections.push({
          componentId: candidateId,
          quantity: totalCandidateQuantity,
        });

        const evaluation = evaluatePhysicalConfiguration(
          container,
          nextSelections,
          componentMap
        );

        if (!evaluation.valid) {
          firstFailure = evaluation;
          break;
        }

        maxAdditionalQuantity = additional;
      }

      return {
        componentId: candidateId,
        name: component.name,
        code: component.code,
        sellingPrice: component.sellingPrice,
        mrp: component.mrp,
        selectable: maxAdditionalQuantity > 0,
        reason:
          maxAdditionalQuantity > 0
            ? null
            : firstFailure?.reason || "PACKING_LAYOUT_NOT_FIT",
        message:
          maxAdditionalQuantity > 0
            ? null
            : configurationReasonMessage(
                firstFailure?.reason || "PACKING_LAYOUT_NOT_FIT"
              ),
        maxAdditionalQuantity,
      };
    });
  }

  const selectedExpiryDates = normalizedItems.items
    .map((item) => componentMap.get(String(item.componentId)))
    .filter(
      (component) => component?.expiryTracked !== false && component?.expiryDate
    )
    .map((component) => new Date(component.expiryDate))
    .filter((date) => !Number.isNaN(date.getTime()));

  const earliestExpiryDate = selectedExpiryDates.length
    ? new Date(Math.min(...selectedExpiryDates.map((date) => date.getTime())))
    : null;

  const finalReason = !physical.valid
    ? physical.reason
    : !deliveryEstimate.canEstimate
      ? "UNAVAILABLE"
      : !pricing.complete
        ? "PRICE_NOT_SET"
        : null;

  res.status(200).json({
    success: true,
    configuration: {
      valid: physical.valid,
      orderable:
        physical.valid && deliveryEstimate.canEstimate && pricing.complete,
      reason: finalReason,
      message: finalReason ? configurationReasonMessage(finalReason) : null,
      channel: channel || null,
      container: {
        _id: container._id,
        name: container.name,
        code: container.code,
        sellingPrice: container.sellingPrice ?? null,
        mrp: container.mrp ?? null,
        innerDimensions: container.innerDimensions,
        maxContentWeight: container.maxContentWeight,
        usableVolumePercent: container.usableVolumePercent,
        maxItems: container.maxItems,
      },
      selectedItems: pricing.items,
      selectedDecorations: pricing.decorations,
      pricing,
      earliestExpiryDate,
      capacity: physical.capacity || null,
      deliveryEstimate,
      candidates,
    },
  });
});

/* =========================================================
   PUBLIC TAXONOMY / PRODUCTS
========================================================= */

export const getCategories = asyncHandler(async (req, res) => {
  disableCatalogCaching(res);
  const categories = await Category.find({ isActive: true })
    .sort({ sortOrder: 1, name: 1 })
    .lean();

  res.status(200).json({ success: true, categories });
});

export const getCollections = asyncHandler(async (req, res) => {
  disableCatalogCaching(res);
  const collections = await Collection.find({ isActive: true })
    .sort({ isFeatured: -1, sortOrder: 1, name: 1 })
    .lean();

  res.status(200).json({ success: true, collections });
});

export const getProducts = asyncHandler(async (req, res) => {
  disableCatalogCaching(res);
  const {
    search,
    category,
    collection,
    minPrice,
    maxPrice,
    featured,
    sort,
  } = req.query;

  const { page, limit, skip } = getPagination(req.query);
  const activePricedProducts = await SKU.distinct("product", {
    isActive: true, price: { $gt: 0 },
  });
  const filter = {
    status: PRODUCT_STATUS.ACTIVE,
    minPrice: { $gt: 0 },
    category: { $exists: true, $ne: null },
    ...websiteImageMongoFilter(),
    _id: { $in: activePricedProducts },
  };

  if (search?.trim()) {
    const safeSearch = escapeRegex(search.trim());
    filter.$or = [
      { name: { $regex: safeSearch, $options: "i" } },
      { shortDescription: { $regex: safeSearch, $options: "i" } },
      { tags: { $regex: safeSearch, $options: "i" } },
    ];
  }

  if (category) {
    const categoryId = await resolveCategoryFilter(category);
    if (!categoryId) {
      return res.status(200).json({
        success: true,
        products: [],
        pagination: getPaginationMeta(0, page, limit),
      });
    }
    filter.category = categoryId;
  }

  if (collection) {
    const collectionId = await resolveCollectionFilter(collection);
    if (!collectionId) {
      return res.status(200).json({
        success: true,
        products: [],
        pagination: getPaginationMeta(0, page, limit),
      });
    }
    filter.collections = collectionId;
  }

  const parsedMinPrice = Number(minPrice);
  const parsedMaxPrice = Number(maxPrice);

  if (
    minPrice !== undefined &&
    minPrice !== "" &&
    Number.isFinite(parsedMinPrice) &&
    parsedMinPrice >= 0
  ) {
    filter.maxPrice = { $gte: parsedMinPrice };
  }

  if (
    maxPrice !== undefined &&
    maxPrice !== "" &&
    Number.isFinite(parsedMaxPrice) &&
    parsedMaxPrice >= 0
  ) {
    filter.minPrice = { ...filter.minPrice, $lte: parsedMaxPrice };
  }

  const featuredValue = parseBoolean(featured);
  if (featuredValue !== undefined) filter.isFeatured = featuredValue;

  let sortQuery = { createdAt: -1 };
  if (sort === "price-low") sortQuery = { minPrice: 1, createdAt: -1 };
  if (sort === "price-high") sortQuery = { minPrice: -1, createdAt: -1 };
  if (sort === "name") sortQuery = { name: 1 };
  if (sort === "featured") sortQuery = { isFeatured: -1, createdAt: -1 };

  const total = await Product.countDocuments(filter);
  const products = await Product.find(filter)
    .populate("category", "name slug")
    .populate("collections", "name slug")
    .sort(sortQuery)
    .skip(skip)
    .limit(limit)
    .lean();

  const productIds = products.map((product) => product._id);
  const rawSkus = productIds.length
    ? await SKU.find({ product: { $in: productIds }, isActive: true })
        .select(
          "product code price mrp compareAtPrice discount baseSellingPrice taxEnabled taxPercent container hamperContents packagedDimensions packagedWeight sortOrder"
        )
        .populate({
          path: "container",
          select: "outerDimensions",
        })
        .populate({
          path: "hamperContents.component",
          select: "weight",
        })
        .sort({ sortOrder: 1, price: 1 })
        .lean()
    : [];

  const skusByProduct = new Map();

  for (const sku of rawSkus) {
    const key = String(sku.product);

    if (!skusByProduct.has(key)) {
      skusByProduct.set(key, []);
    }

    skusByProduct.get(key).push(sku);
  }

  const publicProducts = products.map((product) => {
    const productSkus =
      skusByProduct.get(
        String(product._id)
      ) || [];

    const summarySku =
      productSkus[0] || null;

    const pricingSummary =
      buildCatalogCardPricing(
        productSkus
      );

    return {
      ...product,

      hamperSummary:
        summarySku
          ? calculateReadyMadeHamperMetrics(
              summarySku
            )
          : null,

      /*
       * Card pricing is resolved from the cheapest active SKU
       * so the displayed selling price, MRP and OFF percentage
       * all refer to the same SKU.
       */
      pricingSummary,

      // Convenient aliases for existing frontend cards.
      cardPrice:
        pricingSummary.sellingPrice,

      compareAtPrice:
        pricingSummary.compareAtPrice,

      mrp:
        pricingSummary.mrp,

      discountAmount:
        pricingSummary.discountAmount,

      discountPercent:
        pricingSummary.discountPercent,

      hasDiscount:
        pricingSummary.hasDiscount,
    };
  });

  res.status(200).json({
    success: true,
    products: publicProducts,
    pagination: getPaginationMeta(total, page, limit),
  });
});


export const getProductBySlug = asyncHandler(async (req, res) => {
  disableCatalogCaching(res);
  const { slug } = req.params;

  const product = await Product.findOne({
    slug: String(slug).trim().toLowerCase(),
    status: PRODUCT_STATUS.ACTIVE,
    minPrice: { $gt: 0 },
    category: { $exists: true, $ne: null },
    ...websiteImageMongoFilter(),
  })
    .populate("category", "name slug description")
    .populate("collections", "name slug")
    .lean();

  if (!product) {
    return res.status(404).json({ success: false, message: "Product not found" });
  }

  const rawSkus = await SKU.find({
    product: product._id,
    isActive: true,
    price: { $gt: 0 },
  })
    .select(
      "product code name optionValues baseSellingPrice mrp taxEnabled taxPercent hsnSac discount price compareAtPrice images container hamperContents internalMaterials decorations packagedDimensions packagedWeight productionLeadTime defaultCourierDays earliestExpiryDate isActive sortOrder createdAt updatedAt"
    )
    .populate({
      path: "container",
      select:
        "name code material images outerDimensions innerDimensions maxContentWeight usableVolumePercent maxItems availability productionLeadTime defaultCourierDays",
    })
    .populate({
      path: "hamperContents.component",
      select:
        "name code type hamperRole brand images sizePack uom dimensions weight fragile dietary expiryTracked shelfLifeDays expiryDate personalizable personalizationMethod availability",
    })
    .populate({
      path: "decorations.component",
      select:
        "name code type hamperRole decorationType brand images sizePack uom personalizable personalizationMethod availability sellingPrice taxEnabled taxPercent hsnSac discount",
    })
    .sort({ sortOrder: 1, price: 1 })
    .lean();

  if (rawSkus.length === 0) {
    return res.status(404).json({ success: false, message: "Product is not ready for sale" });
  }

  const skus = await Promise.all(
    rawSkus.map(async (sku) => {
      const courier = parseCourierDays(req.query.courierDays, sku.defaultCourierDays);

      if (!courier.valid) {
        const error = new Error(courier.message);
        error.statusCode = 400;
        throw error;
      }

      const deliveryEstimate = await calculateSkuDeliveryEstimate(sku, {
        courierDays: courier.value,
        includeDetails: false,
      });

      const hamperMetrics = calculateReadyMadeHamperMetrics(sku);
      const { internalMaterials, ...publicSku } = sku;

      return {
        ...publicSku,
        hamperMetrics,
        deliveryEstimate,
      };
    })
  );

  res.status(200).json({
    success: true,
    product: { ...product, skus },
  });
});


/* =========================================================
   ADMIN PRODUCT MASTER ARCHIVE / READINESS
========================================================= */

export const getProductMasterArchive = asyncHandler(async (req, res) => {
  const limit = Math.min(500, Math.max(1, Number(req.query.limit) || 200));
  const [sourceRows, components, containers, products, skus] = await Promise.all([
    ProductMasterArchive.find().sort({ lastImportedAt: -1, rowNumber: 1 }).limit(limit).lean(),
    Component.find({ "source.type": "product_master" }).lean(),
    Container.find({ "source.type": "product_master" }).lean(),
    Product.find({ "source.type": "product_master" }).lean(),
    SKU.find({ "source.type": "product_master" }).lean(),
  ]);
  const bySku = (rows) => new Map(rows.map((row) => [String(row.source?.externalSku || ""), row]));
  const componentBySku = bySku(components);
  const containerBySku = bySku(containers);
  const productBySku = bySku(products);
  const skuByProduct = new Map();
  for (const sku of skus) {
    const key = String(sku.product || "");
    if (!skuByProduct.has(key)) skuByProduct.set(key, []);
    skuByProduct.get(key).push(sku);
  }
  const records = sourceRows.filter((row) => {
    // Preserve historical archive documents, but don't display the old
    // misclassified Component snapshot as a second gift after a source SKU
    // has been positively identified as a Container in V22.
    if (row.recordType !== "component") return true;
    return !containerBySku.has(String(row.externalSku || ""));
  }).map((row) => {
    const code = String(row.externalSku || "");
    let reasons = [];
    let found = false;
    let record = null;
    if (row.recordType === "container") {
      record = containerBySku.get(code);
      found = Boolean(record);
      reasons = record ? containerArchiveReasons(record) : row.reasons;
    } else if (row.recordType === "ready_made_hamper") {
      record = productBySku.get(code);
      found = Boolean(record);
      reasons = record
        ? hamperArchiveReasons(record, skuByProduct.get(String(record._id)) || [])
        : row.reasons;
    } else {
      record = componentBySku.get(code);
      found = Boolean(record);
      reasons = record ? componentArchiveReasons(record) : row.reasons;
    }
    // Invalid rows remain archived even when they cannot enter a strict schema.
    if (!found && reasons.length === 0) reasons = ["Row needs review before catalogue creation"];

    // IMPORTANT: Customer publication is separate from admin media visibility.
    // Even an archived/inactive product must show its real saved pictures to admins.
    const productSkus = row.recordType === "ready_made_hamper" && record
      ? (skuByProduct.get(String(record._id)) || [])
      : [];
    const imageCandidates = [
      ...(Array.isArray(record?.images) ? record.images : []),
      ...productSkus.flatMap((sku) => Array.isArray(sku.images) ? sku.images : []),
    ];
    const seenImageUrls = new Set();
    const images = imageCandidates.map((image) => ({
      url: String(typeof image === "string" ? image : image?.url || "").trim(),
      alt: String(typeof image === "object" ? image?.alt || "" : ""),
    })).filter((image) => {
      if (!/^https:\/\//i.test(image.url) || seenImageUrls.has(image.url)) return false;
      try {
        const host = new URL(image.url).hostname.toLowerCase();
        if (["drive.google.com", "docs.google.com"].includes(host)) return false;
      } catch { return false; }
      seenImageUrls.add(image.url);
      return true;
    });

    // Raw Excel image link is ONLY a source reference, not a website image.
    // Keep it available to authenticated admins for diagnosing sync failures.
    const rawData = row.rawExcelData && typeof row.rawExcelData === "object"
      ? row.rawExcelData : {};
    const excelImageLink = Object.entries(rawData).find(([key]) =>
      ["imageasseturl", "imageurl"].includes(String(key).toLowerCase().replace(/[^a-z0-9]/g, ""))
    )?.[1];
    const sourceImageUrl = String(
      excelImageLink || row.sourceImageUrl || row.imageUrl || ""
    ).trim();
    const hasDriveLink = Boolean(parseDriveAssetLink(sourceImageUrl));
    const imageState = images.length > 0
      ? "saved"
      : hasDriveLink ? "drive_link_pending" : "no_source_link";

    const firstSku = productSkus[0] || null;
    const published = row.recordType === "ready_made_hamper" &&
      record?.status === PRODUCT_STATUS.ACTIVE && firstSku?.isActive === true;
    const publicationBlockers = row.recordType === "ready_made_hamper" ? [
      !record?.category ? "Website category missing" : null,
      !hasWebsiteImage(record?.images) ? "Hamper cover image missing (sync/upload an actual photo)" : null,
      !firstSku || !(Number(firstSku.price) > 0) ? "Positive selling price missing" : null,
      !firstSku || !(firstSku.hamperContents || []).length
        ? "Gift contents missing; cannot offer checkout for an empty hamper" : null,
    ].filter(Boolean) : [];
    // A hamper without actual gift contents is still an Admin DRAFT even if
    // its old status/price/image fields happen to pass the generic check.
    reasons = [...new Set([...reasons, ...publicationBlockers])];

    return {
      rowKey: row.rowKey, rowNumber: row.rowNumber,
      externalSku: row.externalSku, name: row.name,
      ...(row.recordType === "ready_made_hamper" ? {
        productId: record?._id || null,
        skuId: firstSku?._id || null,
        published,
        publicationBlockers,
      } : {}),
      recordType: row.recordType, sourceSheetName: row.sourceSheetName,
      importedToCatalog: found, state: found && reasons.length === 0 ? "ready" : "archive",
      reasons,
      images,
      imageCount: images.length,
      imageState,
      hasDriveLink,
      sourceImageUrl: hasDriveLink ? sourceImageUrl : "",
    };
  });
  const ready = records.filter((row) => row.state === "ready").length;
  const savedImageRows = records.filter((row) => row.imageState === "saved").length;
  const pendingDriveRows = records.filter((row) => row.imageState === "drive_link_pending").length;
  const noSourceLinkRows = records.filter((row) => row.imageState === "no_source_link").length;
  res.status(200).json({
    success: true,
    imageAuditVersion: "V22-live-state-hyperlink",
    summary: {
      total: records.length, ready, archive: records.length - ready,
      savedImageRows, pendingDriveRows, noSourceLinkRows,
    },
    records,
  });
});

/* =========================================================
   IMAGE UPLOAD
========================================================= */

export const uploadCatalogImage = asyncHandler(async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ success: false, message: "Image file is required" });
  }

  const allowedTypes = [
    "product",
    "sku",
    "category",
    "collection",
    "component",
    "container",
  ];

  const type = allowedTypes.includes(req.body.type) ? req.body.type : "product";
  const folderMap = {
    product: "hamporium/catalog/products",
    sku: "hamporium/catalog/skus",
    category: "hamporium/catalog/categories",
    collection: "hamporium/catalog/collections",
    component: "hamporium/catalog/components",
    container: "hamporium/catalog/containers",
  };

  const image = await uploadFile(req.file.buffer, { folder: folderMap[type] });

  res.status(201).json({
    success: true,
    message: "Image uploaded successfully",
    image,
  });
});

export const deleteCatalogImage = asyncHandler(async (req, res) => {
  const { publicId } = req.body;

  if (!publicId?.trim()) {
    return res.status(400).json({
      success: false,
      message: "Image public ID is required",
    });
  }

  await deleteFile(publicId.trim());

  res.status(200).json({
    success: true,
    message: "Image deleted successfully",
  });
});

/* =========================================================
   ADMIN CATEGORIES
========================================================= */

export const getAdminCategories = asyncHandler(async (req, res) => {
  const categories = await Category.find()
    .sort({ sortOrder: 1, name: 1 })
    .lean();

  res.status(200).json({ success: true, categories });
});

export const createCategory = asyncHandler(async (req, res) => {
  const { name, description, image, imagePublicId, isActive, sortOrder } = req.body;

  if (!name?.trim()) {
    return res.status(400).json({ success: false, message: "Category name is required" });
  }

  const slug = await ensureUniqueSlug(Category, name);
  const activeValue = parseBoolean(isActive);

  if (isActive !== undefined && activeValue === undefined) {
    return res.status(400).json({ success: false, message: "isActive must be true or false" });
  }

  const category = await Category.create({
    name: name.trim(),
    slug,
    description: description || "",
    image: image || "",
    imagePublicId: imagePublicId || "",
    isActive: activeValue ?? true,
    sortOrder: Number(sortOrder) || 0,
  });

  res.status(201).json({ success: true, message: "Category created successfully", category });
});

export const updateCategory = asyncHandler(async (req, res) => {
  const { categoryId } = req.params;

  if (!isValidId(categoryId)) {
    return res.status(400).json({ success: false, message: "Invalid category ID" });
  }

  const category = await Category.findById(categoryId);
  if (!category) {
    return res.status(404).json({ success: false, message: "Category not found" });
  }

  if (req.body.name !== undefined) {
    const name = String(req.body.name).trim();
    if (!name) {
      return res.status(400).json({ success: false, message: "Category name cannot be empty" });
    }
    category.name = name;
  }

  if (req.body.description !== undefined) category.description = req.body.description;
  if (req.body.image !== undefined) category.image = req.body.image;
  if (req.body.imagePublicId !== undefined) category.imagePublicId = req.body.imagePublicId;
  if (req.body.sortOrder !== undefined) category.sortOrder = Number(req.body.sortOrder) || 0;

  if (req.body.isActive !== undefined) {
    const activeValue = parseBoolean(req.body.isActive);
    if (activeValue === undefined) {
      return res.status(400).json({ success: false, message: "isActive must be true or false" });
    }
    category.isActive = activeValue;
  }

  if (req.body.slug) {
    category.slug = await ensureUniqueSlug(Category, req.body.slug, category._id);
  }

  await category.save();
  res.status(200).json({ success: true, message: "Category updated successfully", category });
});

export const deleteCategory = asyncHandler(async (req, res) => {
  const { categoryId } = req.params;

  if (!isValidId(categoryId)) {
    return res.status(400).json({ success: false, message: "Invalid category ID" });
  }

  const category = await Category.findById(categoryId);
  if (!category) {
    return res.status(404).json({ success: false, message: "Category not found" });
  }

  const productCount = await Product.countDocuments({ category: category._id });
  if (productCount > 0) {
    return res.status(409).json({
      success: false,
      message: "Category cannot be deleted because products are using it. Disable it instead.",
    });
  }

  await category.deleteOne();
  res.status(200).json({ success: true, message: "Category deleted successfully" });
});

/* =========================================================
   ADMIN COLLECTIONS
========================================================= */

export const getAdminCollections = asyncHandler(async (req, res) => {
  const collections = await Collection.find()
    .sort({ sortOrder: 1, name: 1 })
    .lean();

  res.status(200).json({ success: true, collections });
});

export const createCollection = asyncHandler(async (req, res) => {
  const {
    name,
    description,
    image,
    imagePublicId,
    bannerImage,
    bannerImagePublicId,
    isFeatured,
    isActive,
    sortOrder,
  } = req.body;

  if (!name?.trim()) {
    return res.status(400).json({ success: false, message: "Collection name is required" });
  }

  const slug = await ensureUniqueSlug(Collection, name);
  const featuredValue = parseBoolean(isFeatured);
  const activeValue = parseBoolean(isActive);

  if (isFeatured !== undefined && featuredValue === undefined) {
    return res.status(400).json({ success: false, message: "isFeatured must be true or false" });
  }

  if (isActive !== undefined && activeValue === undefined) {
    return res.status(400).json({ success: false, message: "isActive must be true or false" });
  }

  const collection = await Collection.create({
    name: name.trim(),
    slug,
    description: description || "",
    image: image || "",
    imagePublicId: imagePublicId || "",
    bannerImage: bannerImage || "",
    bannerImagePublicId: bannerImagePublicId || "",
    isFeatured: featuredValue ?? false,
    isActive: activeValue ?? true,
    sortOrder: Number(sortOrder) || 0,
  });

  res.status(201).json({ success: true, message: "Collection created successfully", collection });
});

export const updateCollection = asyncHandler(async (req, res) => {
  const { collectionId } = req.params;

  if (!isValidId(collectionId)) {
    return res.status(400).json({ success: false, message: "Invalid collection ID" });
  }

  const collection = await Collection.findById(collectionId);
  if (!collection) {
    return res.status(404).json({ success: false, message: "Collection not found" });
  }

  if (req.body.name !== undefined) {
    const name = String(req.body.name).trim();
    if (!name) {
      return res.status(400).json({ success: false, message: "Collection name cannot be empty" });
    }
    collection.name = name;
  }

  if (req.body.description !== undefined) collection.description = req.body.description;
  if (req.body.image !== undefined) collection.image = req.body.image;
  if (req.body.imagePublicId !== undefined) collection.imagePublicId = req.body.imagePublicId;
  if (req.body.bannerImage !== undefined) collection.bannerImage = req.body.bannerImage;
  if (req.body.bannerImagePublicId !== undefined) {
    collection.bannerImagePublicId = req.body.bannerImagePublicId;
  }
  if (req.body.sortOrder !== undefined) collection.sortOrder = Number(req.body.sortOrder) || 0;

  if (req.body.isFeatured !== undefined) {
    const featuredValue = parseBoolean(req.body.isFeatured);
    if (featuredValue === undefined) {
      return res.status(400).json({ success: false, message: "isFeatured must be true or false" });
    }
    collection.isFeatured = featuredValue;
  }

  if (req.body.isActive !== undefined) {
    const activeValue = parseBoolean(req.body.isActive);
    if (activeValue === undefined) {
      return res.status(400).json({ success: false, message: "isActive must be true or false" });
    }
    collection.isActive = activeValue;
  }

  if (req.body.slug) {
    collection.slug = await ensureUniqueSlug(Collection, req.body.slug, collection._id);
  }

  await collection.save();
  res.status(200).json({ success: true, message: "Collection updated successfully", collection });
});

export const deleteCollection = asyncHandler(async (req, res) => {
  const { collectionId } = req.params;

  if (!isValidId(collectionId)) {
    return res.status(400).json({ success: false, message: "Invalid collection ID" });
  }

  const collection = await Collection.findById(collectionId);
  if (!collection) {
    return res.status(404).json({ success: false, message: "Collection not found" });
  }

  await Product.updateMany(
    { collections: collection._id },
    { $pull: { collections: collection._id } }
  );

  await collection.deleteOne();
  res.status(200).json({ success: true, message: "Collection deleted successfully" });
});

/* =========================================================
   ADMIN COMPONENTS
========================================================= */

export const getAdminComponents = asyncHandler(async (req, res) => {
  const {
    search,
    type,
    isActive,
    customerSelectable,
    availability,
    category,
    subcategory,
    segment,
    channel,
    hamperUse,
    hamperRole,
  } = req.query;

  const { page, limit, skip } = getPagination(req.query, 30);
  const filter = {};

  if (search?.trim()) {
    const safeSearch = escapeRegex(search.trim());
    filter.$or = [
      { name: { $regex: safeSearch, $options: "i" } },
      { code: { $regex: safeSearch, $options: "i" } },
      { brand: { $regex: safeSearch, $options: "i" } },
      { "source.externalSku": { $regex: safeSearch, $options: "i" } },
    ];
  }

  if (type && COMPONENT_TYPES.includes(type)) filter.type = type;
  if (hamperRole && HAMPER_ROLES.includes(hamperRole)) {
    if (hamperRole === "decoration") {
      filter.hamperRole = "decoration";
    } else {
      filter.$and = [
        {
          $or: [
            { hamperRole: "content" },
            { hamperRole: { $exists: false } },
            { hamperRole: null },
          ],
        },
      ];
    }
  }
  if (category?.trim()) filter.category = category.trim();
  if (subcategory?.trim()) filter.subcategory = subcategory.trim();
  if (segment?.trim()) filter.segment = segment.trim();

  if (channel) {
    if (!CHANNEL_KEYS.includes(channel)) {
      return res.status(400).json({ success: false, message: "Invalid channel" });
    }
    filter[`channels.${channel}`] = true;
  }

  const activeValue = parseBoolean(isActive);
  if (activeValue !== undefined) filter.isActive = activeValue;

  const selectableValue = parseBoolean(customerSelectable);
  if (selectableValue !== undefined) filter.customerSelectable = selectableValue;

  const hamperUseValue = parseBoolean(hamperUse);
  if (hamperUseValue !== undefined) filter.hamperUse = hamperUseValue;

  if (availability && AVAILABILITY_VALUES.includes(availability)) {
    filter["availability.status"] = availability;
  }

  const total = await Component.countDocuments(filter);
  const components = await Component.find(filter)
    .sort({ productPriority: 1, createdAt: -1 })
    .skip(skip)
    .limit(limit)
    .lean();

  res.status(200).json({
    success: true,
    components,
    pagination: getPaginationMeta(total, page, limit),
  });
});

export const getAdminComponentById = asyncHandler(async (req, res) => {
  const { componentId } = req.params;

  if (!isValidId(componentId)) {
    return res.status(400).json({ success: false, message: "Invalid component ID" });
  }

  const component = await Component.findById(componentId).lean();
  if (!component) {
    return res.status(404).json({ success: false, message: "Component not found" });
  }

  res.status(200).json({ success: true, component });
});

export const createComponent = asyncHandler(async (req, res) => {
  const {
    name,
    code,
    type,
    hamperRole,
    brand,
    description,
    images,
    dimensions,
    weight,
    expiryDate,
    availability,
    customerSelectable,
    isActive,
    internalNotes,
  } = req.body;

  if (!name?.trim()) {
    return res.status(400).json({ success: false, message: "Component name is required" });
  }

  if (!code?.trim()) {
    return res.status(400).json({ success: false, message: "Component code is required" });
  }

  if (!COMPONENT_TYPES.includes(type)) {
    return res.status(400).json({ success: false, message: "Invalid component type" });
  }

  if (hamperRole !== undefined && !HAMPER_ROLES.includes(hamperRole)) {
    return res.status(400).json({ success: false, message: "Invalid hamper role" });
  }

  const finalHamperRole = type === "packaging" ? "content" : hamperRole || "content";

  if (finalHamperRole === "decoration" && type !== "non_food") {
    return res.status(400).json({
      success: false,
      message: "Decorative materials must use the non_food component type",
    });
  }

  const normalizedCode = code.trim().toUpperCase();
  const exists = await Component.exists({ code: normalizedCode });

  if (exists) {
    return res.status(409).json({ success: false, message: "Component code already exists" });
  }

  const selectableValue = parseBoolean(customerSelectable);
  const activeValue = parseBoolean(isActive);
  const hamperUseValue = parseBoolean(req.body.hamperUse);
  const expiryTrackedValue = parseBoolean(req.body.expiryTracked);

  if (customerSelectable !== undefined && selectableValue === undefined) {
    return res.status(400).json({
      success: false,
      message: "customerSelectable must be true or false",
    });
  }

  if (isActive !== undefined && activeValue === undefined) {
    return res.status(400).json({ success: false, message: "isActive must be true or false" });
  }

  if (req.body.hamperUse !== undefined && hamperUseValue === undefined) {
    return res.status(400).json({ success: false, message: "hamperUse must be true or false" });
  }

  if (req.body.expiryTracked !== undefined && expiryTrackedValue === undefined) {
    return res.status(400).json({ success: false, message: "expiryTracked must be true or false" });
  }

  const finalHamperUse = hamperUseValue ?? true;
  const finalExpiryTracked =
    type === "packaging" || finalHamperRole === "decoration"
      ? false
      : expiryTrackedValue ?? type === "food";
  const finalSelectable =
    type === "packaging"
      ? false
      : finalHamperRole === "decoration"
        ? selectableValue ?? false
        : !finalHamperUse
          ? false
          : selectableValue ?? false;

  const validationError = validateComponentPayload({
    ...req.body,
    type,
    hamperRole: finalHamperRole,
    expiryDate,
    expiryTracked: finalExpiryTracked,
    dimensions,
    weight,
    customerSelectable: finalSelectable,
    availability,
  });

  if (validationError) {
    return res.status(400).json({ success: false, message: validationError });
  }

  const component = new Component({
    name: name.trim(),
    code: normalizedCode,
    type,
    hamperRole: finalHamperRole,
    brand: brand?.trim() || "",
    description: description || "",
    images: Array.isArray(images) ? images : [],
    dimensions: normalizeDimensions(dimensions),
    weight: normalizeWeight(weight),
    expiryDate: expiryDate ? new Date(expiryDate) : null,
    availability: normalizeAvailability(availability, { stockUnit: true }),
    customerSelectable: finalSelectable,
    isActive: activeValue ?? true,
    internalNotes: internalNotes || "",
  });

  applyComponentMasterFields(component, req.body);
  component.hamperRole = finalHamperRole;
  component.hamperUse = finalHamperUse;
  component.expiryTracked = finalExpiryTracked;

  if (type === "packaging") {
    component.hamperRole = "content";
    component.customerSelectable = false;
    component.expiryDate = null;
  }

  if (component.hamperRole === "decoration") {
    component.expiryTracked = false;
    component.expiryDate = null;
    component.countsTowardBoxCapacity = false;
  }

  await component.save();

  res.status(201).json({
    success: true,
    message: "Component created successfully",
    component,
  });
});

export const updateComponent = asyncHandler(async (req, res) => {
  const { componentId } = req.params;

  if (!isValidId(componentId)) {
    return res.status(400).json({ success: false, message: "Invalid component ID" });
  }

  const component = await Component.findById(componentId);
  if (!component) {
    return res.status(404).json({ success: false, message: "Component not found" });
  }

  if (req.body.name !== undefined) {
    const name = String(req.body.name).trim();
    if (!name) {
      return res.status(400).json({ success: false, message: "Component name cannot be empty" });
    }
    component.name = name;
  }

  if (req.body.code !== undefined) {
    const newCode = String(req.body.code).trim().toUpperCase();
    if (!newCode) {
      return res.status(400).json({ success: false, message: "Component code cannot be empty" });
    }

    const exists = await Component.exists({
      code: newCode,
      _id: { $ne: component._id },
    });

    if (exists) {
      return res.status(409).json({ success: false, message: "Component code already exists" });
    }

    component.code = newCode;
  }

  const nextType = req.body.type !== undefined ? req.body.type : component.type;
  if (!COMPONENT_TYPES.includes(nextType)) {
    return res.status(400).json({ success: false, message: "Invalid component type" });
  }

  let nextHamperRole =
    req.body.hamperRole !== undefined
      ? req.body.hamperRole
      : component.hamperRole || "content";

  if (!HAMPER_ROLES.includes(nextHamperRole)) {
    return res.status(400).json({ success: false, message: "Invalid hamper role" });
  }

  if (nextType === "packaging") nextHamperRole = "content";

  if (nextHamperRole === "decoration" && nextType !== "non_food") {
    return res.status(400).json({
      success: false,
      message: "Decorative materials must use the non_food component type",
    });
  }

  if (
    nextHamperRole === "decoration" &&
    (component.hamperRole || "content") !== "decoration"
  ) {
    const usedAsContent = await SKU.exists({
      "hamperContents.component": component._id,
    });

    if (usedAsContent) {
      return res.status(409).json({
        success: false,
        message:
          "Component is used in a ready-made hamper SKU and cannot be changed to a decorative material",
      });
    }
  }

  if (
    nextHamperRole !== "decoration" &&
    (component.hamperRole || "content") === "decoration"
  ) {
    const usedAsDecoration = await SKU.exists({
      "decorations.component": component._id,
    });

    if (usedAsDecoration) {
      return res.status(409).json({
        success: false,
        message:
          "Component is used in ready-made hamper decorations and cannot leave the decoration role",
      });
    }
  }

  if (req.body.type !== undefined && nextType !== component.type) {
    if (nextType === "packaging") {
      const usedAsContentOrDecoration = await SKU.exists({
        $or: [
          { "hamperContents.component": component._id },
          { "decorations.component": component._id },
        ],
      });

      if (usedAsContentOrDecoration) {
        return res.status(409).json({
          success: false,
          message:
            "Component is used in hamper contents/decorations and cannot be changed to packaging",
        });
      }
    } else {
      const usedAsSkuMaterial = await SKU.exists({
        "internalMaterials.component": component._id,
      });
      const usedAsContainerMaterial = await Container.exists({
        "packingMaterials.component": component._id,
      });

      if (usedAsSkuMaterial || usedAsContainerMaterial) {
        return res.status(409).json({
          success: false,
          message:
            "Component is used as packaging material and cannot be changed to a customer item type",
        });
      }
    }
  }

  let nextHamperUse = component.hamperUse !== false;
  if (req.body.hamperUse !== undefined) {
    const value = parseBoolean(req.body.hamperUse);
    if (value === undefined) {
      return res.status(400).json({ success: false, message: "hamperUse must be true or false" });
    }
    nextHamperUse = value;
  }

  let nextSelectable = component.customerSelectable;
  if (req.body.customerSelectable !== undefined) {
    const value = parseBoolean(req.body.customerSelectable);
    if (value === undefined) {
      return res.status(400).json({
        success: false,
        message: "customerSelectable must be true or false",
      });
    }
    nextSelectable = value;
  }

  if (nextType === "packaging") nextSelectable = false;
  if (nextHamperRole !== "decoration" && !nextHamperUse) nextSelectable = false;

  let nextExpiryTracked = Boolean(component.expiryTracked);
  if (req.body.expiryTracked !== undefined) {
    const value = parseBoolean(req.body.expiryTracked);
    if (value === undefined) {
      return res.status(400).json({ success: false, message: "expiryTracked must be true or false" });
    }
    nextExpiryTracked = value;
  } else if (req.body.type !== undefined && nextType === "food" && component.type !== "food") {
    nextExpiryTracked = true;
  }

  if (nextType === "packaging" || nextHamperRole === "decoration") {
    nextExpiryTracked = false;
  }

  const currentDimensions = toPlainObject(component.dimensions);
  const currentWeight = toPlainObject(component.weight);
  const currentAvailability = toPlainObject(component.availability);

  const nextDimensions =
    req.body.dimensions !== undefined
      ? { ...currentDimensions, ...req.body.dimensions }
      : currentDimensions;

  const nextWeight =
    req.body.weight !== undefined
      ? { ...currentWeight, ...req.body.weight }
      : currentWeight;

  const nextAvailability =
    req.body.availability !== undefined
      ? { ...currentAvailability, ...req.body.availability }
      : currentAvailability;

  const nextExpiry =
    req.body.expiryDate !== undefined ? req.body.expiryDate : component.expiryDate;

  const validationError = validateComponentPayload({
    ...req.body,
    type: nextType,
    hamperRole: nextHamperRole,
    expiryDate: nextExpiry,
    expiryTracked: nextExpiryTracked,
    dimensions: nextDimensions,
    weight: nextWeight,
    customerSelectable: nextSelectable,
    availability: nextAvailability,
  });

  if (validationError) {
    return res.status(400).json({ success: false, message: validationError });
  }

  component.type = nextType;
  component.hamperRole = nextHamperRole;
  component.hamperUse = nextHamperUse;
  component.customerSelectable = nextSelectable;
  component.expiryTracked = nextExpiryTracked;

  if (req.body.brand !== undefined) component.brand = String(req.body.brand || "").trim();
  if (req.body.description !== undefined) component.description = req.body.description || "";
  if (req.body.images !== undefined) {
    component.images = Array.isArray(req.body.images) ? req.body.images : [];
  }
  if (req.body.dimensions !== undefined) {
    component.dimensions = normalizeDimensions(nextDimensions);
  }
  if (req.body.weight !== undefined) component.weight = normalizeWeight(nextWeight);
  if (req.body.availability !== undefined) {
    component.availability = normalizeAvailability(nextAvailability, { stockUnit: true });
  }

  if (req.body.expiryDate !== undefined) {
    component.expiryDate = req.body.expiryDate ? new Date(req.body.expiryDate) : null;
  }

  if (nextType === "packaging" || nextHamperRole === "decoration") {
    component.expiryDate = null;
  }

  if (req.body.isActive !== undefined) {
    const activeValue = parseBoolean(req.body.isActive);
    if (activeValue === undefined) {
      return res.status(400).json({ success: false, message: "isActive must be true or false" });
    }
    component.isActive = activeValue;
  }

  if (req.body.internalNotes !== undefined) {
    component.internalNotes = req.body.internalNotes || "";
  }

  applyComponentMasterFields(component, req.body);
  component.hamperRole = nextHamperRole;
  component.hamperUse = nextHamperUse;
  component.expiryTracked = nextExpiryTracked;
  component.customerSelectable = nextSelectable;
  if (component.hamperRole === "decoration") {
    component.countsTowardBoxCapacity = false;
  }

  await component.save();

  if (
    req.body.expiryDate !== undefined ||
    req.body.type !== undefined ||
    req.body.expiryTracked !== undefined
  ) {
    await syncSkuExpiryForComponent(component._id);
  }

  res.status(200).json({
    success: true,
    message: "Component updated successfully",
    component,
  });
});

export const deleteComponent = asyncHandler(async (req, res) => {
  const { componentId } = req.params;

  if (!isValidId(componentId)) {
    return res.status(400).json({ success: false, message: "Invalid component ID" });
  }

  const component = await Component.findById(componentId);
  if (!component) {
    return res.status(404).json({ success: false, message: "Component not found" });
  }

  const usedBySKU = await SKU.exists({
    $or: [
      { "hamperContents.component": component._id },
      { "internalMaterials.component": component._id },
      { "decorations.component": component._id },
    ],
  });

  const usedByContainer = await Container.exists({
    "packingMaterials.component": component._id,
  });

  if (usedBySKU || usedByContainer) {
    return res.status(409).json({
      success: false,
      message: "Component is in use. Disable it instead of deleting it.",
    });
  }

  await component.deleteOne();
  res.status(200).json({ success: true, message: "Component deleted successfully" });
});

/* =========================================================
   ADMIN CONTAINERS
========================================================= */

export const getAdminContainers = asyncHandler(async (req, res) => {
  const {
    search,
    isActive,
    customerSelectable,
    availability,
    category,
    subcategory,
    segment,
    channel,
    hamperUse,
  } = req.query;

  const { page, limit, skip } = getPagination(req.query, 30);
  const filter = {};

  if (search?.trim()) {
    const safeSearch = escapeRegex(search.trim());
    filter.$or = [
      { name: { $regex: safeSearch, $options: "i" } },
      { code: { $regex: safeSearch, $options: "i" } },
      { material: { $regex: safeSearch, $options: "i" } },
      { "source.externalSku": { $regex: safeSearch, $options: "i" } },
    ];
  }

  if (category?.trim()) filter.category = category.trim();
  if (subcategory?.trim()) filter.subcategory = subcategory.trim();
  if (segment?.trim()) filter.segment = segment.trim();

  if (channel) {
    if (!CHANNEL_KEYS.includes(channel)) {
      return res.status(400).json({ success: false, message: "Invalid channel" });
    }
    filter[`channels.${channel}`] = true;
  }

  const activeValue = parseBoolean(isActive);
  if (activeValue !== undefined) filter.isActive = activeValue;

  const selectableValue = parseBoolean(customerSelectable);
  if (selectableValue !== undefined) filter.customerSelectable = selectableValue;

  const hamperUseValue = parseBoolean(hamperUse);
  if (hamperUseValue !== undefined) filter.hamperUse = hamperUseValue;

  if (availability && AVAILABILITY_VALUES.includes(availability)) {
    filter["availability.status"] = availability;
  }

  const total = await Container.countDocuments(filter);
  const containers = await Container.find(filter)
    .populate("packingMaterials.component", "name code type availability")
    .sort({ sortOrder: 1, productPriority: 1, createdAt: -1 })
    .skip(skip)
    .limit(limit)
    .lean();

  res.status(200).json({
    success: true,
    containers: containers.map((container) => ({
      ...container,
      capacity: calculateContainerCapacity(container),
      websiteVisibility: inspectContainerWebsiteVisibility(container),
    })),
    pagination: getPaginationMeta(total, page, limit),
  });
});

export const getAdminContainerById = asyncHandler(async (req, res) => {
  const { containerId } = req.params;

  if (!isValidId(containerId)) {
    return res.status(400).json({ success: false, message: "Invalid container ID" });
  }

  const container = await Container.findById(containerId)
    .populate("packingMaterials.component")
    .lean();

  if (!container) {
    return res.status(404).json({ success: false, message: "Container not found" });
  }

  res.status(200).json({
    success: true,
    container: {
      ...container,
      capacity: calculateContainerCapacity(container),
      websiteVisibility: inspectContainerWebsiteVisibility(container),
    },
  });
});

export const createContainer = asyncHandler(async (req, res) => {
  const {
    name,
    code,
    material,
    description,
    images,
    outerDimensions,
    innerDimensions,
    maxContentWeight,
    usableVolumePercent,
    maxItems,
    packingMaterials,
    productionLeadTime,
    defaultCourierDays,
    availability,
    customerSelectable,
    isActive,
    sortOrder,
    internalNotes,
  } = req.body;

  if (!name?.trim()) {
    return res.status(400).json({ success: false, message: "Container name is required" });
  }

  if (!code?.trim()) {
    return res.status(400).json({ success: false, message: "Container code is required" });
  }

  const normalizedCode = code.trim().toUpperCase();
  const exists = await Container.exists({ code: normalizedCode });

  if (exists) {
    return res.status(409).json({ success: false, message: "Container code already exists" });
  }

  const selectableValue = parseBoolean(customerSelectable);
  const activeValue = parseBoolean(isActive);
  const hamperUseValue = parseBoolean(req.body.hamperUse);

  if (customerSelectable !== undefined && selectableValue === undefined) {
    return res.status(400).json({
      success: false,
      message: "customerSelectable must be true or false",
    });
  }

  if (isActive !== undefined && activeValue === undefined) {
    return res.status(400).json({ success: false, message: "isActive must be true or false" });
  }

  if (req.body.hamperUse !== undefined && hamperUseValue === undefined) {
    return res.status(400).json({ success: false, message: "hamperUse must be true or false" });
  }

  const finalHamperUse = hamperUseValue ?? true;
  const finalSelectable = finalHamperUse ? selectableValue ?? true : false;

  const validationError = validateContainerPayload({
    ...req.body,
    outerDimensions,
    innerDimensions,
    maxContentWeight,
    usableVolumePercent: usableVolumePercent ?? 85,
    maxItems: maxItems ?? 0,
    availability,
    productionLeadTime,
    defaultCourierDays,
    hamperUse: finalHamperUse,
    customerSelectable: finalSelectable,
  });

  if (validationError) {
    return res.status(400).json({ success: false, message: validationError });
  }

  const materialsResult = await validateAndNormalizeMaterialItems(
    packingMaterials || [],
    { fieldName: "packingMaterials" }
  );

  if (!materialsResult.valid) {
    return res.status(400).json({ success: false, message: materialsResult.message });
  }

  const courier = parseCourierDays(defaultCourierDays, null);

  const container = new Container({
    name: name.trim(),
    code: normalizedCode,
    material: material?.trim() || "",
    description: description || "",
    images: Array.isArray(images) ? images : [],
    outerDimensions: normalizeContainerDimensions(outerDimensions),
    innerDimensions: normalizeContainerDimensions(innerDimensions),
    maxContentWeight: normalizeWeightCapacity(maxContentWeight),
    usableVolumePercent: Number(usableVolumePercent ?? 85),
    maxItems: Number(maxItems ?? 0),
    packingMaterials: materialsResult.items,
    productionLeadTime: normalizeProductionLeadTime(productionLeadTime),
    defaultCourierDays: courier.value,
    availability: normalizeAvailability(availability, { stockUnit: false }),
    customerSelectable: finalSelectable,
    isActive: activeValue ?? true,
    sortOrder: Number(sortOrder) || 0,
    internalNotes: internalNotes || "",
  });

  applyContainerMasterFields(container, req.body);
  container.hamperUse = finalHamperUse;
  container.customerSelectable = finalSelectable;

  await container.save();

  const plain = container.toObject();
  res.status(201).json({
    success: true,
    message: "Container created successfully",
    container: { ...plain, capacity: calculateContainerCapacity(plain) },
  });
});

export const updateContainer = asyncHandler(async (req, res) => {
  const { containerId } = req.params;

  if (!isValidId(containerId)) {
    return res.status(400).json({ success: false, message: "Invalid container ID" });
  }

  const container = await Container.findById(containerId);
  if (!container) {
    return res.status(404).json({ success: false, message: "Container not found" });
  }

  if (req.body.name !== undefined) {
    const name = String(req.body.name).trim();
    if (!name) {
      return res.status(400).json({ success: false, message: "Container name cannot be empty" });
    }
    container.name = name;
  }

  if (req.body.code !== undefined) {
    const newCode = String(req.body.code).trim().toUpperCase();
    if (!newCode) {
      return res.status(400).json({ success: false, message: "Container code cannot be empty" });
    }

    const exists = await Container.exists({
      code: newCode,
      _id: { $ne: container._id },
    });

    if (exists) {
      return res.status(409).json({ success: false, message: "Container code already exists" });
    }

    container.code = newCode;
  }

  const currentOuter = toPlainObject(container.outerDimensions);
  const currentInner = toPlainObject(container.innerDimensions);
  const currentWeight = toPlainObject(container.maxContentWeight);
  const currentAvailability = toPlainObject(container.availability);
  const currentLeadTime = toPlainObject(container.productionLeadTime);

  const nextOuter =
    req.body.outerDimensions !== undefined
      ? { ...currentOuter, ...req.body.outerDimensions }
      : currentOuter;
  const nextInner =
    req.body.innerDimensions !== undefined
      ? { ...currentInner, ...req.body.innerDimensions }
      : currentInner;
  const nextWeight =
    req.body.maxContentWeight !== undefined
      ? { ...currentWeight, ...req.body.maxContentWeight }
      : currentWeight;
  const nextAvailability =
    req.body.availability !== undefined
      ? { ...currentAvailability, ...req.body.availability }
      : currentAvailability;
  const nextLeadTime =
    req.body.productionLeadTime !== undefined
      ? { ...currentLeadTime, ...req.body.productionLeadTime }
      : currentLeadTime;
  const nextUsableVolume =
    req.body.usableVolumePercent !== undefined
      ? req.body.usableVolumePercent
      : container.usableVolumePercent;
  const nextMaxItems =
    req.body.maxItems !== undefined ? req.body.maxItems : container.maxItems;
  const nextCourierDays =
    req.body.defaultCourierDays !== undefined
      ? req.body.defaultCourierDays
      : container.defaultCourierDays;

  let nextHamperUse = container.hamperUse !== false;
  if (req.body.hamperUse !== undefined) {
    const value = parseBoolean(req.body.hamperUse);
    if (value === undefined) {
      return res.status(400).json({ success: false, message: "hamperUse must be true or false" });
    }
    nextHamperUse = value;
  }

  let nextSelectable = container.customerSelectable;
  if (req.body.customerSelectable !== undefined) {
    const value = parseBoolean(req.body.customerSelectable);
    if (value === undefined) {
      return res.status(400).json({
        success: false,
        message: "customerSelectable must be true or false",
      });
    }
    nextSelectable = value;
  }

  if (!nextHamperUse) nextSelectable = false;

  const validationError = validateContainerPayload({
    ...req.body,
    outerDimensions: nextOuter,
    innerDimensions: nextInner,
    maxContentWeight: nextWeight,
    usableVolumePercent: nextUsableVolume,
    maxItems: nextMaxItems,
    availability: nextAvailability,
    productionLeadTime: nextLeadTime,
    defaultCourierDays: nextCourierDays,
    hamperUse: nextHamperUse,
    customerSelectable: nextSelectable,
  });

  if (validationError) {
    return res.status(400).json({ success: false, message: validationError });
  }

  if (req.body.packingMaterials !== undefined) {
    const materialsResult = await validateAndNormalizeMaterialItems(
      req.body.packingMaterials,
      { fieldName: "packingMaterials" }
    );

    if (!materialsResult.valid) {
      return res.status(400).json({ success: false, message: materialsResult.message });
    }

    container.packingMaterials = materialsResult.items;
  }

  if (req.body.material !== undefined) container.material = String(req.body.material || "").trim();
  if (req.body.description !== undefined) container.description = req.body.description || "";
  if (req.body.images !== undefined) {
    container.images = Array.isArray(req.body.images) ? req.body.images : [];
  }
  if (req.body.outerDimensions !== undefined) {
    container.outerDimensions = normalizeContainerDimensions(nextOuter);
  }
  if (req.body.innerDimensions !== undefined) {
    container.innerDimensions = normalizeContainerDimensions(nextInner);
  }
  if (req.body.maxContentWeight !== undefined) {
    container.maxContentWeight = normalizeWeightCapacity(nextWeight);
  }
  if (req.body.usableVolumePercent !== undefined) {
    container.usableVolumePercent = Number(nextUsableVolume);
  }
  if (req.body.maxItems !== undefined) container.maxItems = Number(nextMaxItems);
  if (req.body.productionLeadTime !== undefined) {
    container.productionLeadTime = normalizeProductionLeadTime(nextLeadTime);
  }
  if (req.body.defaultCourierDays !== undefined) {
    container.defaultCourierDays = parseCourierDays(nextCourierDays, null).value;
  }
  if (req.body.availability !== undefined) {
    container.availability = normalizeAvailability(nextAvailability, { stockUnit: false });
  }

  container.hamperUse = nextHamperUse;
  container.customerSelectable = nextSelectable;

  if (req.body.isActive !== undefined) {
    const value = parseBoolean(req.body.isActive);
    if (value === undefined) {
      return res.status(400).json({ success: false, message: "isActive must be true or false" });
    }
    container.isActive = value;
  }

  if (req.body.sortOrder !== undefined) container.sortOrder = Number(req.body.sortOrder) || 0;
  if (req.body.internalNotes !== undefined) container.internalNotes = req.body.internalNotes || "";

  applyContainerMasterFields(container, req.body);
  container.hamperUse = nextHamperUse;
  container.customerSelectable = nextSelectable;

  await container.save();
  const plain = container.toObject();

  res.status(200).json({
    success: true,
    message: "Container updated successfully",
    container: { ...plain, capacity: calculateContainerCapacity(plain) },
  });
});

export const deleteContainer = asyncHandler(async (req, res) => {
  const { containerId } = req.params;

  if (!isValidId(containerId)) {
    return res.status(400).json({ success: false, message: "Invalid container ID" });
  }

  const container = await Container.findById(containerId);
  if (!container) {
    return res.status(404).json({ success: false, message: "Container not found" });
  }

  const usedBySKU = await SKU.exists({ container: container._id });
  if (usedBySKU) {
    return res.status(409).json({
      success: false,
      message: "Container is being used by one or more SKUs. Disable it instead of deleting it.",
    });
  }

  await container.deleteOne();
  res.status(200).json({ success: true, message: "Container deleted successfully" });
});

/* =========================================================
   ADMIN PRODUCTS
========================================================= */

export const getAdminProducts = asyncHandler(async (req, res) => {
  const { search, status, category } = req.query;
  const { page, limit, skip } = getPagination(req.query, 20);
  const filter = {};

  if (search?.trim()) {
    const safeSearch = escapeRegex(search.trim());
    filter.$or = [
      { name: { $regex: safeSearch, $options: "i" } },
      { slug: { $regex: safeSearch, $options: "i" } },
    ];
  }

  if (status) filter.status = status;
  if (category && isValidId(category)) filter.category = category;

  const total = await Product.countDocuments(filter);
  const products = await Product.find(filter)
    .populate("category", "name slug")
    .populate("collections", "name slug")
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit)
    .lean();

  res.status(200).json({
    success: true,
    products,
    pagination: getPaginationMeta(total, page, limit),
  });
});

export const getAdminProductById = asyncHandler(async (req, res) => {
  const { productId } = req.params;

  if (!isValidId(productId)) {
    return res.status(400).json({ success: false, message: "Invalid product ID" });
  }

  const product = await Product.findById(productId)
    .populate("category", "name slug")
    .populate("collections", "name slug")
    .lean();

  if (!product) {
    return res.status(404).json({ success: false, message: "Product not found" });
  }

  const rawSkus = await SKU.find({ product: product._id })
    .populate("container")
    .populate("hamperContents.component")
    .populate("decorations.component")
    .populate("internalMaterials.component")
    .sort({ sortOrder: 1, createdAt: 1 })
    .lean();

  const skus = await Promise.all(
    rawSkus.map(async (sku) => {
      const courier = parseCourierDays(req.query.courierDays, sku.defaultCourierDays);
      if (!courier.valid) {
        const error = new Error(courier.message);
        error.statusCode = 400;
        throw error;
      }

      return {
        ...sku,
        deliveryEstimate: await calculateSkuDeliveryEstimate(sku, {
          courierDays: courier.value,
          includeDetails: true,
        }),
      };
    })
  );

  res.status(200).json({
    success: true,
    product: { ...product, skus },
  });
});

export const createProduct = asyncHandler(async (req, res) => {
  const {
    name,
    shortDescription,
    description,
    brand,
    category,
    collections,
    tags,
    images,
    status,
    isFeatured,
  } = req.body;

  if (!name?.trim()) {
    return res.status(400).json({ success: false, message: "Product name is required" });
  }

  if (!category) {
    return res.status(400).json({ success: false, message: "Product category is required" });
  }

  const validCategory = await validateCategory(category);
  if (!validCategory) {
    return res.status(400).json({ success: false, message: "Invalid product category" });
  }

  const validCollections = await validateCollections(collections || []);
  if (validCollections === null) {
    return res.status(400).json({
      success: false,
      message: "One or more collections are invalid",
    });
  }

  const slug = await ensureUniqueSlug(Product, name);
  const featuredValue = parseBoolean(isFeatured);

  if (isFeatured !== undefined && featuredValue === undefined) {
    return res.status(400).json({ success: false, message: "isFeatured must be true or false" });
  }

  const product = await Product.create({
    name: name.trim(),
    slug,
    shortDescription: shortDescription || "",
    description: description || "",
    brand: brand || "HAMPORIUM",
    category: validCategory._id,
    collections: validCollections,
    tags: normalizeTags(tags),
    images: Array.isArray(images) ? images : [],
    status: status || PRODUCT_STATUS.DRAFT,
    isFeatured: featuredValue ?? false,
  });

  res.status(201).json({ success: true, message: "Product created successfully", product });
});

export const updateProduct = asyncHandler(async (req, res) => {
  const { productId } = req.params;

  if (!isValidId(productId)) {
    return res.status(400).json({ success: false, message: "Invalid product ID" });
  }

  const product = await Product.findById(productId);
  if (!product) {
    return res.status(404).json({ success: false, message: "Product not found" });
  }

  if (req.body.category !== undefined) {
    const category = await validateCategory(req.body.category);
    if (!category) {
      return res.status(400).json({ success: false, message: "Invalid product category" });
    }
    product.category = category._id;
  }

  if (req.body.collections !== undefined) {
    const collections = await validateCollections(req.body.collections);
    if (collections === null) {
      return res.status(400).json({
        success: false,
        message: "One or more collections are invalid",
      });
    }
    product.collections = collections;
  }

  if (req.body.name !== undefined) {
    const name = String(req.body.name).trim();
    if (!name) {
      return res.status(400).json({ success: false, message: "Product name cannot be empty" });
    }
    product.name = name;
  }

  if (req.body.shortDescription !== undefined) product.shortDescription = req.body.shortDescription;
  if (req.body.description !== undefined) product.description = req.body.description;
  if (req.body.brand !== undefined) product.brand = req.body.brand;
  if (req.body.images !== undefined) product.images = Array.isArray(req.body.images) ? req.body.images : [];
  if (req.body.status !== undefined) product.status = req.body.status;

  if (req.body.isFeatured !== undefined) {
    const featuredValue = parseBoolean(req.body.isFeatured);
    if (featuredValue === undefined) {
      return res.status(400).json({ success: false, message: "isFeatured must be true or false" });
    }
    product.isFeatured = featuredValue;
  }

  if (req.body.tags !== undefined) product.tags = normalizeTags(req.body.tags);

  if (req.body.slug) {
    product.slug = await ensureUniqueSlug(Product, req.body.slug, product._id);
  }

  await product.save();
  res.status(200).json({ success: true, message: "Product updated successfully", product });
});

export const deleteProduct = asyncHandler(async (req, res) => {
  const { productId } = req.params;

  if (!isValidId(productId)) {
    return res.status(400).json({ success: false, message: "Invalid product ID" });
  }

  const product = await Product.findById(productId);
  if (!product) {
    return res.status(404).json({ success: false, message: "Product not found" });
  }

  product.status = PRODUCT_STATUS.ARCHIVED;
  product.isFeatured = false;
  await product.save();

  await SKU.updateMany(
    { product: product._id },
    { $set: { isActive: false } }
  );

  await syncProductPriceRange(product._id);
  res.status(200).json({ success: true, message: "Product archived successfully" });
});

/* =========================================================
   ADMIN SKUS
========================================================= */

export const createSKU = asyncHandler(async (req, res) => {
  const { productId } = req.params;
  const {
    code,
    skuBarcode,
    name,
    optionValues,
    baseSellingPrice,
    price,
    mrp,
    taxEnabled,
    taxPercent,
    hsnSac,
    discount,
    pricingSource,
    taxSource,
    compareAtPrice,
    images,
    container,
    hamperContents,
    decorations,
    internalMaterials,
    packagedDimensions,
    packagedWeight,
    productionLeadTime,
    defaultCourierDays,
    isActive,
    sortOrder,
    source,
  } = req.body;

  if (!isValidId(productId)) {
    return res.status(400).json({ success: false, message: "Invalid product ID" });
  }

  const product = await Product.findById(productId);
  if (!product) {
    return res.status(404).json({ success: false, message: "Product not found" });
  }

  if (product.status === PRODUCT_STATUS.ARCHIVED) {
    return res.status(400).json({
      success: false,
      message: "Cannot add SKU to archived product",
    });
  }

  if (!code?.trim() || !name?.trim()) {
    return res.status(400).json({
      success: false,
      message: "SKU code and name are required",
    });
  }

  const parsedBaseSellingPrice = Number(
    baseSellingPrice !== undefined ? baseSellingPrice : price
  );
  if (!Number.isFinite(parsedBaseSellingPrice) || parsedBaseSellingPrice < 0) {
    return res.status(400).json({
      success: false,
      message: "Valid base selling price is required",
    });
  }

  const taxRate =
    taxPercent === undefined || taxPercent === null || taxPercent === ""
      ? 0
      : Number(taxPercent);
  if (!Number.isFinite(taxRate) || taxRate < 0 || taxRate > 100) {
    return res.status(400).json({ success: false, message: "Invalid GST rate" });
  }

  const taxEnabledValue =
    taxEnabled === undefined ? taxRate > 0 : parseBoolean(taxEnabled);
  if (taxEnabled !== undefined && taxEnabledValue === undefined) {
    return res.status(400).json({
      success: false,
      message: "taxEnabled must be true or false",
    });
  }

  const discountError = validateDiscountConfig(discount);
  if (discountError) {
    return res.status(400).json({ success: false, message: discountError });
  }

  const normalizedDiscount = normalizeDiscountConfig(discount);
  const pricing = calculateCatalogPricing({
    baseSellingPrice: parsedBaseSellingPrice,
    taxPercent: taxRate,
    taxEnabled: taxEnabledValue !== false,
    discount: normalizedDiscount,
  });

  let parsedMrp = null;
  if (mrp !== undefined && mrp !== null && mrp !== "") {
    parsedMrp = Number(mrp);
    if (!Number.isFinite(parsedMrp) || parsedMrp < 0) {
      return res.status(400).json({ success: false, message: "Invalid MRP" });
    }
  }

  let parsedCompareAtPrice = null;
  if (compareAtPrice !== undefined && compareAtPrice !== null && compareAtPrice !== "") {
    parsedCompareAtPrice = Number(compareAtPrice);
    if (!Number.isFinite(parsedCompareAtPrice) || parsedCompareAtPrice < 0) {
      return res.status(400).json({ success: false, message: "Invalid compare-at price" });
    }
  } else if (parsedMrp !== null && parsedMrp > pricing.price) {
    parsedCompareAtPrice = parsedMrp;
  }

  if (parsedCompareAtPrice !== null && parsedCompareAtPrice <= pricing.price) {
    parsedCompareAtPrice = null;
  }

  const normalizedCode = code.trim().toUpperCase();
  const existingSKU = await SKU.exists({ code: normalizedCode });
  if (existingSKU) {
    return res.status(409).json({ success: false, message: "SKU code already exists" });
  }

  const activeValue = parseBoolean(isActive);
  if (isActive !== undefined && activeValue === undefined) {
    return res.status(400).json({ success: false, message: "isActive must be true or false" });
  }

  const containerResult = await validateContainerReference(container);
  if (!containerResult.valid) {
    return res.status(400).json({ success: false, message: containerResult.message });
  }

  const contentsResult = await validateAndNormalizeHamperContents(hamperContents || []);
  if (!contentsResult.valid) {
    return res.status(400).json({ success: false, message: contentsResult.message });
  }

  const decorationsResult = await validateAndNormalizeDecorations(decorations || []);
  if (!decorationsResult.valid) {
    return res.status(400).json({ success: false, message: decorationsResult.message });
  }

  const materialsResult = await validateAndNormalizeMaterialItems(internalMaterials || [], {
    fieldName: "internalMaterials",
  });
  if (!materialsResult.valid) {
    return res.status(400).json({ success: false, message: materialsResult.message });
  }

  const leadTimeError = validateProductionLeadTime(productionLeadTime || {});
  if (leadTimeError) {
    return res.status(400).json({ success: false, message: leadTimeError });
  }

  const courier = parseCourierDays(defaultCourierDays, null);
  if (!courier.valid) {
    return res.status(400).json({ success: false, message: courier.message });
  }

  const sourceError = validateSource(source);
  if (sourceError) {
    return res.status(400).json({ success: false, message: sourceError });
  }

  const sku = await SKU.create({
    product: product._id,
    code: normalizedCode,
    skuBarcode: String(skuBarcode || "").trim(),
    name: name.trim(),
    optionValues: optionValues || {},
    baseSellingPrice: pricing.baseSellingPrice,
    mrp: parsedMrp,
    taxEnabled: pricing.taxEnabled,
    taxPercent: pricing.taxPercent,
    hsnSac: String(hsnSac || "").trim(),
    discount: pricing.discount,
    pricingSource: SOURCE_TYPES.includes(pricingSource) ? pricingSource : "manual",
    taxSource: SOURCE_TYPES.includes(taxSource) ? taxSource : "manual",
    price: pricing.price,
    compareAtPrice: parsedCompareAtPrice,
    images: Array.isArray(images) ? images : [],
    container: containerResult.containerId,
    hamperContents: contentsResult.items,
    decorations: decorationsResult.items,
    internalMaterials: materialsResult.items,
    packagedDimensions: packagedDimensions ? normalizeDimensions(packagedDimensions) : undefined,
    packagedWeight: packagedWeight ? normalizeWeight(packagedWeight) : undefined,
    productionLeadTime: normalizeProductionLeadTime(productionLeadTime),
    defaultCourierDays: courier.value,
    earliestExpiryDate: contentsResult.earliestExpiryDate,
    isActive: activeValue ?? true,
    sortOrder: Number(sortOrder) || 0,
    source: source ? normalizeSource(source) : undefined,
  });

  await syncProductPriceRange(product._id);
  res.status(201).json({ success: true, message: "SKU created successfully", sku });
});

export const updateSKU = asyncHandler(async (req, res) => {
  const { skuId } = req.params;

  if (!isValidId(skuId)) {
    return res.status(400).json({ success: false, message: "Invalid SKU ID" });
  }

  const sku = await SKU.findById(skuId);
  if (!sku) {
    return res.status(404).json({ success: false, message: "SKU not found" });
  }

  if (req.body.code !== undefined) {
    const newCode = String(req.body.code).trim().toUpperCase();
    if (!newCode) {
      return res.status(400).json({ success: false, message: "SKU code cannot be empty" });
    }

    const existingSKU = await SKU.exists({
      code: newCode,
      _id: { $ne: sku._id },
    });

    if (existingSKU) {
      return res.status(409).json({ success: false, message: "SKU code already exists" });
    }

    sku.code = newCode;
  }

  if (req.body.name !== undefined) {
    const name = String(req.body.name).trim();
    if (!name) {
      return res.status(400).json({ success: false, message: "SKU name cannot be empty" });
    }
    sku.name = name;
  }

  if (
    req.body.baseSellingPrice !== undefined ||
    req.body.price !== undefined
  ) {
    const basePrice = Number(
      req.body.baseSellingPrice !== undefined
        ? req.body.baseSellingPrice
        : req.body.price
    );

    if (!Number.isFinite(basePrice) || basePrice < 0) {
      return res.status(400).json({
        success: false,
        message: "Invalid base selling price",
      });
    }

    sku.baseSellingPrice = basePrice;
    sku.pricingSource = SOURCE_TYPES.includes(req.body.pricingSource)
      ? req.body.pricingSource
      : "manual";
  }

  if (req.body.mrp !== undefined) {
    if (req.body.mrp === null || req.body.mrp === "") {
      sku.mrp = null;
    } else {
      const mrp = Number(req.body.mrp);
      if (!Number.isFinite(mrp) || mrp < 0) {
        return res.status(400).json({ success: false, message: "Invalid MRP" });
      }
      sku.mrp = mrp;
    }
  }

  if (req.body.taxPercent !== undefined) {
    const rate = Number(req.body.taxPercent);
    if (!Number.isFinite(rate) || rate < 0 || rate > 100) {
      return res.status(400).json({ success: false, message: "Invalid GST rate" });
    }
    sku.taxPercent = rate;
    sku.taxSource = SOURCE_TYPES.includes(req.body.taxSource)
      ? req.body.taxSource
      : "manual";
  }

  if (req.body.taxEnabled !== undefined) {
    const enabled = parseBoolean(req.body.taxEnabled);
    if (enabled === undefined) {
      return res.status(400).json({
        success: false,
        message: "taxEnabled must be true or false",
      });
    }
    sku.taxEnabled = enabled;
  }

  if (req.body.hsnSac !== undefined) {
    sku.hsnSac = String(req.body.hsnSac || "").trim();
  }

  if (req.body.discount !== undefined) {
    const discountError = validateDiscountConfig(req.body.discount);
    if (discountError) {
      return res.status(400).json({ success: false, message: discountError });
    }
    sku.discount = normalizeDiscountConfig(
      req.body.discount,
      toPlainObject(sku.discount)
    );
    sku.pricingSource = SOURCE_TYPES.includes(req.body.pricingSource)
      ? req.body.pricingSource
      : "manual";
  }

  if (req.body.compareAtPrice !== undefined) {
    if (req.body.compareAtPrice === null || req.body.compareAtPrice === "") {
      sku.compareAtPrice = null;
    } else {
      const compareAtPrice = Number(req.body.compareAtPrice);
      if (!Number.isFinite(compareAtPrice) || compareAtPrice < 0) {
        return res.status(400).json({ success: false, message: "Invalid compare-at price" });
      }
      sku.compareAtPrice = compareAtPrice;
    }
  }

  if (req.body.optionValues !== undefined) sku.optionValues = req.body.optionValues || {};
  if (req.body.images !== undefined) sku.images = Array.isArray(req.body.images) ? req.body.images : [];

  if (req.body.container !== undefined) {
    const containerResult = await validateContainerReference(req.body.container);
    if (!containerResult.valid) {
      return res.status(400).json({ success: false, message: containerResult.message });
    }
    sku.container = containerResult.containerId;
  }

  if (req.body.hamperContents !== undefined) {
    const contentsResult = await validateAndNormalizeHamperContents(req.body.hamperContents);
    if (!contentsResult.valid) {
      return res.status(400).json({ success: false, message: contentsResult.message });
    }

    sku.hamperContents = contentsResult.items;
    sku.earliestExpiryDate = contentsResult.earliestExpiryDate;
  } else {
    sku.earliestExpiryDate = await calculateEarliestExpiryDate(sku.hamperContents);
  }

  if (req.body.decorations !== undefined) {
    const decorationsResult = await validateAndNormalizeDecorations(
      req.body.decorations
    );

    if (!decorationsResult.valid) {
      return res.status(400).json({
        success: false,
        message: decorationsResult.message,
      });
    }

    sku.decorations = decorationsResult.items;
  }

  if (req.body.internalMaterials !== undefined) {
    const materialsResult = await validateAndNormalizeMaterialItems(
      req.body.internalMaterials,
      { fieldName: "internalMaterials" }
    );

    if (!materialsResult.valid) {
      return res.status(400).json({ success: false, message: materialsResult.message });
    }

    sku.internalMaterials = materialsResult.items;
  }

  if (req.body.packagedDimensions !== undefined) {
    sku.packagedDimensions = normalizeDimensions(req.body.packagedDimensions);
  }

  if (req.body.packagedWeight !== undefined) {
    sku.packagedWeight = normalizeWeight(req.body.packagedWeight);
  }

  if (req.body.productionLeadTime !== undefined) {
    const nextLeadTime = {
      ...toPlainObject(sku.productionLeadTime),
      ...req.body.productionLeadTime,
    };

    const leadTimeError = validateProductionLeadTime(nextLeadTime);
    if (leadTimeError) {
      return res.status(400).json({ success: false, message: leadTimeError });
    }

    sku.productionLeadTime = normalizeProductionLeadTime(nextLeadTime);
  }

  if (req.body.defaultCourierDays !== undefined) {
    const courier = parseCourierDays(req.body.defaultCourierDays, null);
    if (!courier.valid) {
      return res.status(400).json({ success: false, message: courier.message });
    }
    sku.defaultCourierDays = courier.value;
  }

  if (req.body.sortOrder !== undefined) {
    const sortOrder = Number(req.body.sortOrder);
    if (!Number.isFinite(sortOrder)) {
      return res.status(400).json({ success: false, message: "Invalid SKU sort order" });
    }
    sku.sortOrder = sortOrder;
  }

  if (req.body.isActive !== undefined) {
    const activeValue = parseBoolean(req.body.isActive);
    if (activeValue === undefined) {
      return res.status(400).json({ success: false, message: "isActive must be true or false" });
    }
    sku.isActive = activeValue;
  }

  if (req.body.skuBarcode !== undefined) {
    sku.skuBarcode = String(req.body.skuBarcode || "").trim();
  }

  if (req.body.source !== undefined) {
    const sourceError = validateSource(req.body.source);
    if (sourceError) {
      return res.status(400).json({ success: false, message: sourceError });
    }
    sku.source = normalizeSource(req.body.source, toPlainObject(sku.source));
  }

  await sku.save();
  await syncProductPriceRange(sku.product);

  res.status(200).json({ success: true, message: "SKU updated successfully", sku });
});

export const deleteSKU = asyncHandler(async (req, res) => {
  const { skuId } = req.params;

  if (!isValidId(skuId)) {
    return res.status(400).json({ success: false, message: "Invalid SKU ID" });
  }

  const sku = await SKU.findById(skuId);
  if (!sku) {
    return res.status(404).json({ success: false, message: "SKU not found" });
    
  }

  const productId = sku.product;
  await sku.deleteOne();
  await syncProductPriceRange(productId);

  res.status(200).json({ success: true, message: "SKU deleted successfully" });
});


/* =========================================================
   IMAGE-ONLY GOOGLE DRIVE GALLERY SYNC (SAFE / RESUMABLE)

   The original importer is intentionally left unchanged. Its Confirm action
   clears the existing catalogue; this separate route NEVER does that.
   Upload the unmodified Excel once, then sync 3-5 image folders per call.
========================================================= */

const getImageSyncRowsFromWorkbook = async (file) => {
  const source = getProductMasterUploadSource(file);
  if (!source) {
    const error = new Error("Excel file is required");
    error.statusCode = 400;
    throw error;
  }
  const extension = String(file?.originalname || "").toLowerCase();
  let workbook;
  if (typeof source === "string" && /\.(xlsx|xlsm)$/.test(extension)) {
    const { compactBuffer } = await compactProductMasterFromZip(source, file.originalname || "");
    workbook = readWorkbookSource(compactBuffer, { dense: false, cellDates: false });
  } else {
    workbook = readWorkbookSource(source, { dense: false, cellDates: false });
  }

  try {
    const sheetGroups = [
      {
        aliases: PRODUCT_MASTER_SHEET_ALIASES,
        requiredAliasGroups: [["Product SKU", "SKU", "Product SKU (10 digits numeric — immutable)"], ["Product Name", "Name"]],
        skuAliases: ["Product SKU", "SKU", "Product SKU (10 digits numeric — immutable)"],
        nameAliases: ["Product Name", "Name"],
      },
      {
        aliases: HAMPER_MASTER_SHEET_ALIASES,
        requiredAliasGroups: [["Hamper Code", "Hamper SKU", "Product SKU"], ["Hamper Name", "Product Name", "Name"]],
        skuAliases: ["Hamper Code", "Hamper SKU", "Product SKU"],
        nameAliases: ["Hamper Name", "Product Name", "Name"],
      },
      {
        aliases: [DECORATION_MASTER_SHEET, "Decorations"],
        requiredAliasGroups: [["Decoration SKU", "Product SKU", "SKU"], ["Decoration Name", "Product Name", "Name"]],
        skuAliases: ["Decoration SKU", "Product SKU", "SKU"],
        nameAliases: ["Decoration Name", "Product Name", "Name"],
      },
    ];
    const found = new Map();
    const seenSheets = new Set();
    for (const group of sheetGroups) {
      const sheetName = findWorkbookSheet(workbook, group.aliases);
      if (!sheetName || seenSheets.has(sheetName)) continue;
      seenSheets.add(sheetName);
      const extracted = readWorksheetObjects(workbook.Sheets[sheetName], {
        requiredAliasGroups: group.requiredAliasGroups,
        includeRow: (row) => Boolean(masterText(row, group.skuAliases)),
      });
      for (const { row, rowNumber } of extracted.rows) {
        const externalSku = masterText(row, group.skuAliases);
        const imageUrl = masterText(row, ["Image / Asset URL", "Image URL"]);
        const name = masterText(row, group.nameAliases);
        if (!externalSku || !imageUrl || !parseDriveAssetLink(imageUrl)) continue;
        if (!found.has(externalSku)) {
          found.set(externalSku, { externalSku, imageUrl, name, rowNumber, sourceSheetName: sheetName });
        }
      }
    }
    return [...found.values()];
  } finally {
    releaseWorkbookSheets(workbook);
  }
};

export const prepareProductMasterImageSync = asyncHandler(async (req, res) => {
  if (!process.env.GOOGLE_DRIVE_API_KEY) {
    return res.status(503).json({ success: false, message: "Set GOOGLE_DRIVE_API_KEY on the backend before syncing images" });
  }
  const entries = await getImageSyncRowsFromWorkbook(req.file);
  if (!entries.length) {
    return res.status(422).json({ success: false, message: "No supported Google Drive links were found in Product Master, Hamper Master or Decoration Master" });
  }
  // Image-only preparation also repairs the archive's missing source-link metadata.
  // Never changes Product/SKU/Component/Container/prices or the original Excel.
  // Only match existing imported archive rows; no upsert is performed here.
  const linkOperations = entries.map((entry) => ({
    updateMany: {
      filter: {
        externalSku: String(entry.externalSku),
        sourceSheetName: String(entry.sourceSheetName),
      },
      update: { $set: { "rawExcelData.imageasseturl": entry.imageUrl } },
      upsert: false,
    },
  }));
  let archiveRowsMatched = 0;
  if (linkOperations.length) {
    const backfill = await ProductMasterArchive.bulkWrite(linkOperations, { ordered: false });
    archiveRowsMatched = Number(backfill.matchedCount || 0);
  }
  console.info(`[ImageSync] prepared ${entries.length} Drive links; matched ${archiveRowsMatched} archive rows`);
  const job = await ProductMasterImageSyncJob.create({
    entries,
    expiresAt: new Date(Date.now() + 72 * 60 * 60 * 1000),
  });
  res.status(201).json({
    success: true,
    jobId: String(job._id),
    total: entries.length,
    archiveRowsMatched,
    imageSyncVersion: "V14-single-folder-test",
    message: "Image-only sync prepared. Test one Drive folder first, then continue if it succeeds. No catalogue records were deleted.",
  });
});

export const advanceProductMasterImageSync = asyncHandler(async (req, res) => {
  const jobId = String(req.body?.jobId || "");
  if (!mongoose.isValidObjectId(jobId)) return res.status(400).json({ success: false, message: "Valid jobId is required" });
  const batchSize = 1; // One full folder per HTTP call prevents large Render timeouts.
  const job = await ProductMasterImageSyncJob.findOneAndUpdate(
    { _id: jobId, expiresAt: { $gt: new Date() }, $or: [
      { status: "ready" },
      { status: "running", startedAt: { $lt: new Date(Date.now() - 20 * 60 * 1000) } },
    ] },
    { $set: { status: "running", startedAt: new Date() } },
    { new: true }
  );
  if (!job) {
    const state = await ProductMasterImageSyncJob.findById(jobId).select("status cursor entries results").lean();
    return res.status(state?.status === "running" ? 409 : state ? 200 : 404).json({
      success: Boolean(state),
      busy: state?.status === "running",
      done: state?.status === "done",
      nextOffset: state?.cursor || 0,
      total: state?.entries?.length || 0,
      results: state?.results || [],
      message: state ? "Job is already running or finished" : "Image sync job was not found",
    });
  }

  try {
    const next = job.entries.slice(job.cursor, job.cursor + batchSize);
    const batchResults = [];
    for (const entry of next) batchResults.push(await syncProductMasterImageEntry(entry));
    job.results.push(...batchResults);
    job.cursor += next.length;
    const done = job.cursor >= job.entries.length;
    job.status = done ? "done" : "ready";
    job.startedAt = null;
    await job.save();
    res.json({
      success: true,
      done,
      jobId: String(job._id),
      nextOffset: job.cursor,
      total: job.entries.length,
      batchResults,
      summary: {
        updated: job.results.filter((r) => r.status === "updated").length,
        unchanged: job.results.filter((r) => r.status === "unchanged").length,
        failed: job.results.filter((r) => r.status === "failed").length,
        notFound: job.results.filter((r) => r.status === "not_found").length,
      },
      results: done ? job.results : undefined,
    });
  } catch (error) {
    job.status = "ready";
    job.startedAt = null;
    await job.save().catch(() => {});
    throw error;
  }
});

export const getProductMasterImageSyncStatus = asyncHandler(async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.jobId)) {
    return res.status(400).json({ success: false, message: "Invalid jobId" });
  }
  const job = await ProductMasterImageSyncJob.findById(req.params.jobId)
    .select("cursor status entries results")
    .lean();
  if (!job) return res.status(404).json({ success: false, message: "Image sync job not found" });
  res.json({ success: true, jobId: String(job._id), done: job.status === "done",
    busy: job.status === "running", nextOffset: job.cursor, total: job.entries.length, results: job.results });
});
